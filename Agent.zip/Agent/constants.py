"""
Constants used throughout the application.
"""

import os
from typing import Dict, Any, Optional

# AWS Bedrock Configuration
DEFAULT_AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
DEFAULT_MODEL_ID = os.getenv("LLM_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0")
ANTHROPIC_VERSION = "bedrock-2023-05-31"

# Database Configuration
DEFAULT_DB_URL = os.getenv("DATABASE_URL", "postgresql://nandha:nandha@3.83.8.200:5432/cocoindex")
DB_POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "10"))
DB_MAX_OVERFLOW = int(os.getenv("DB_MAX_OVERFLOW", "20"))
DB_POOL_RECYCLE = int(os.getenv("DB_POOL_RECYCLE", "3600"))
ECHO_SQL = os.getenv("ECHO_SQL", "False").lower() == "true"

# LLM Default Settings
DEFAULT_TEMPERATURE = 0.1
DEFAULT_MAX_TOKENS = 1000
DEFAULT_TOP_P = 0.9
DEFAULT_TOP_K = 250

# Environment Variable Names
class EnvVars:
    AWS_ACCESS_KEY_ID = "AKIA37NAM3MMYGH3BYWT"
    AWS_SECRET_ACCESS_KEY = "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"
    AWS_REGION = "us-east-1"
    DATABASE_URL = "DATABASE_URL"
    LOG_LEVEL = "LOG_LEVEL"
    
    @classmethod
    def get_aws_credentials(cls) -> Dict[str, str]:
        """Get AWS credentials from class variables."""
        return {
            "aws_access_key_id": cls.AWS_ACCESS_KEY_ID,
            "aws_secret_access_key": cls.AWS_SECRET_ACCESS_KEY,
            "region_name": cls.AWS_REGION
        }

#FRESHDESK Configuration
# FRESHDESK_API_KEY should be the base64-encoded string used in the 'Authorization: Basic ...' header for Freshdesk API requests
FRESHDESK_API_KEY="S0U1V0R3bm9sUGJrdExVWE1oYlo6RmludGVjaEAyMDIy"
FRESHDESK_DOMAIN="credavenue.freshdesk.com"
# Optional: If you need to send a Cookie header, set it here
FRESHDESK_COOKIE=""  # Set your cookie string if needed, otherwise leave as empty