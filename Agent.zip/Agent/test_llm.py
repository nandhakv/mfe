#!/usr/bin/env python3
"""
Test script for LLM functionality.
"""

import os
import sys
import time
import json
from constants import EnvVars

# Set up environment variables
os.environ["AWS_ACCESS_KEY_ID"] = EnvVars.AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = EnvVars.AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"] = EnvVars.AWS_REGION

def test_llm_imports():
    """Test that LLM module imports correctly."""
    print("🧪 Testing LLM Imports")
    print("=" * 30)
    
    try:
        from llm import call_llm_api, generate_response
        print("✅ LLM functions imported successfully")
        
        # Test direct import from module
        from llm.llm import call_llm_api as direct_call_llm_api
        from llm.llm import generate_response as direct_generate_response
        print("✅ Direct module imports successful")
        
        return True
        
    except Exception as e:
        print(f"❌ Import test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_basic_functionality():
    """Test basic LLM functionality with simple prompts."""
    print("\n🚀 Testing Basic Functionality")
    print("=" * 40)
    
    try:
        from llm import generate_response
        
        # Test with string input
        print("Testing string input...")
        simple_prompt = "What is 2 + 2? Please respond with just the number."
        
        start_time = time.time()
        response = generate_response(simple_prompt, max_tokens=50, temperature=0.1)
        execution_time = time.time() - start_time
        
        print(f"✅ String input test completed in {execution_time:.3f}s")
        print(f"   Prompt: {simple_prompt}")
        print(f"   Response: {response[:100]}{'...' if len(response) > 100 else ''}")
        
        # Test with message list input
        print("\nTesting message list input...")
        messages = [
            {"role": "user", "content": "What is the capital of France?"}
        ]
        
        start_time = time.time()
        response = generate_response(messages, max_tokens=50, temperature=0.1)
        execution_time = time.time() - start_time
        
        print(f"✅ Message list test completed in {execution_time:.3f}s")
        print(f"   Response: {response[:100]}{'...' if len(response) > 100 else ''}")
        
        return True
        
    except Exception as e:
        print(f"❌ Basic functionality test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_direct_api_calls():
    """Test direct API calls with custom payloads."""
    print("\n🔧 Testing Direct API Calls")
    print("=" * 40)
    
    try:
        from llm import call_llm_api
        from constants import DEFAULT_MODEL_ID, ANTHROPIC_VERSION, DEFAULT_TOP_P, DEFAULT_TOP_K
        
        # Create a custom payload
        custom_payload = {
            "modelId": DEFAULT_MODEL_ID,
            "body": {
                "anthropic_version": ANTHROPIC_VERSION,
                "max_tokens": 100,
                "temperature": 0.1,
                "top_p": DEFAULT_TOP_P,
                "top_k": DEFAULT_TOP_K,
                "messages": [
                    {
                        "role": "user",
                        "content": "Say 'Hello, World!' and nothing else."
                    }
                ]
            }
        }
        
        print("Testing custom payload...")
        start_time = time.time()
        response = call_llm_api(custom_payload)
        execution_time = time.time() - start_time
        
        print(f"✅ Direct API call completed in {execution_time:.3f}s")
        print(f"   Response: {response[:100]}{'...' if len(response) > 100 else ''}")
        
        return True
        
    except Exception as e:
        print(f"❌ Direct API test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_parameter_variations():
    """Test different parameter combinations."""
    print("\n⚙️ Testing Parameter Variations")
    print("=" * 40)
    
    try:
        from llm import generate_response
        
        # Test different temperatures
        temperatures = [0.1, 0.5, 0.9]
        base_prompt = "Write a one-sentence story about a cat."
        
        for temp in temperatures:
            print(f"Testing temperature {temp}...")
            start_time = time.time()
            response = generate_response(base_prompt, max_tokens=100, temperature=temp)
            execution_time = time.time() - start_time
            
            print(f"   Temperature {temp}: {execution_time:.3f}s")
            print(f"   Response: {response[:80]}{'...' if len(response) > 80 else ''}")
        
        # Test different max_tokens
        print("\nTesting different max_tokens...")
        token_limits = [50, 100, 200]
        
        for tokens in token_limits:
            print(f"Testing max_tokens {tokens}...")
            start_time = time.time()
            response = generate_response("Explain quantum computing in simple terms.", 
                                      max_tokens=tokens, temperature=0.0)
            execution_time = time.time() - start_time
            
            print(f"   Max tokens {tokens}: {execution_time:.3f}s")
            print(f"   Response length: {len(response)} characters")
        
        return True
        
    except Exception as e:
        print(f"❌ Parameter variations test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_error_handling():
    """Test error handling scenarios."""
    print("\n🛡️ Testing Error Handling")
    print("=" * 40)
    
    try:
        from llm import generate_response
        
        # Test invalid input types
        print("Testing invalid input types...")
        invalid_type_passed = False
        missing_content_passed = False
        
        # Test invalid type
        response = generate_response(123)  # Invalid type
        if "[LLM Error]" in response and "Messages must be a string" in response:
            print(f"✅ Correctly handled invalid type error: {response}")
            invalid_type_passed = True
        else:
            print(f"❌ Unexpected response for invalid type: {response}")

        # Test missing content
        response = generate_response([{"invalid": "message"}])  # Missing content
        if "[LLM Error]" in response and "Messages must be a string" in response:
            print(f"✅ Correctly handled missing content error: {response}")
            missing_content_passed = True
        else:
            print(f"❌ Unexpected response for missing content: {response}")

        if invalid_type_passed and missing_content_passed:
            print("✅ All error handling tests passed")
        else:
            print("❌ Error handling test failed for invalid input cases")
            return False
        
        # Test with invalid AWS credentials (if possible)
        print("\nTesting with invalid credentials...")
        original_key = os.environ.get("AWS_ACCESS_KEY_ID")
        os.environ["AWS_ACCESS_KEY_ID"] = "invalid_key"
        
        try:
            response = generate_response("Test prompt", max_tokens=10)
            if "[LLM Error]" in response:
                print("✅ Correctly handled invalid credentials")
            else:
                print("⚠️ Unexpected response with invalid credentials")
        except Exception as e:
            print(f"✅ Correctly caught credential error: {e}")
        finally:
            if original_key:
                os.environ["AWS_ACCESS_KEY_ID"] = original_key
        
        return True
        
    except Exception as e:
        print(f"❌ Error handling test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_performance():
    """Test performance and response times."""
    print("\n⚡ Testing Performance")
    print("=" * 30)
    
    try:
        from llm import generate_response
        
        # Test multiple calls to measure consistency
        prompt = "What is the weather like today?"
        num_calls = 3
        times = []
        
        print(f"Making {num_calls} calls to measure performance...")
        
        for i in range(num_calls):
            start_time = time.time()
            response = generate_response(prompt, max_tokens=50, temperature=0.1)
            execution_time = time.time() - start_time
            times.append(execution_time)
            
            print(f"   Call {i+1}: {execution_time:.3f}s")
        
        avg_time = sum(times) / len(times)
        min_time = min(times)
        max_time = max(times)
        
        print(f"\n📊 Performance Summary:")
        print(f"   Average time: {avg_time:.3f}s")
        print(f"   Min time: {min_time:.3f}s")
        print(f"   Max time: {max_time:.3f}s")
        print(f"   Variance: {max_time - min_time:.3f}s")
        
        # Check if performance is reasonable (less than 30 seconds average)
        if avg_time < 30:
            print("✅ Performance is within acceptable range")
            return True
        else:
            print("⚠️ Performance is slower than expected")
            return False
        
    except Exception as e:
        print(f"❌ Performance test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_complex_prompts():
    """Test with more complex prompts and scenarios."""
    print("\n🧠 Testing Complex Prompts")
    print("=" * 40)
    
    try:
        from llm import generate_response
        
        # Test multi-turn conversation
        print("Testing multi-turn conversation...")
        conversation = [
            {"role": "user", "content": "I'm learning Python programming."},
            {"role": "assistant", "content": "That's great! Python is an excellent language to learn."},
            {"role": "user", "content": "What should I learn first?"}
        ]
        
        start_time = time.time()
        response = generate_response(conversation, max_tokens=150, temperature=0.0)
        execution_time = time.time() - start_time
        
        print(f"✅ Multi-turn conversation completed in {execution_time:.3f}s")
        print(f"   Response: {response[:120]}{'...' if len(response) > 120 else ''}")
        
        # Test creative writing
        print("\nTesting creative writing...")
        creative_prompt = "Write a short poem about artificial intelligence."
        
        start_time = time.time()
        response = generate_response(creative_prompt, max_tokens=200, temperature=0.8)
        execution_time = time.time() - start_time
        
        print(f"✅ Creative writing completed in {execution_time:.3f}s")
        print(f"   Response: {response[:150]}{'...' if len(response) > 150 else ''}")
        
        # Test technical explanation
        print("\nTesting technical explanation...")
        tech_prompt = "Explain how machine learning algorithms work in simple terms."
        
        start_time = time.time()
        response = generate_response(tech_prompt, max_tokens=300, temperature=0.2)
        execution_time = time.time() - start_time
        
        print(f"✅ Technical explanation completed in {execution_time:.3f}s")
        print(f"   Response: {response[:150]}{'...' if len(response) > 150 else ''}")
        
        return True
        
    except Exception as e:
        print(f"❌ Complex prompts test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_edge_cases():
    """Test edge cases and boundary conditions."""
    print("\n🔍 Testing Edge Cases")
    print("=" * 30)
    
    try:
        from llm import generate_response
        
        # Test very short prompts
        print("Testing very short prompt...")
        response = generate_response("Hi", max_tokens=10, temperature=0.1)
        print(f"✅ Short prompt response: {response}")
        
        # Test very long prompts
        print("\nTesting long prompt...")
        long_prompt = "This is a very long prompt. " * 50  # ~1500 characters
        response = generate_response(long_prompt, max_tokens=50, temperature=0.1)
        print(f"✅ Long prompt response length: {len(response)} characters")
        
        # Test minimum parameters
        print("\nTesting minimum parameters...")
        response = generate_response("Test", max_tokens=1, temperature=0.0)
        print(f"✅ Minimum parameters response: {response}")
        
        # Test maximum parameters
        print("\nTesting maximum parameters...")
        response = generate_response("Test", max_tokens=8192, temperature=1.0)
        print(f"✅ Maximum parameters response length: {len(response)} characters")
        
        return True
        
    except Exception as e:
        print(f"❌ Edge cases test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🧪 LLM Test Suite")
    print("=" * 60)
    
    # Run all tests
    tests = [
        ("Imports", test_llm_imports),
        ("Basic Functionality", test_basic_functionality),
        ("Direct API Calls", test_direct_api_calls),
        ("Parameter Variations", test_parameter_variations),
        ("Error Handling", test_error_handling),
        ("Performance", test_performance),
        ("Complex Prompts", test_complex_prompts),
        ("Edge Cases", test_edge_cases)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        print(f"\n{'='*20} {test_name} {'='*20}")
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
            results[test_name] = False
    
    # Summary
    print("\n📋 Test Summary")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name:.<30} {status}")
        if result:
            passed += 1
    
    print(f"\nOverall: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! LLM module is working correctly.")
        sys.exit(0)
    else:
        print(f"\n❌ {total - passed} test(s) failed. Please check the errors above.")
        sys.exit(1) 