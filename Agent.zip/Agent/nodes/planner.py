import json
import re
import logging
from datetime import datetime
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

from tools.registry import get_tool_registry

class PlannerNode:
    """Node responsible for planning the execution flow using only LLM."""

    def __init__(self):
        self.tool_registry = get_tool_registry()
        logger.info("Initialized LLM-based planner")

    def set_tool_registry(self, tool_registry):
        """Set the tool registry for the planner."""
        self.tool_registry = tool_registry

    def __call__(self, state: Dict[str, Any], status_callback=None) -> Dict[str, Any]:
        logger.info("Executing planner")
        updates = {}
        messages = list(state.get("messages", []))

        SYSTEM_PROMPT = """
You are Aura, the technical support core for Yubi— a fintech company with multiple fintech products. Customers raise tickets when they face issues on Yubi products. Your role is to resolve these tickets as a technical expert: always analyze and understand the business logic from the codebase, since complete product knowledge can be derived from it. Do not complain about missing documentation; instead, provide actionable solutions by reasoning directly from the implementation and business logic in the code, just as a skilled technical support engineer would.

Your primary mission is to analyze, triage, and resolve support requests by deeply investigating all available knowledge bases, codebases, and documents. You operate autonomously, using advanced search and reasoning to provide clear, actionable, and well-categorized responses.

**Knowledge Base System Overview:**
- Every product/process/domain has a dedicated Knowledge Base (KB) containing:
    - **Codebases**: One or more repositories (frontend, backend, integrations)
    - **Documents**: User guides, SOPs, API docs, and technical references
    - **Metadata**: Name, description, type (Product/SOP/Common), tags
- You can search, retrieve, and analyze any code or document within a KB. Use repository and document metadata to guide your investigation.

**Support Agent Core Workflow:**
1. **Deep Requirement Analysis**: Carefully read the user's support request. If ambiguous, identify missing details and clarify requirements.
2. **Categorization**: Assign each request to a category (e.g., Bug, Feature Request, Usage Question, Incident, RCA Required, SOP Guidance, etc.) based on the KB structure and content.
3. **Evidence-Driven Investigation**:
    - Search for the most relevant KB(s) based on the request context.
    - Use `code_search` and `document_search` to find related code, files, or documentation.
    - Always inspect the actual content (via `view_file` or document preview) before making any claims or recommendations.
    - Do NOT speculate or generate fixes without direct evidence from the KB/codebase/document.
4. **Clear Next-Step Planning**:
    - If missing information, recommend specific tool calls or clarifying questions.
    - If evidence is sufficient, summarize findings and propose a clear, concise next action.

**Prompt Engineering Rules:**
- Avoid developer-centric language; focus on support, triage, and user communication.
- Use markdown formatting for all responses:
    - Section headings for "Evidence", "Analysis", "Category", "Next Steps"
    - Bullet points for findings and recommendations
    - Code blocks only for confirmed, evidence-backed fixes or config changes
- Never fabricate evidence. If something is missing, say so and plan how to get it.
- Always cite the specific KB, codebase, or document you used for evidence.

**Example Support Workflow:**
*User Request: "A product page is crashing with a white screen."*
1. **Analyze**: Note the product or process, the symptom, and the urgency.
2. **Categorize**: Assign a category such as "Incident", "Bug", "Feature Request", or "SOP Guidance".
3. **Investigate**:
    - Search KBs for the relevant product or process and locate related codebases and documents.
    - Use `code_search` and `document_search` to find relevant code or documentation.
    - If code or document is found, use `view_file` or document preview to inspect the logic or content.
4. **Plan**:
    - If a likely root cause is found, summarize it and propose a fix (with code block, if possible).
    - If not enough info, recommend the next tool call or ask for more details.

**Your job:**
- Always ground your reasoning in KB/code/document evidence.
- Categorize, summarize, and plan next steps clearly.
- Be concise, professional, and support-focused in every response.
"""
        # Insert system prompt at the top if not already present
        if not messages or messages[0].get("role") != "system":
            messages.insert(0, {"role": "system", "content": SYSTEM_PROMPT})
        tools = getattr(self.tool_registry, 'tools', {})

        planning_prompt = self._create_planning_prompt_from_messages(messages, tools)
        
        from agent import Agent
        messages = Agent.add_message_to_list(messages, "system", f"Planning prompt: {planning_prompt}")
        
        try:
            from llm import generate_response
            max_attempts = 2
            plan = None
            last_response = None
            for attempt in range(max_attempts):
                response = generate_response(messages=messages, response_format="json")
                messages = Agent.add_message_to_list(messages, "assistant", response)
                last_response = response
                plan = None  # Always reset plan before parsing
                try:
                    match = re.search(r"```json\s*(\{[\s\S]+?\})\s*```", response)
                    if match:
                        plan = json.loads(match.group(1))
                    else:
                        match = re.search(r"(\{[\s\S]+\})", response)
                        if match:
                            plan = json.loads(match.group(1))
                        else:
                            plan = json.loads(response)
                    break  # Successfully parsed JSON
                except Exception as e:
                    logger.warning(f"Attempt {attempt+1}: Failed to parse plan as JSON: {e}")
                    plan = None  # Explicitly clear plan on failure
                    if attempt < max_attempts - 1:
                        # Ask LLM to reformat the last output as valid JSON
                        reformat_msg = (
                            "System: Your last output was not valid JSON. "
                            "Please reformat your previous response as a valid JSON object matching the required schema. "
                            "Return ONLY the JSON object, nothing else."
                        )
                        messages = Agent.add_message_to_list(messages, "system", reformat_msg)
            if not isinstance(plan, dict):
                logger.error(f"Planner failed to produce a valid plan after {max_attempts} attempts.")
                plan = {"strategy": "direct", "tool_calls": [], "execution_order": "sequential"}  # Fallback plan
                updates["output"] = last_response or "Planner failed to produce a valid plan."
                updates["response_ready"] = True
                messages = Agent.add_message_to_list(messages, "internal action no tools", last_response)
            else:
                tool_execution_plans = {
                    "strategy": plan.get("strategy", "direct"),
                    "tool_calls": plan.get("tool_calls", []),
                    "execution_order": plan.get("execution_order", "sequential")
                }
                updates["tool_execution_plans"] = tool_execution_plans
                messages = Agent.add_message_to_list(messages, "internal action planning", tool_execution_plans)
        except Exception as e:
            logger.error(f"Planner error: {e}")
            updates["output"] = "I encountered an error processing your request."
            updates["error"] = str(e)
            updates["response_ready"] = True
            messages = Agent.add_message_to_list(messages, "internal action error", f"Planner error: {str(e)}")
        
        updates["messages"] = messages
        return updates

    def _create_planning_prompt_from_messages(self, messages: list, tools: dict) -> str:
        """Create planning prompt from messages with detailed tool signatures and strict tool name constraints."""
        tool_descriptions = []
        import inspect
        for name, meta in tools.items():
            desc = meta.get("description", "")
            params = meta.get("parameters", {})
            input_model = meta.get("input_model")
            if input_model and hasattr(input_model, 'schema'):
                schema = input_model.schema()
                props = schema.get('properties', {})
                required = set(schema.get('required', []))
                param_lines = []
                for field, info in props.items():
                    typ = info.get('title', info.get('type', 'Any'))
                    req = ' [required]' if field in required else ''
                    desc_field = info.get('description', '')
                    param_lines.append(f"    {field}: {typ}{req}{' - ' + desc_field if desc_field else ''}")
                param_schema = "\n".join(param_lines)
                tool_descriptions.append(f"- {name} (parameters):\n{param_schema}\n  Description: {desc}")
            elif params:
                param_lines = [f"    {k}: {getattr(v['type'], '__name__', str(v['type']))}" for k, v in params.items()]
                param_schema = "\n".join(param_lines)
                tool_descriptions.append(f"- {name} (parameters):\n{param_schema}\n  Description: {desc}")
            else:
                tool_descriptions.append(f"- {name} (no parameters)\n  Description: {desc}")
        if tool_descriptions:
            tool_list_str = "\n".join(tool_descriptions)
        else:
            tool_list_str = "No tools available."
        prompt = (
            "You are an expert AI workflow planner. Your job is to create a step-by-step plan to solve the user's query using ONLY the available tools listed below.\n"
            "\n"
            "AVAILABLE TOOLS (use only these names):\n"
            f"{tool_list_str}\n"
            "\n"
            "IMPORTANT: You MUST ONLY use tool names exactly as listed above. Do NOT invent tool names or use tools not in the list.\n"
            "When you generate a plan, each step must use a tool_name exactly as listed above.\n"
            "\n"
            "For each step, specify the tool_name and parameters as a JSON list under 'tool_calls'.\n"
            "Return your plan as a JSON object with keys: strategy, tool_calls, execution_order.\n"
            "\n"
            "User Query: " + messages[-1]["content"]
        )
        return prompt
