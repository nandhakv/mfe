import json
import re
import logging
from datetime import datetime
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

from tools.registry import get_tool_registry

class PlannerNode:
    """Node responsible for planning the execution flow using only LLM."""

    def __init__(self):
        self.tool_registry = get_tool_registry()
        logger.info("Initialized LLM-based planner")

    def set_tool_registry(self, tool_registry):
        """Set the tool registry for the planner."""
        self.tool_registry = tool_registry

    def __call__(self, state: Dict[str, Any], status_callback=None) -> Dict[str, Any]:
        logger.info("Executing planner")
        updates = {}
        messages = list(state.get("messages", []))

        SYSTEM_PROMPT = """
You are Aura, the technical support core for Yubi—a fintech company with multiple fintech products. Customers raise tickets when they face issues on Yubi products. Your role is to resolve these tickets as a technical expert: always analyze and understand the business logic from the codebase, since complete product knowledge can be derived from it. Do not complain about missing documentation; instead, provide actionable solutions by reasoning directly from the implementation and business logic in the code, just as a skilled technical support engineer would.

**CRITICAL WORKFLOW REQUIREMENTS:**
- You MUST perform at least one knowledge base search to identify the relevant product/domain
- You MUST perform at least one code search or document search to gather technical evidence
- You MUST NOT generate a final response until technical evidence (code, docs, KB) is gathered
- Always prioritize gathering technical evidence before providing solutions
- If technical evidence is missing, your plan MUST include tool calls to gather it

**Support Agent Core Workflow:**
1. **Deep Requirement Analysis**: Carefully read the user's support request. If ambiguous, identify missing details and clarify requirements.
2. **Categorization**: Assign each request to a category (e.g., Bug, Feature Request, Usage Question, Incident, RCA Required, SOP Guidance, etc.) based on the KB structure and content.
3. **Evidence-Driven Investigation**:
    - Search for the most relevant KB(s) based on the request context.
    - Use `code_search` and `document_search` to find related code, files, or documentation.
    - Always inspect the actual content (via `view_file` or document preview) before making any claims or recommendations.
    - Do NOT speculate or generate fixes without direct evidence from the KB/codebase/document.
4. **Clear Next-Step Planning**:
    - If missing information, recommend specific tool calls or clarifying questions.
    - If evidence is sufficient, summarize findings and propose a clear, concise next action.

**Support Reasoning Principles:**
- Never stop at a pointer or reference (e.g., a file path or doc name). Always retrieve and analyze the actual content before making claims.
- Never generate a response or recommendation unless all required evidence is present from KB/code/document content.
- If anything is missing, plan the next step or clarifying question to gather it.
- Retry and refine your queries and tool choices as needed until you are satisfied you have maximized the evidence for the correct category and next action.
- Make smart, context-driven decisions about which type of evidence to seek next, and do not give up until all avenues (documentation, code, conversation, etc.) have been explored.
- Always use both code and documentation as sources of product truth. If documentation is missing or incomplete, treat the codebase as the definitive source of business logic and product behavior. Analyze the code to synthesize actionable business logic, workflows, and user-facing steps. Do not default to 'insufficient documentation' as a blocker—provide a technical, implementation-driven solution based on code analysis unless a clear blocker is evident in the code itself.
- For every solution, always provide both a business-oriented (user-facing) and a technical (developer/support) approach whenever possible.
- The business solution should include clear, step-by-step instructions for users to perform the action via UI or API, based on actual business logic in the code.
- The technical solution should include concrete steps, scripts, or code snippets showing how a developer or support engineer can solve the problem directly (e.g., via script, Rails console, or API call), referencing the relevant code and methods.
- Always explain the root cause from both business and technical perspectives.
- If possible, output a summary table of the workflow and actors involved.
- Only mention documentation gaps if neither code nor business logic provides an answer.
- Always synthesize actionable steps for both user and developer roles when code allows.

**Your job:**
- Always ground your reasoning in KB/code/document evidence.
- Categorize, summarize, and plan next steps clearly.
- Be concise, professional, and support-focused in every response.
- Ensure your plan includes the necessary tool calls to gather technical evidence before any final response generation.
"""
        # Ensure only user/assistant roles and string content
        # Add the user query as a user message if not present
        if not messages or messages[-1].get("role") != "user":
            user_query = state.get("query") or (messages[-1]["content"] if messages else "")
            messages.append({"role": "user", "content": str(user_query)})
        # Add planning prompt as user message
        tools = getattr(self.tool_registry, 'tools', {})
        planning_prompt = self._create_planning_prompt_from_messages(messages, tools)
        messages.append({"role": "user", "content": planning_prompt})
        try:
            from llm import generate_response
            max_attempts = 2
            plan = None
            last_response = None
            for attempt in range(max_attempts):
                response = generate_response(messages=messages, response_format="json")
                messages.append({"role": "assistant", "content": str(response)})
                last_response = response
                plan = None
                try:
                    match = re.search(r"```json\s*(\{[\s\S]+?\})\s*```", response)
                    if match:
                        plan = json.loads(match.group(1))
                    else:
                        match = re.search(r"(\{[\s\S]+\})", response)
                        if match:
                            plan = json.loads(match.group(1))
                        else:
                            plan = json.loads(response)
                    break  # Successfully parsed JSON
                except Exception as e:
                    logger.warning(f"Attempt {attempt+1}: Failed to parse plan as JSON: {e}")
                    plan = None  # Explicitly clear plan on failure
                    if attempt < max_attempts - 1:
                        # Ask LLM to reformat the last output as valid JSON
                        reformat_msg = (
                            "Your last output was not valid JSON. "
                            "Please reformat your previous response as a valid JSON object matching the required schema. "
                            "Return ONLY the JSON object, nothing else."
                        )
                        messages.append({"role": "user", "content": reformat_msg})
            if not isinstance(plan, dict):
                logger.error(f"Planner failed to produce a valid plan after {max_attempts} attempts.")
                plan = {"strategy": "direct", "tool_calls": [], "execution_order": "sequential"}  # Fallback plan
                updates["output"] = last_response or "Planner failed to produce a valid plan."
                updates["response_ready"] = True
                messages.append({"role": "assistant", "content": str(last_response)})
            else:
                tool_execution_plans = {
                    "strategy": plan.get("strategy", "direct"),
                    "tool_calls": plan.get("tool_calls", []),
                    "execution_order": plan.get("execution_order", "sequential")
                }
                updates["tool_execution_plans"] = tool_execution_plans
                # Add tool call plan as user message
                messages.append({"role": "user", "content": json.dumps(tool_execution_plans, indent=2)})
        except Exception as e:
            logger.error(f"Planner error: {e}")
            updates["output"] = "I encountered an error processing your request."
            updates["error"] = str(e)
            updates["response_ready"] = True
            messages.append({"role": "assistant", "content": f"Planner error: {str(e)}"})
        updates["messages"] = messages
        return updates

    def _create_planning_prompt_from_messages(self, messages: list, tools: dict) -> str:
        """Create planning prompt from messages with detailed tool signatures and strict tool name constraints."""
        tool_descriptions = []
        import inspect
        for name, meta in tools.items():
            desc = meta.get("description", "")
            params = meta.get("parameters", {})
            input_model = meta.get("input_model")
            if input_model and hasattr(input_model, 'schema'):
                schema = input_model.schema()
                props = schema.get('properties', {})
                required = set(schema.get('required', []))
                param_lines = []
                for field, info in props.items():
                    typ = info.get('title', info.get('type', 'Any'))
                    req = ' [required]' if field in required else ''
                    desc_field = info.get('description', '')
                    param_lines.append(f"    {field}: {typ}{req}{' - ' + desc_field if desc_field else ''}")
                param_schema = "\n".join(param_lines)
                tool_descriptions.append(f"- {name} (parameters):\n{param_schema}\n  Description: {desc}")
            elif params:
                param_lines = [f"    {k}: {getattr(v['type'], '__name__', str(v['type']))}" for k, v in params.items()]
                param_schema = "\n".join(param_lines)
                tool_descriptions.append(f"- {name} (parameters):\n{param_schema}\n  Description: {desc}")
            else:
                tool_descriptions.append(f"- {name} (no parameters)\n  Description: {desc}")
        if tool_descriptions:
            tool_list_str = "\n".join(tool_descriptions)
        else:
            tool_list_str = "No tools available."
        prompt = (
            "You are an expert AI workflow planner. Your job is to create a step-by-step plan to solve the user's query using ONLY the available tools listed below.\n"
            "\n"
            "AVAILABLE TOOLS (use only these names):\n"
            f"{tool_list_str}\n"
            "\n"
            "IMPORTANT: You MUST ONLY use tool names exactly as listed above. Do NOT invent tool names or use tools not in the list.\n"
            "When you generate a plan, each step must use a tool_name exactly as listed above.\n"
            "\n"
            "For each step, specify the tool_name and parameters as a JSON list under 'tool_calls'.\n"
            "Return your plan as a JSON object with keys: strategy, tool_calls, execution_order.\n"
            "\n"
            "User Query: " + messages[-1]["content"]
        )
        return prompt
