"""Base types and interfaces for agent nodes."""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, TypeVar

# --- Core Types ---

class ExecutionStrategy(str, Enum):
    """Defines different execution strategies for the agent."""
    DIRECT = "direct"  # Respond directly using LLM
    SINGLE_TOOL = "single_tool"  # Use a single tool
    MULTI_STEP = "multi_step"  # Use multiple tools in sequence or parallel

@dataclass
class ToolCall:
    """Represents a planned tool execution."""
    tool_name: str
    parameters: Dict[str, Any]
    reason: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the tool call to a dictionary."""
        return {
            "tool": self.tool_name,
            "parameters": self.parameters,
            "reason": self.reason
        }

class PlanningResult:
    """Result of the planning phase."""
    def __init__(self, strategy: ExecutionStrategy, tool_calls: List[ToolCall] = None):
        self.strategy = strategy
        self.tool_calls = tool_calls or []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the planning result to a dictionary."""
        return {
            "strategy": self.strategy.value,
            "steps": [call.to_dict() for call in self.tool_calls]
        }

# Type variable for state
try:
    from agent.state import AgentState
    StateT = TypeVar('StateT', bound=AgentState)
except ImportError:
    # Fallback in case of circular imports
    StateT = TypeVar('StateT')

class BaseNode:
    """Base class for all nodes in the agent's workflow."""
    
    async def __call__(self, state: StateT) -> StateT:
        """Process the state and return the updated state."""
        return await self.process(state)
    
    async def process(self, state: StateT) -> StateT:
        """Process the state and return the updated state.
        
        Args:
            state: The current state of the agent
            
        Returns:
            The updated state
        """
        raise NotImplementedError("Subclasses must implement process()")