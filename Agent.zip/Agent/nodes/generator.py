"""Response generator node implementation for the agent."""

import logging
from typing import Dict, Any

from llm import generate_response
from utils.message_utils import add_message_to_list
logger = logging.getLogger(__name__)


class GeneratorNode:
    """Node responsible for generating the final user-facing response."""

    def __init__(self, **kwargs):
        """Initializes the generator node."""
        pass

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Generates the final response and returns a partial state update."""
        logger.info("Executing generator node")
        updates = {}
        messages = list(state.get("messages", []))

        generation_prompt = self._create_generation_prompt()
        
        messages = add_message_to_list(messages, "system", generation_prompt)
        
        try:
            response = generate_response(messages=messages)
            # Always format the output as markdown for Streamlit UI
            import re
            def to_markdown(text):
                # Remove unwanted HTML, excessive whitespace, and non-markdown artifacts
                text = re.sub(r'<[^>]+>', '', text)  # Remove HTML tags
                text = re.sub(r'\n{3,}', '\n\n', text)  # Collapse multiple newlines
                text = text.strip()
                # If not already markdown, add basic formatting
                if not text.startswith('#'):
                    text = f"## Support Summary\n\n{text}"
                return text

            markdown_response = to_markdown(response)
            logger.info("Final Markdown Output sent via API:\n%s", markdown_response)
            updates["output"] = markdown_response
            messages = add_message_to_list(messages, "assistant", markdown_response)

            # Print LLM request stats at the very end
            try:
                from llm.llm import get_llm_request_stats
                stats = get_llm_request_stats()
                if stats:
                    logger.info("LLM Request Stats:", stats.as_dict())
            except Exception as stats_exc:
                logger.warning(f"Could not print LLM stats: {stats_exc}")

            # logger.info("final messages list: %s", messages)
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            error_msg = f"I am sorry, but I encountered an error while generating the response: {e}"
            updates["output"] = error_msg
            messages = add_message_to_list(messages, "assistant", error_msg)
            updates["error"] = str(e)
        
        updates["messages"] = messages
        updates["response_ready"] = True # Always mark as ready after generation
        return updates

    def _create_generation_prompt(self):
        return """
You are Aura, an expert AI support agent for the Yubi team. Your job is to analyze, triage, and resolve support requests using deep investigation of knowledge bases, codebases, and documents. Always provide clear, concise, and actionable responses grounded in real evidence.

**Support Agent Response Rules:**
- Categorize the request (e.g., Bug, Feature Request, Incident, Usage Question, SOP Guidance, RCA Required, etc.)
- Only make claims or suggestions based on direct evidence from KB/code/document content. Never speculate or fabricate.
- If you lack evidence, say so and recommend the next tool call or clarifying question.
- Use markdown formatting:
  - Section headings: `## Category`, `## Evidence`, `## Analysis`, `## Recommendation / Next Steps`
  - Bullet points for findings and recommendations
  - Code blocks only for confirmed, evidence-backed fixes
- Always cite the specific KB, codebase, or document used for evidence.
- Be concise, professional, and support-focused in every response.

YOUR RESPONSE:
"""