"""Tool executor node for the agent workflow."""

import logging
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor
from message_utils import append_unique_message
import inspect
import asyncio
import json

logger = logging.getLogger("agent.tool_executor")

class ToolResult:
    """Container for tool execution results."""
    
    def __init__(self, tool_name: str, parameters: Dict, result: Any = None, error: str = None):
        self.tool_name = tool_name
        self.parameters = parameters
        self.result = result
        self.error = error
    
    def to_dict(self) -> Dict:
        """Convert to dictionary representation."""
        return {
            "tool_name": self.tool_name,
            "parameters": self.parameters,
            "result": self.result,
            "error": self.error,
            "success": self.error is None
        }

class ToolExecutorNode:
    """Node responsible for executing tools in the agent's workflow."""
    
    def __init__(self):
        """Initialize the tool executor node."""
        from tools.registry import get_tool_registry
        self.registry = get_tool_registry()
        logger.info("Initialized tool executor node")
    
    import inspect
    import asyncio
    def _execute_single_tool(self, tool_name: str, params: Dict) -> "ToolResult":
        """Execute a single tool and return its result with smart retry logic."""
        max_retries = 2
        retry_delay = 1  # seconds
        
        for attempt in range(max_retries + 1):
            try:
                if tool_name not in self.registry.tools:
                    logger.error(f"Tool {tool_name} not found in registry. Available tools: {list(self.registry.tools.keys())}")
                    return ToolResult(tool_name, params, error=f"Tool {tool_name} not found in registry")

                tool_info = self.registry.tools[tool_name]
                tool_func = tool_info["function"]
                input_model = tool_info.get("input_model")

                # Coerce kb_id to string if it's an integer, a common LLM mistake
                if 'kb_id' in params and isinstance(params.get('kb_id'), int):
                    params['kb_id'] = str(params['kb_id'])

                # If the tool has an input model, create an instance of it
                if input_model:
                    model_instance = input_model(**params)
                    result = tool_func(model_instance)
                else:
                    result = tool_func(**params)

                # Await if coroutine
                if inspect.iscoroutine(result):
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        # No running event loop
                        result = asyncio.run(result)
                    else:
                        # There is a running event loop (may be in thread)
                        # Try to run the coroutine in the current loop
                        # This may still fail in some threaded contexts, but is safest
                        import nest_asyncio
                        nest_asyncio.apply()
                        result = loop.run_until_complete(result)

                return ToolResult(tool_name, params, result=result)
                
            except Exception as e:
                error_msg = f"Error executing tool {tool_name} (attempt {attempt + 1}/{max_retries + 1}): {str(e)}"
                logger.warning(error_msg)
                
                # Don't retry for certain types of errors that won't be fixed by retrying
                if "No matching knowledge bases found" in str(e) or "not found" in str(e).lower():
                    logger.info(f"Not retrying {tool_name} - error indicates no data available")
                    return ToolResult(tool_name, params, error=error_msg)
                
                if attempt < max_retries:
                    logger.info(f"Retrying tool {tool_name} in {retry_delay} seconds...")
                    import time
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.error(f"Tool {tool_name} failed after {max_retries + 1} attempts")
                    return ToolResult(tool_name, params, error=error_msg)
        
        # This should never be reached, but just in case
        return ToolResult(tool_name, params, error="Unexpected error in tool execution")

    def _make_serializable(self, obj: Any) -> Any:
        """Convert objects to JSON-serializable format."""
        if hasattr(obj, 'model_dump'):
            # Pydantic models
            return obj.model_dump()
        elif hasattr(obj, '__dict__'):
            # Custom objects with __dict__
            return obj.__dict__
        elif hasattr(obj, 'to_dict'):
            # Objects with to_dict method
            return obj.to_dict()
        elif isinstance(obj, (list, tuple)):
            return [self._make_serializable(item) for item in obj]
        elif isinstance(obj, dict):
            return {key: self._make_serializable(value) for key, value in obj.items()}
        else:
            return obj

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Executes the single tool call specified in the plan."""
        logger.info("Executing a single tool call")
        updates = {}
        messages = list(state.get("messages", []))

        plan = state.get("tool_execution_plans", {})
        tool_calls = plan.get("tool_calls", [])

        if not tool_calls:
            return {}

        # In ReAct, we only execute the first (and only) tool in the plan
        tool_call = tool_calls[0]
        tool_name = tool_call.get("tool_name")
        params = tool_call.get("parameters", {})

        logger.info(f"Executing tool: {tool_name} with params {params}")
        result = self._execute_single_tool(tool_name, params)

        # Append the result to the running list of all results
        tool_results = state.get("tool_results", [])
        tool_results.append(result.to_dict())
        updates["tool_results"] = tool_results

        from agent import Agent
        # Add tool result as user message with tool call details and result
        # Convert result to JSON-serializable format
        serializable_result = self._make_serializable(result.result)
        tool_message = json.dumps({
            "tool_name": result.tool_name,
            "parameters": result.parameters,
            "result": serializable_result,
            "error": result.error
        }, indent=2)
        messages.append({"role": "user", "content": tool_message})

        # General empty result handling for all tools
        tool_result = result.result if hasattr(result, 'result') else None
        is_empty = (
            tool_result is None or
            (isinstance(tool_result, list) and not tool_result) or
            (isinstance(tool_result, dict) and not tool_result)
        )
        if is_empty:
            messages = Agent.add_message_to_list(
                messages,
                "tool",
                f"Tool '{tool_name}' returned no results for parameters {params}."
            )

        updates["messages"] = messages
        return updates

if __name__ == "__main__":
    msg = None
    logger.info(msg or "")


