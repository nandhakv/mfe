"""Tool executor node for the agent workflow."""

import logging
from typing import Dict, Any, List, Optional
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger("agent.tool_executor")
from utils.message_utils import add_message_to_list

class ToolResult:
    """Container for tool execution results."""
    
    def __init__(self, tool_name: str, parameters: Dict, result: Any = None, error: Optional[str] = None):
        self.tool_name = tool_name
        self.parameters = parameters
        self.result = result
        self.error = error
    
    def to_dict(self) -> Dict:
        """Convert to dictionary representation."""
        return {
            "tool_name": self.tool_name,
            "parameters": self.parameters,
            "result": self.result,
            "error": self.error,
            "success": self.error is None
        }

class ToolExecutorNode:
    """Node responsible for executing tools in the agent's workflow."""
    
    def __init__(self):
        """Initialize the tool executor node."""
        from tools.registry import get_registry
        self.registry = get_registry()
        logger.info("Initialized tool executor node")
    
    def _execute_single_tool(self, tool_name: str, params: Dict) -> "ToolResult":
        """Execute a single tool and return its result."""
        try:
            # Always use the registry's call method which handles async and model conversion
            result = self.registry.call(tool_name, **params)
            return ToolResult(tool_name, params, result=result)
            
        except Exception as e:
            error_msg = f"Error executing tool {tool_name}: {str(e)}"
            logger.error(error_msg)
            return ToolResult(tool_name, params, error=error_msg)
    
    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Executes all tool calls in parallel."""
        logger.info("Executing all tool calls in parallel")
        updates = {}
        messages = list(state.get("messages", []))

        plan = state.get("tool_execution_plans", {})
        tool_calls = plan.get("tool_calls", [])

        if not tool_calls:
            return {}

        # Execute all tools in parallel
        with ThreadPoolExecutor(max_workers=len(tool_calls)) as executor:
            # Submit all tool executions
            future_to_tool = {}
            for tool_call in tool_calls:
                tool_name = tool_call.get("tool_name")
                params = tool_call.get("parameters", {})
                future = executor.submit(self._execute_single_tool, tool_name, params)
                future_to_tool[future] = tool_call
            
            # Collect all results
            all_results = []
            for future in future_to_tool:
                result = future.result()
                all_results.append(result.to_dict())
                logger.info(f"Tool {result.tool_name} completed with {'success' if result.error is None else 'error'}")

        # Append all results to the running list
        tool_results = state.get("tool_results", [])
        tool_results.extend(all_results)
        updates["tool_results"] = tool_results

        # Enhanced error and empty result handling for all tools
        for result in all_results:
            tool_name = result.get("tool_name")
            params = result.get("parameters", {})
            tool_result = result.get("result")
            error = result.get("error")
            
            # Handle tool errors
            if error:
                error_message = f"Tool '{tool_name}' failed: {error}. "
                if "timeout" in error.lower() or "connection" in error.lower():
                    error_message += "This might be a temporary issue. Try again or contact the relevant team."
                elif "not found" in error.lower() or "unauthorized" in error.lower():
                    error_message += "You may not have access to this information. Try alternative tools or contact the team."
                elif "no results" in error.lower():
                    error_message += "Try broader search terms or different knowledge bases."
                else:
                    error_message += "Consider using alternative tools or contacting the relevant team."
                messages = add_message_to_list(messages, "assistant", error_message)
            
            # Handle empty results
            is_empty = (
                tool_result is None or
                (isinstance(tool_result, list) and not tool_result) or
                (isinstance(tool_result, dict) and not tool_result)
            )
            if is_empty and not error:
                empty_message = f"Tool '{tool_name}' returned no results for parameters {params}. "
                empty_message += "This could mean: 1) The information doesn't exist, 2) Try different search terms, 3) Check if you're searching in the right knowledge base."
                messages = add_message_to_list(messages, "assistant", empty_message)
            
            # Add successful tool results to messages (include actual data)
            if not error and not is_empty:
                # Include the actual tool result data in the message
                success_message = f"Tool '{tool_name}' completed successfully. Result: {tool_result}"
                messages = add_message_to_list(messages, "assistant", success_message)
                logger.info(f"=== DEBUG: Added tool result to messages ===")
                logger.info(f"Tool: {tool_name}")
                logger.info(f"Result: {tool_result}")
                logger.info(f"=== END DEBUG ===")

        updates["messages"] = messages
        return updates


