import json
from typing import Dict, Any, Optional
from llm import generate_response
from utils.logging_utils import logger

class ReflectNode:
    """The central reasoning node for the ReAct agent. It decides the next single action."""

    def __init__(self, **kwargs):
        logger.info("Initialized ReAct-style reflect node")
        self._cached_prompt = None
        self._cached_tools_hash = None

    def _extract_json_from_response(self, response: str) -> Dict[str, Any]:
        """Extracts the first valid JSON object from a string, ignoring extra trailing data and attempting to recover from truncation."""
        import json
        import re

        # Clean up common markdown artifacts
        if "```json" in response:
            response = response.split("```json")[1].split("```")[0]

        start_pos = response.find('{')
        if start_pos == -1:
            logger.error(f"No JSON object start found in response: {response}")
            return {"decision": "generate", "reason": "No JSON found in reflection."}

        # First, try to find a complete JSON object using bracket matching
        depth = 0
        end_pos = -1
        for i in range(start_pos, len(response)):
            if response[i] == '{':
                depth += 1
            elif response[i] == '}':
                depth -= 1
                if depth == 0:
                    end_pos = i + 1
                    break
        
        if end_pos != -1:
            json_candidate = response[start_pos:end_pos]
            try:
                parsed = json.loads(json_candidate)
                if len(response) > end_pos and response[end_pos:].strip():
                    logger.warning(f"Ignoring extra data after valid JSON object: {response[end_pos:].strip()[:200]}...")
                return parsed
            except json.JSONDecodeError as e:
                logger.warning(f"Found a seemingly complete JSON object, but parsing failed: {e}. Will attempt recovery.")

        # If that fails, it's likely truncated. Enter repair mode.
        logger.warning("Could not find a complete JSON object. Attempting to repair truncated response.")
        json_candidate = response[start_pos:].strip()
        
        for i in range(15): # Try adding up to 15 closing braces/quotes
            try:
                parsed = json.loads(json_candidate)
                logger.warning(f"Successfully parsed JSON after {i+1} repair attempt(s). The original response was likely truncated.")
                return parsed
            except json.JSONDecodeError as e:
                if "Unexpected end of data" in str(e):
                    json_candidate += '}'
                elif "Unterminated string" in str(e):
                    json_candidate += '"}'
                else:
                    logger.error(f"JSON parsing failed with a non-truncation error: {e}. Original candidate: {response[start_pos:]}")
                    break

        logger.error(f"All attempts to parse/fix the JSON response failed. Original response: {response}")
        return {"decision": "generate", "reason": "Could not parse a valid JSON object from the LLM response."}

    def _extract_tool_call_from_raw_response(self, response: str) -> Optional[Dict[str, Any]]:
        """Extract tool call information from raw response even if JSON is malformed."""
        import re
        
        logger.info(f"Attempting to extract tool call from raw response: {response[:200]}...")
        
        # Try to extract tool call using regex patterns
        patterns = [
            r"'tool_name':\s*'([^']+)'",
            r'"tool_name":\s*"([^"]+)"',
            r'tool_name["\']?\s*:\s*["\']([^"\']+)["\']',
            r'parameters["\']?\s*:\s*\{([^}]+)\}',
            r'parameters["\']?\s*:\s*\{([^}]*)\}'
        ]
        
        tool_name = None
        parameters = {}
        
        # Extract tool name
        for pattern in patterns[:3]:
            match = re.search(pattern, response)
            if match:
                tool_name = match.group(1)
                logger.info(f"Found tool name: {tool_name}")
                break
        
        # Extract parameters (simplified - just look for key-value pairs)
        param_patterns = [
            r"'([^']+)':\s*'([^']*)'",
            r'"([^"]+)":\s*"([^"]*)"',
            r"'([^']+)':\s*([^,}]+)",
            r'"([^"]+)":\s*([^,}]+)'
        ]
        
        for pattern in param_patterns:
            matches = re.findall(pattern, response)
            for key, value in matches:
                # Clean up the value
                value = value.strip().strip('"\'')
                if value.lower() not in ['none', 'null', '']:
                    parameters[key] = value
        
        logger.info(f"Extracted parameters: {parameters}")
        
        if tool_name:
            logger.info(f"Extracted tool call from malformed JSON: {tool_name} with params {parameters}")
            return {
                "decision": "call_tool",
                "reason": "Extracted tool call from malformed JSON response",
                "tool_call": {
                    "tool_name": tool_name,
                    "parameters": parameters
                }
            }
        else:
            logger.warning("No tool name found in malformed JSON response")
        
        return None

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Decides the next single action and returns a partial state update."""
        logger.info("Executing reflection to decide next action")
        updates = {}
        messages = list(state.get("messages", []))
        
        # Optimize message history to prevent token bloat
        messages = self._optimize_message_history(messages)
        
        # Add reflection prompt as user message
        prompt = self._create_reflection_prompt()
        messages.append({"role": "user", "content": str(prompt)})
        try:
            response = generate_response(messages=messages, response_format="json")
            reflection = self._extract_json_from_response(response)
            
            # If JSON parsing failed, try to extract tool call from raw response
            if reflection.get("decision") == "generate" and "Could not parse" in reflection.get("reason", ""):
                logger.warning("JSON parsing failed, attempting to extract tool call from raw response")
                extracted_tool_call = self._extract_tool_call_from_raw_response(response)
                if extracted_tool_call:
                    logger.info(f"Successfully extracted tool call: {extracted_tool_call}")
                    reflection = extracted_tool_call
                else:
                    logger.warning("Could not extract tool call from raw response, attempting JSON reformat")
                    # Ask LLM to reformat as valid JSON
                    reformat_msg = (
                        "Your response was not valid JSON. Please reformat your response as a valid JSON object with the exact schema:\n"
                        "{\n"
                        '  "thought": "your reasoning",\n'
                        '  "decision": "call_tool" or "generate",\n'
                        '  "reason": "explanation",\n'
                        '  "tool_call": {\n'
                        '    "tool_name": "tool_name",\n'
                        '    "parameters": {"param": "value"}\n'
                        '  }\n'
                        "}\n"
                        "Use double quotes for all strings and ensure valid JSON syntax."
                    )
                    messages.append({"role": "user", "content": reformat_msg})
                    try:
                        retry_response = generate_response(messages=messages, response_format="json")
                        reflection = self._extract_json_from_response(retry_response)
                    except Exception as retry_e:
                        logger.error(f"Retry also failed: {retry_e}")
                        reflection = {"decision": "generate", "reason": "Failed to get valid JSON after retry"}
            
            logger.info(f"Reflection result: {reflection}")
            messages.append({"role": "assistant", "content": str(reflection)})
            updates["messages"] = messages
            decision = reflection.get("decision", "generate").lower()
            if decision == "call_tool" and reflection.get("tool_call"):
                logger.info(f"Decision: Call tool. Reason: {reflection.get('reason')}")
                updates["tool_execution_plans"] = {"tool_calls": [reflection["tool_call"]]}
                updates["last_reflection_decision"] = "call_tool"
                # Add tool call as user message
                messages.append({"role": "user", "content": json.dumps(reflection["tool_call"], indent=2)})
            else:
                logger.info(f"Decision: Generate response. Reason: {reflection.get('reason')}")
                updates["last_reflection_decision"] = "generate"
        except Exception as e:
            logger.error(f"FATAL: Error during reflection: {e}")
            updates["error"] = str(e)
            updates['last_reflection_decision'] = "generate"
            messages.append({"role": "assistant", "content": f"Reflection error: {str(e)}"})
        return updates

    def _create_reflection_prompt(self) -> str:
        """Creates a concise reflection prompt focused only on decision-making."""
        # Check if we can reuse cached prompt
        from tools.registry import get_tool_registry
        tool_registry = get_tool_registry()
        tools = getattr(tool_registry, 'tools', {})
        
        # Create a hash of the tools to check if they've changed
        tools_hash = hash(frozenset((name, meta.get('description', '')) for name, meta in tools.items()))
        
        if self._cached_prompt and self._cached_tools_hash == tools_hash:
            return self._cached_prompt
        
        # Build tools section
        tool_lines = []
        for name, meta in tools.items():
            desc = meta.get('description', '')
            tool_lines.append(f"- {name}: {desc}")
        tools_section = '\n'.join(tool_lines) if tool_lines else 'No tools available.'

        prompt = f"""
You are Aura, a technical support agent. Based on the conversation history, decide the next action.

**AVAILABLE TOOLS:**
{tools_section}

**Decision Rules:**
- If you need more technical evidence (code, docs, KB), call a tool
- If you have sufficient evidence to provide a solution, generate a response
- Always prioritize gathering technical evidence before generating final answers
- Use the most relevant tool for the current context

**STRICT OUTPUT FORMAT:**
Respond ONLY with valid JSON:
{{
  "thought": "Brief reasoning about what evidence is present/missing",
  "decision": "call_tool" or "generate",
  "reason": "Why this decision",
  "tool_call": {{
    "tool_name": "tool_name",
    "parameters": {{"param": "value"}}
  }}
}}
"""
        
        # Cache the prompt and tools hash
        self._cached_prompt = prompt
        self._cached_tools_hash = tools_hash
        
        return prompt

    def _optimize_message_history(self, messages: list) -> list:
        """Optimize message history to prevent token bloat while preserving context."""
        if len(messages) <= 10:  # Keep all messages if under threshold
            return messages

        # Keep the first few messages (system context)
        optimized = messages[:3]

        # Keep the last few messages (recent context)
        optimized.extend(messages[-7:])

        # Add a summary message if we removed many messages
        if len(messages) > 10:
            removed_count = len(messages) - len(optimized)
            summary_msg = {
                "role": "system",
                "content": f"Note: {removed_count} intermediate messages were removed to optimize token usage. Focus on the most recent context."
            }
            optimized.insert(3, summary_msg)

        return optimized
