import json
import re
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

from tools.registry import get_registry
from utils.message_utils import add_message_to_list

class ReflectNode:
    """The central reasoning node for the ReAct agent. It decides the next single action."""

    def __init__(self, **kwargs):
        logger.info("Initialized ReAct-style reflect node")



    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Reflect on tool results and decide the next single action, enforcing strict sequential logic and no placeholders."""
        logger.info("Executing reflection to decide next action")
        updates = {}
        messages = list(state.get("messages", []))
        
        # Step 1: Add system message with reflection prompt
        system_message = self._create_reflection_prompt()
        messages = add_message_to_list(messages, "system", system_message)
        
        # Step 2: Invoke LLM
        try:
            from llm import generate_response
            from constants import DEFAULT_TEMPERATURE
            response = generate_response(messages=messages, temperature=DEFAULT_TEMPERATURE)
            
            logger.info(f"Raw reflection response: {response}")
            
            # Step 3: Save LLM response to messages (single source of truth)
            messages = add_message_to_list(messages, "assistant", response)
            
            # Step 4: Parse response and extract plan
            plan = self._parse_llm_response(response)
            
            # Step 5: Extract tool call logic (only one per step, no placeholders)
            tool_call = None
            
            # Check if there's a direct tool_call field
            if plan and "tool_call" in plan and isinstance(plan["tool_call"], dict):
                tool_call = plan["tool_call"]
                logger.info(f"Found direct tool_call in response: {tool_call['tool_name']}")
            # Check if there's a tool_calls list
            elif plan and "tool_calls" in plan:
                if isinstance(plan["tool_calls"], list) and len(plan["tool_calls"]) > 0:
                    tool_call = plan["tool_calls"][0]  # Only take the first tool call
                    logger.info(f"Found tool_call in tool_calls list: {tool_call['tool_name']}")
            
            # Check decision field
            decision = plan.get("decision", "").lower() if plan else ""
            
            # Process the tool call if we have one
            if tool_call:
                # Check for placeholder values in tool call parameters
                if any(isinstance(v, str) and "from_previous_search" in v 
                        for v in tool_call.get("parameters", {}).values()):
                    logger.warning("Tool call contains placeholder value. Forcing fallback to knowledge_base_search.")
                    last_user_message = next((m['content'] for m in reversed(messages) if m['role'] == 'user'), '')
                    updates["tool_execution_plans"] = {"tool_calls": [{
                        "tool_name": "knowledge_base_search",
                        "parameters": {"query": last_user_message}
                    }]}
                else:
                    updates["tool_execution_plans"] = {"tool_calls": [tool_call]}
                
                updates["last_reflection_decision"] = "call_tool"
                logger.info(f"Reflection decided to execute tool: {tool_call['tool_name']}")
            elif decision == "call_tool":
                # Decision says call_tool but no tool_call found
                logger.warning("Decision is call_tool but no valid tool_call found. Forcing fallback to knowledge_base_search.")
                last_user_message = next((m['content'] for m in reversed(messages) if m['role'] == 'user'), '')
                updates["tool_execution_plans"] = {"tool_calls": [{
                    "tool_name": "knowledge_base_search",
                    "parameters": {"query": last_user_message}
                }]}
                updates["last_reflection_decision"] = "call_tool"
            else:
                # No tool calls, proceed to generation
                logger.info(f"Decision: Generate response. Reason: {plan.get('reason') if plan else 'No plan generated'}")
                updates["last_reflection_decision"] = "generate"

        except Exception as e:
            logger.error(f"Reflection error: {e}")
            error_msg = f"I encountered an error processing your request: {str(e)}"
            messages = add_message_to_list(messages, "assistant", error_msg)
            updates["error"] = str(e)
            
            # On JSON parsing errors, fallback to knowledge_base_search
            if "Invalid JSON response" in str(e) or "Failed to decode JSON" in str(e):
                logger.warning("JSON parsing error detected. Forcing fallback to knowledge_base_search.")
                last_user_message = next((m['content'] for m in reversed(messages) if m['role'] == 'user'), '')
                updates['last_reflection_decision'] = "call_tool"
                updates["tool_execution_plans"] = {"tool_calls": [{
                    "tool_name": "knowledge_base_search",
                    "parameters": {"query": last_user_message}
                }]}
            else:
                logger.warning("Non-JSON error detected during reflection. Falling back to generation.")
                updates['last_reflection_decision'] = "generate"
        
        # Always update messages as the single source of truth
        updates["messages"] = messages
        return updates

    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """Parse the LLM response to extract the reflection plan."""
        plan = None
        
        # Try to extract JSON from markdown code block
        match = re.search(r"```json\s*(\{[\s\S]+?\})\s*```", response)
        if match:
            try:
                plan = json.loads(match.group(1))
                return plan
            except Exception as e:
                logger.warning(f"Failed to parse markdown-wrapped JSON: {e}")
        
        # Try to parse the entire response as JSON
        try:
            plan = json.loads(response)
            return plan
        except Exception as e:
            logger.warning(f"Failed to parse direct JSON: {e}")
        
        # Try to extract JSON using regex
        match = re.search(r"(\{[\s\S]+\})", response)
        if match:
            try:
                plan = json.loads(match.group(1))
                return plan
            except Exception as e:
                logger.warning(f"Failed to parse fallback JSON: {e}")
        
        logger.error(f"Could not parse LLM response as JSON: {response}")
        return {}
    
    def _create_reflection_prompt(self) -> str:
        """Creates the ReAct-style reflection prompt with available tools and strict JSON-only output enforcement."""
        # Access tools from the registry
        tools = {}
        tool_registry = get_registry()
        if hasattr(tool_registry, '_tools'):
            tools = tool_registry._tools
        elif hasattr(tool_registry, 'list_tools'):
            tool_list = tool_registry.list_tools()
            tools = {tool['name']: tool for tool in tool_list}
        
        # Import tool definitions directly from tools package
        from tools import get_tool_list
        
        tool_list = get_tool_list()
        tool_list_str = json.dumps(tool_list, indent=2)

        prompt = """
<Role>
You are Aura, the technical support core for Yubi—a fintech company with multiple fintech products. Your role is to resolve support tickets by analyzing code, documentation, and business logic.
</Role>

<AVAILABLE TOOLS>
{0}
</AVAILABLE TOOLS>

<CRITICAL REFLECTION RULES>
- **SINGLE TOOL CALL ONLY**: You MUST only plan and execute ONE tool call at a time. This is critical for sequential reasoning.
- **NO PLACEHOLDER VALUES**: You MUST NEVER use placeholder values for parameters (e.g., "knowledge_base_id": "kb_from_previous_search"). If you don't have a required ID, use knowledge_base_search with a semantic query.
- **STRICT JSON OUTPUT**: Your response MUST be valid JSON with this exact schema:
```json
{{
  "reasoning": "Your step-by-step reasoning about the current state and what information is needed next",
  "decision": "call_tool OR generate",
  "tool_call": {{
    "tool_name": "name_of_tool_to_call",
    "parameters": {{
      "param1": "value1",
      "param2": "value2"
    }}
  }}
}}
```
</CRITICAL REFLECTION RULES>

<Reflection Workflow>
1. **Analyze Current State**: Review all messages, tool results, and ticket information.
2. **Identify Missing Information**: Determine what specific information is still needed.
3. **Plan Next Single Step**: Choose ONE tool to call that will provide the most valuable information.
4. **Generate Semantic Queries**: For search tools, create precise, context-rich queries.
5. **Decide When Complete**: When you have all necessary information, set decision to "generate".
</Reflection Workflow>

<Evidence-Based Reasoning>
- Never stop at a pointer or reference (e.g., file path). Always retrieve actual content.
- Never generate a response unless all required evidence is present.
- If anything is missing, plan the next single tool call to gather it.
- Retry and refine queries as needed to maximize evidence quality.
- Use both code and documentation as sources of product truth.
- If documentation is missing, treat the codebase as the definitive source.
</Evidence-Based Reasoning>

Remember: Your output MUST be valid JSON following the schema above. No markdown, no explanations outside the JSON.
"""
        return prompt.format(tool_list_str)
