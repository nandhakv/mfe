import json
from typing import Dict, Any
from llm import generate_response
from utils.logging_utils import logger

class ReflectNode:
    """The central reasoning node for the ReAct agent. It decides the next single action."""

    def __init__(self, **kwargs):
        logger.info("Initialized ReAct-style reflect node")

    def _extract_json_from_response(self, response: str) -> Dict[str, Any]:
        """Extracts the first valid JSON object from a string, ignoring extra trailing data and attempting to recover from truncation."""
        import json
        import re

        # Clean up common markdown artifacts
        if "```json" in response:
            response = response.split("```json")[1].split("```")[0]

        start_pos = response.find('{')
        if start_pos == -1:
            logger.error(f"No JSON object start found in response: {response}")
            return {"decision": "generate", "reason": "No JSON found in reflection."}

        # First, try to find a complete JSON object using bracket matching
        depth = 0
        end_pos = -1
        for i in range(start_pos, len(response)):
            if response[i] == '{':
                depth += 1
            elif response[i] == '}':
                depth -= 1
                if depth == 0:
                    end_pos = i + 1
                    break
        
        if end_pos != -1:
            json_candidate = response[start_pos:end_pos]
            try:
                parsed = json.loads(json_candidate)
                if len(response) > end_pos and response[end_pos:].strip():
                    logger.warning(f"Ignoring extra data after valid JSON object: {response[end_pos:].strip()[:200]}...")
                return parsed
            except json.JSONDecodeError as e:
                logger.warning(f"Found a seemingly complete JSON object, but parsing failed: {e}. Will attempt recovery.")

        # If that fails, it's likely truncated. Enter repair mode.
        logger.warning("Could not find a complete JSON object. Attempting to repair truncated response.")
        json_candidate = response[start_pos:].strip()
        
        for i in range(15): # Try adding up to 15 closing braces/quotes
            try:
                parsed = json.loads(json_candidate)
                logger.warning(f"Successfully parsed JSON after {i+1} repair attempt(s). The original response was likely truncated.")
                return parsed
            except json.JSONDecodeError as e:
                if "Unexpected end of data" in str(e):
                    json_candidate += '}'
                elif "Unterminated string" in str(e):
                    json_candidate += '"}'
                else:
                    logger.error(f"JSON parsing failed with a non-truncation error: {e}. Original candidate: {response[start_pos:]}")
                    break

        logger.error(f"All attempts to parse/fix the JSON response failed. Original response: {response}")
        return {"decision": "generate", "reason": "Could not parse a valid JSON object from the LLM response."}

    def __call__(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Decides the next single action and returns a partial state update."""
        logger.info("Executing reflection to decide next action")
        updates = {}
        messages = list(state.get("messages", []))
        prompt = self._create_reflection_prompt()
        messages.append({"role": "system", "content": prompt})

        try:
            response = generate_response(messages=messages, response_format="json")
            reflection = self._extract_json_from_response(response)
            logger.info(f"Reflection result: {reflection}")

            from agent import Agent
            messages = Agent.add_message_to_list(messages, "internal reflection", reflection)
            updates["messages"] = messages

            decision = reflection.get("decision", "generate").lower()

            if decision == "call_tool" and reflection.get("tool_call"):
                logger.info(f"Decision: Call tool. Reason: {reflection.get('reason')}")
                updates["tool_execution_plans"] = {"tool_calls": [reflection["tool_call"]]}
                updates["last_reflection_decision"] = "call_tool"
            else:
                logger.info(f"Decision: Generate response. Reason: {reflection.get('reason')}")
                updates["last_reflection_decision"] = "generate"

        except Exception as e:
            logger.error(f"FATAL: Error during reflection: {e}")
            updates["error"] = str(e)

            # CRITICAL FIX: On JSON parsing errors, DO NOT generate. Continue the investigation.
            if "Invalid JSON response" in str(e) or "Failed to decode JSON" in str(e):
                logger.warning("JSON parsing error detected. Forcing 'call_tool' to continue investigation.")
                updates['last_reflection_decision'] = "call_tool"
                
                # As a robust fallback, create a new search query based on the original user request.
                last_user_message = next((m['content'] for m in reversed(state.get("messages", [])) if m['role'] == 'user'), '')
                if last_user_message:
                    logger.info(f"Using fallback search query: {last_user_message}")
                    updates["tool_execution_plans"] = {"tool_calls": [{
                        "tool_name": "knowledge_base_search",
                        "parameters": {"query": last_user_message}
                    }]}
                else:
                    # If all else fails, generate to avoid an infinite loop.
                    updates['last_reflection_decision'] = "generate"
            
            # For any other type of exception, fallback to generation.
            else:
                logger.warning("Non-JSON error detected during reflection. Falling back to generation.")
                updates['last_reflection_decision'] = "generate"

        return updates

    def _create_reflection_prompt(self) -> str:
        """Creates the ReAct-style reflection prompt with available tools and strict JSON-only output enforcement."""
        # Dynamically build the available tools section from the tool registry
        from tools.registry import get_tool_registry
        tool_registry = get_tool_registry()
        tools = getattr(tool_registry, 'tools', {})
        tool_lines = []
        for name, meta in tools.items():
            desc = meta.get('description', '')
            tool_lines.append(f"- {name}: {desc}")
        tools_section = '\n'.join(tool_lines) if tool_lines else 'No tools available.'

        return f"""
You are Aura, the technical support core for Yubi—a fintech company with multiple fintech products. Customers raise tickets when they face issues on Yubi products. Your role is to resolve these tickets as a technical expert: always analyze and understand the business logic from the codebase, since complete product knowledge can be derived from it. Do not complain about missing documentation; instead, provide actionable solutions by reasoning directly from the implementation and business logic in the code, just as a skilled technical support engineer would.

**AVAILABLE TOOLS:**
{tools_section}

You MUST only select tools from the AVAILABLE TOOLS list below. Do NOT invent or reference any tool not listed here.

**Reflection Workflow for Support:**
1. **Intention Analysis & Requirement Assessment**: Carefully review the latest user message, ticket details, and conversation history. Analyze the query or ticket to understand the user's or customer's intention—whether they are requesting a specific action (such as performing an operation, updating a status, or triggering a process), seeking an explanation, or asking for a root cause analysis. Always begin by summarizing and explaining both the intention and the context of the ticket in your own words, to demonstrate understanding. Additionally, always consider and reason about why the user may be unable to perform the requested action themselves (e.g., business logic, permissions, technical blockers, UI limitations, etc.), and include this reasoning in your response.

2. **Semantic Query Generation**: For every search or retrieval tool (knowledge base, code, document), synthesize the most relevant, context-rich semantic query possible. Do NOT simply pass the ticket title or description—combine all available information (ticket fields, conversation, prior tool results, emails, etc,...) to generate a precise, meaningful search query that maximizes the chance of finding the root cause or answer.
3. **Evidence Check**: For each required piece of information (e.g., knowledge base, codebase, document, code content, SOP), state if it is 'Present' or 'Missing' in the conversation.
4. **Support Reasoning Principles:**
    - Never stop at a pointer or reference (e.g., a file path or doc name). Always retrieve and analyze the actual content before making claims.
    - Never generate a response or recommendation unless all required evidence is present from KB/code/document content.
    - If anything is missing, plan the next step or clarifying question to gather it.
    - Retry and refine your queries and tool choices as needed until you are satisfied you have maximized the evidence for the correct category and next action.
    - Make smart, context-driven decisions about which type of evidence to seek next, and do not give up until all avenues (documentation, code, conversation, etc.) have been explored.
    - Always use both code and documentation as sources of product truth. If documentation is missing or incomplete, treat the codebase as the definitive source of business logic and product behavior. Analyze the code to synthesize actionable business logic, workflows, and user-facing steps. Do not default to 'insufficient documentation' as a blocker—provide a technical, implementation-driven solution based on code analysis unless a clear blocker is evident in the code itself.
    - For every solution, always provide both a business-oriented (user-facing) and a technical (developer/support) approach whenever possible.
    - The business solution should include clear, step-by-step instructions for users to perform the action via UI or API, based on actual business logic in the code.
    - The technical solution should include concrete steps, scripts, or code snippets showing how a developer or support engineer can solve the problem directly (e.g., via script, Rails console, or API call), referencing the relevant code and methods.
    - Always explain the root cause from both business and technical perspectives.
    - If possible, output a summary table of the workflow and actors involved.
    - Only mention documentation gaps if neither code nor business logic provides an answer.
    - Always synthesize actionable steps for both user and developer roles when code allows.
5. **Action Decision & Solution Proposal**: Based on your assessment, decide the next action:
    - If any required evidence is missing, your decision MUST be to gather more evidence or clarify requirements using one of the available tools above.
    - If all evidence is present, your decision can be to generate a response.
    - If the user's intention is to request a specific action, before providing step-by-step instructions, analyze and explain any possible reasons (business rules, permission issues, technical blockers, or UI limitations) that might prevent the user from performing the action themselves. Only then reply with clear, step-by-step instructions on how to perform that action (using UI, API, scripts, etc.) based on the available evidence. If the intention is to seek an explanation or root cause, provide a relevant, evidence-based answer. If the business or technical flow is unclear, clearly state what is missing and what concrete next evidence or clarification is required.
    - Always respond as a technical expert, providing both technical insight and actionable steps, and flagging any blockers or special conditions if found.
    - Always make your reply directly relevant to the user's intention as inferred from the query or ticket details.
    - All categorization MUST be one of: Data update, Bug, New feature, Product misunderstanding. Do not use any other category.

**IMPORTANT**
Move to generate only if you tried all possible ways like retrying tools with different parameters or different tools.
Do not make decision only on assumptions.

**STRICT OUTPUT INSTRUCTION:**
Respond ONLY with a single valid JSON object matching the schema below. Do NOT include any explanation, markdown, or extra text. The JSON object MUST include the keys: thought, decision, reason, and tool_call (if a tool should be called). Never include markdown, code blocks, or explanations outside the JSON. Your entire response must be a single, complete JSON object.

```json
{{
  "thought": "A brief summary of your assessment, explaining what is present and what is missing.",
  "decision": "call_tool | generate",
  "reason": "A brief but clear explanation of why you chose this action.",
  "tool_call": {{
    "parameters": {{
      "param1": "value1",
      "param2": "value2"
    }}
  }}
}}
```
"""
