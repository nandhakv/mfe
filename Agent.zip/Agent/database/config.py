"""
Database configuration settings.
"""
import os
from constants import (
    DEFAULT_DB_URL,
    DB_POOL_SIZE,
    DB_MAX_OVERFLOW,
    DB_POOL_RECYCLE,
    ECHO_SQL
)

class DatabaseConfig:
    """Database configuration parameters."""
    
    # Database connection URL
    URL: str = DEFAULT_DB_URL
    
    # Connection pool settings
    POOL_SIZE: int = DB_POOL_SIZE
    MAX_OVERFLOW: int = DB_MAX_OVERFLOW
    POOL_RECYCLE: int = DB_POOL_RECYCLE
    
    # Enable SQL query logging
    ECHO_SQL: bool = ECHO_SQL
    POOL_RECYCLE: int = int(os.getenv("DB_POOL_RECYCLE", "3600"))