# database/__init__.py
from .connection import Database, get_database

__all__ = ['Database', 'get_database']