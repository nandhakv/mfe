# database/connection.py
import os
from typing import Optional, Generator, Any, Dict
from contextlib import contextmanager
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session

from constants import (
    DEFAULT_DB_URL,
    DB_POOL_SIZE,
    DB_MAX_OVERFLOW,
    DB_POOL_RECYCLE,
    ECHO_SQL
)

logger = logging.getLogger(__name__)

from sqlalchemy import select, func, desc
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Session
import numpy as np

from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager

class Database:
    def get_knowledge_base_info(self, kb_ids):
        if not kb_ids:
            return []
        from sqlalchemy import text
        with self.session_factory() as session:
            stmt = text('''
                SELECT id, name, description FROM knowledge_bases WHERE id = ANY(:kb_ids)
            ''')
            result = session.execute(stmt, {"kb_ids": kb_ids}).fetchall()
            return [(row.name, row.description, str(row.id)) for row in result]


    def search_documents_across_kbs(self, query_embedding, limit):
        """
        Search all document_chunks for the most relevant chunks to the query embedding, across all knowledge bases.
        """
        from sqlalchemy import text
        # Convert numpy array to list if needed
        if hasattr(query_embedding, "tolist"):
            query_embedding = query_embedding.tolist()
        with self.session_factory() as session:
            stmt = text("""
                SELECT id, knowledge_base_id, document_id, text, 
                       (1 - (embedding <#> CAST(:embedding AS vector))) AS score
                FROM document_chunks
                ORDER BY score DESC
                LIMIT :limit
            """)
            result = session.execute(stmt, {"embedding": query_embedding, "limit": limit})
            rows = result.fetchall()
            return [
                {
                    "id": str(row.id),
                    "kb_id": str(row.knowledge_base_id),
                    "document_id": str(row.document_id),
                    "text": row.text,
                    "score": row.score
                }
                for row in rows
            ]

    def __init__(self, db_url: Optional[str] = None):
        """
        Initialize database connection.
        
        Args:
            db_url: Database connection URL. If not provided, will use DATABASE_URL from environment.
        """
        self.db_url = db_url or os.getenv("DATABASE_URL")
        if not self.db_url:
            raise ValueError("Database URL is required. Set DATABASE_URL environment variable.")
        
        engine_kwargs = {
            "echo": ECHO_SQL,
            "pool_pre_ping": True,
            "pool_recycle": DB_POOL_RECYCLE,
        }
        # Only add pool_size and max_overflow for non-SQLite databases
        if not self.db_url.startswith("sqlite"):
            engine_kwargs["pool_size"] = DB_POOL_SIZE
            engine_kwargs["max_overflow"] = DB_MAX_OVERFLOW
        self.engine = create_engine(
            self.db_url,
            **engine_kwargs
        )
        
        # Create a thread-safe session factory
        self.session_factory = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine
        )

    def search_knowledge_bases(self, query_embedding, threshold=0.5, limit=5, type: str = ""):
        """
        Find knowledge bases whose document chunks are most similar to the query embedding.
        Returns a list of (name, description, kb_id)
        """
        from sqlalchemy import text
        # Convert numpy array to list if needed
        if hasattr(query_embedding, "tolist"):
            query_embedding = query_embedding.tolist()
        with self.session_factory() as session:
            # Find top knowledge_base_ids by max similarity among their document_chunks
            stmt = text('''
                SELECT knowledge_base_id, MAX(1 - (embedding <#> CAST(:embedding AS vector))) AS max_score
                FROM document_chunks
                GROUP BY knowledge_base_id
                ORDER BY max_score DESC
                LIMIT :limit
            ''')
            result = session.execute(stmt, {"embedding": query_embedding, "limit": limit})
            kb_scores = result.fetchall()
            kb_ids = [row.knowledge_base_id for row in kb_scores if row.max_score >= threshold]
            if not kb_ids:
                return []
            if type:
                kb_stmt = text('''
                    SELECT id, name, description FROM knowledge_bases WHERE id = ANY(:kb_ids) AND type = :type
                ''')
                kb_results = session.execute(kb_stmt, {"kb_ids": kb_ids, "type": type}).fetchall()
            else:
                kb_stmt = text('''
                    SELECT id, name, description FROM knowledge_bases WHERE id = ANY(:kb_ids)
                ''')
                kb_results = session.execute(kb_stmt, {"kb_ids": kb_ids}).fetchall()
            return [(row.name, row.description, str(row.id)) for row in kb_results]

    def search_documents(self, kb_id, query_embedding, limit=5, threshold=0.5):
        """
        Find document chunks most similar to the query embedding, optionally restricted to a knowledge base.
        Returns a list of dicts for each chunk.
        """
        from sqlalchemy import text
        # Convert numpy array to list if needed
        if hasattr(query_embedding, "tolist"):
            query_embedding = query_embedding.tolist()
        with self.session_factory() as session:
            if kb_id:
                stmt = text('''
                    SELECT id, knowledge_base_id, document_id, text, (1 - (embedding <#> CAST(:embedding AS vector))) AS score
                    FROM document_chunks
                    WHERE knowledge_base_id = :kb_id
                    ORDER BY score DESC
                    LIMIT :limit
                ''')
                result = session.execute(stmt, {"embedding": query_embedding, "kb_id": kb_id, "limit": limit})
            else:
                stmt = text('''
                    SELECT id, knowledge_base_id, document_id, text, (1 - (embedding <#> CAST(:embedding AS vector))) AS score
                    FROM document_chunks
                    ORDER BY score DESC
                    LIMIT :limit
                ''')
                result = session.execute(stmt, {"embedding": query_embedding, "limit": limit})
            rows = result.fetchall()
            return [
                {
                    "id": str(row.id),
                    "kb_id": str(row.knowledge_base_id),
                    "document_id": str(row.document_id),
                    "text": row.text,
                    "score": row.score
                }
                for row in rows if row.score >= threshold
            ]

        self.SessionLocal = scoped_session(self.session_factory)
    
    @contextmanager
    def get_session(self) -> Generator[scoped_session, None, None]:
        """
        Get a database session with automatic cleanup.
        
        Usage:
            with db.get_session() as session:
                # Use session here
                result = session.execute("SELECT 1")
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database error: {str(e)}")
            raise
        finally:
            session.close()
    
    def execute(self, query: str, params: Optional[Dict[str, Any]] = None):
        """
        Execute a raw SQL query.
        
        Args:
            query: SQL query string
            params: Optional parameters for the query
            
        Returns:
            Result of the query execution
        """
        with self.get_session() as session:
            result = session.execute(query, params or {})
            return result

# Singleton instance
_db_instance = None

def get_database(db_url: Optional[str] = None) -> Database:
    """
    Get or create the database instance.
    
    Args:
        db_url: Optional database URL. If not provided, will use DATABASE_URL from environment.
        
    Returns:
        Database instance
    """
    global _db_instance
    if _db_instance is None:
        _db_instance = Database(db_url)
    return _db_instance