"""
LLM module for the Agent, providing a simple interface for AWS Bedrock models.
"""

from .llm import (
    call_llm_api, 
    generate_response
)

__all__ = [
    # Main functions
    "call_llm_api",
    "generate_response"
]
