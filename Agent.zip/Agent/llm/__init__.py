"""
LLM module for the Agent, providing a simple interface for AWS Bedrock models with support for various response formats and structures.
"""

from .llm import (
    call_llm_api, 
    generate_response, 
    generate_response_with_payload,
    generate_json_response,
    ResponseFormat,
    ResponseStructure,
    COMMON_STRUCTURES
)

__all__ = [
    # Main functions
    "call_llm_api",
    "generate_response",
    "generate_response_with_payload",
    "generate_json_response",
    
    # Types and constants
    "ResponseFormat",
    "ResponseStructure",
    "COMMON_STRUCTURES"
]
