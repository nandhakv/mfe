"""
LLM Utilities - Handles interactions with AWS Bedrock models.
"""

import json
import logging
import boto3
from typing import Dict, Any, List, Optional, Union

from constants import (
    DEFAULT_MODEL_ID,
    DEFAULT_TEMPERATURE,
    DEFAULT_MAX_TOKENS,
    DEFAULT_TOP_P,
    DEFAULT_TOP_K,
    ANTHROPIC_VERSION,
    EnvVars
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("LLM")

def call_llm_api(payload: Dict[str, Any]) -> str:
    """
    Call the AWS Bedrock Claude 3 Sonnet API with a message-based payload.
    
    Args:
        payload: Dict with 'body' containing the request parameters
        
    Returns:
        The generated response text
    """
    try:
        # Get AWS credentials using the EnvVars class method
        try:
            creds = EnvVars.get_aws_credentials()
            logger.debug(f"Using AWS credentials for region: {creds.get('region_name')}")
            
            if not creds:
                error_msg = "Failed to retrieve AWS credentials. Credentials object is None."
                logger.error(error_msg)
                return f"[LLM Error] {error_msg}"
                
            missing = [k for k in ["aws_access_key_id", "aws_secret_access_key"] if not creds.get(k)]
            if missing:
                error_msg = f"Missing required AWS credentials: {', '.join(missing)}"
                logger.error(error_msg)
                return f"[LLM Error] {error_msg}"
            
            # Initialize the Bedrock client
            try:
                bedrock = boto3.client(
                    "bedrock-runtime",
                    region_name=creds["region_name"],
                    aws_access_key_id=creds["aws_access_key_id"],
                    aws_secret_access_key=creds["aws_secret_access_key"]
                )
                logger.debug("Successfully initialized Bedrock client")
                
            except Exception as e:
                error_msg = f"Failed to initialize Bedrock client: {str(e)}"
                logger.error(error_msg, exc_info=True)
                return f"[LLM Error] {error_msg}"
                
        except Exception as e:
            error_msg = f"Error retrieving AWS credentials: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return f"[LLM Error] {error_msg}"
        
        # Extract request body from payload
        request_body = payload.get("body", {})
        model_id = payload.get("modelId", DEFAULT_MODEL_ID)
        
        logger.info(f"Sending request to AWS Bedrock model: {model_id}")
        logger.debug(f"Request payload: {json.dumps(request_body, indent=2)}")
        
        try:
            # Call the Bedrock API
            response = bedrock.invoke_model(
                modelId=model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )
            
            # Parse the response
            response_text = response["body"].read().decode()
            logger.info("Bedrock API response received")
            
            # Try to parse as JSON first
            try:
                response_body = json.loads(response_text)
                logger.debug(f"Response: {json.dumps(response_body, indent=2)}")
                
                # Handle Claude 3 response format
                if isinstance(response_body, dict) and 'content' in response_body and len(response_body['content']) > 0:
                    result = response_body['content'][0]['text'].strip()
                else:
                    # If not in expected format, try to extract the content directly
                    logger.warning("Unexpected response format, trying to extract content")
                    result = response_text.strip()
                
                return result
                
            except json.JSONDecodeError:
                # If response is not JSON, return it as is
                logger.warning("Response is not valid JSON, returning raw response")
                return response_text
                
        except Exception as e:
            error_msg = f"Error calling Bedrock API: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return f"[LLM Error] {error_msg}"
            
    except Exception as e:
        error_msg = f"Unexpected error in call_llm_api: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"[LLM Error] {error_msg}"

def generate_response(
    messages: Union[str, List[Dict[str, Any]]],
    max_tokens: int = 8192,
    temperature: float = 0.0
) -> str:
    """
    Generate a response using the AWS Bedrock Claude 3 model with message-based input.
    
    Args:
        messages: Either a string prompt or a list of message dictionaries with 'role' and 'content'.
                 Role can be 'system', 'user', 'assistant', or 'tool'.
        max_tokens: Maximum number of tokens to generate
        temperature: Temperature for response generation (0.0 to 1.0)
        
    Returns:
        The generated response text
    """
    try:
        # Use the default model ID from constants
        model_id = DEFAULT_MODEL_ID
        
        # Handle string input (treat as user message)
        if isinstance(messages, str):
            prompt = messages
        # Handle list of messages (convert to string)
        elif isinstance(messages, list) and all(isinstance(m, dict) and 'content' in m for m in messages):
            prompt = "\n".join(f"{m.get('role', 'user').upper()}: {m['content']}" for m in messages)
        else:
            raise ValueError("Messages must be a string or a list of dictionaries with 'content' key")
        
        # Prepare the request payload
        payload = {
            "modelId": model_id,
            "contentType": "application/json",
            "accept": "*/*",
            "body": {
                "anthropic_version": ANTHROPIC_VERSION,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "top_p": DEFAULT_TOP_P,
                "top_k": DEFAULT_TOP_K,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
        }
        
        # Call the API
        return call_llm_api(payload)
        
    except Exception as e:
        error_msg = f"Error in generate_response: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"[LLM Error] {error_msg}"
