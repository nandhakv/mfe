"""
LLM Utilities - Handles interactions with AWS Bedrock models with support for response formats.
"""

import json
import logging
import os
import re
import time
import boto3
from typing import Dict, Any, List, Optional, Union, Tuple, Literal

from llm.message_formatter import format_messages_for_claude

from constants import (
    DEFAULT_MODEL_ID,
    DEFAULT_TEMPERATURE,
    DEFAULT_MAX_TOKENS,
    DEFAULT_TOP_P,
    DEFAULT_TOP_K,
    ANTHROPIC_VERSION,
    EnvVars
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("LLM")

# Response format types
ResponseFormat = Literal["text", "json", "markdown", "html"]

# Response structure types
ResponseStructure = Dict[str, Any]

# Default system prompts for different response formats
DEFAULT_SYSTEM_PROMPTS = {
    "text": """
You are a helpful AI assistant.
Provide accurate, clear, and concise responses to questions.
If you don't know something or if the information isn't in the provided context, admit it clearly.
""",
    
    "json": """
You are an AI assistant that responds in valid JSON format.
Your response must be a valid JSON object that matches the requested schema.
Only include the JSON object in your response, without any additional text or markdown formatting.
""",
    
    "markdown": """
You are an AI assistant that responds in Markdown format.
Use appropriate formatting like headings, lists, and code blocks to make the response clear and readable.
""",
    
    "html": """
You are an AI assistant that responds in HTML format.
Your response should be valid HTML that can be rendered in a web browser.
Include appropriate HTML tags for structure and formatting.
"""
}

# Common response structures
COMMON_STRUCTURES = {
    "qa": {
        "type": "object",
        "properties": {
            "answer": {"type": "string", "description": "Direct answer to the question"},
            "reasoning": {"type": "string", "description": "Explanation of the reasoning"},
            "sources": {"type": "array", "items": {"type": "string"}, "description": "Sources used"}
        },
        "required": ["answer"]
    },
    "analysis": {
        "type": "object",
        "properties": {
            "summary": {"type": "string", "description": "Brief summary"},
            "findings": {"type": "array", "items": {"type": "string"}, "description": "Key findings"},
            "recommendations": {"type": "array", "items": {"type": "string"}, "description": "Recommendations"}
        },
        "required": ["summary", "findings"]
    },
    "classification": {
        "type": "object",
        "properties": {
            "category": {"type": "string", "description": "Category"},
            "confidence": {"type": "number", "description": "Confidence score (0-1)"},
            "explanation": {"type": "string", "description": "Explanation"}
        },
        "required": ["category"]
    },
    "extraction": {
        "type": "object",
        "properties": {
            "entities": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string", "description": "Entity type"},
                        "value": {"type": "string", "description": "Entity value"},
                        "position": {"type": "array", "items": {"type": "integer"}, "description": "Start and end position"}
                    },
                    "required": ["type", "value"]
                }
            }
        },
        "required": ["entities"]
    }
}

# Add at the top after imports
AGENT_TOKEN_COUNTER = None

def count_tokens(text):
    # Claude 3.5: ~1 token per 4 characters (English)
    if not text:
        return 0
    return max(1, len(text) // 4)

def call_llm_api(payload: Dict[str, Any], response_format: ResponseFormat = "text") -> str:
    """
    Call the AWS Bedrock Claude 3 Sonnet API with a message-based payload.
    
    Args:
        payload: Dict with 'body' containing the request parameters
        response_format: Format for the response (text, json, markdown, html)
        
    Returns:
        The generated response text in the requested format
    """
    try:
        # Get AWS credentials using the EnvVars class method
        try:
            creds = EnvVars.get_aws_credentials()
            logger.debug(f"Using AWS credentials for region: {creds.get('region_name')}")
            
            # Log the credentials (masking secret key for security)
            masked_key = f"{creds.get('aws_access_key_id', '')[:4]}...{creds.get('aws_access_key_id', '')[-4:]}" if creds.get('aws_access_key_id') else 'None'
            logger.debug(f"Using AWS Access Key ID: {masked_key}")
            
            if not creds:
                error_msg = "Failed to retrieve AWS credentials. Credentials object is None."
                logger.error(error_msg)
                return f"[LLM Error] {error_msg}"
                
            missing = [k for k in ["aws_access_key_id", "aws_secret_access_key"] if not creds.get(k)]
            if missing:
                error_msg = f"Missing required AWS credentials: {', '.join(missing)}"
                logger.error(error_msg)
                return f"[LLM Error] {error_msg}"
            
            # Initialize the Bedrock client
            try:
                bedrock = boto3.client(
                    "bedrock-runtime",
                    region_name=creds["region_name"],
                    aws_access_key_id=creds["aws_access_key_id"],
                    aws_secret_access_key=creds["aws_secret_access_key"]
                )
                logger.debug("Successfully initialized Bedrock client")
                
            except Exception as e:
                error_msg = f"Failed to initialize Bedrock client: {str(e)}"
                logger.error(error_msg, exc_info=True)
                return f"[LLM Error] {error_msg}"
                
        except Exception as e:
            error_msg = f"Error retrieving AWS credentials: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return f"[LLM Error] {error_msg}"
        
        # Extract request body from payload
        request_body = payload.get("body", {})
        model_id = payload.get("modelId", DEFAULT_MODEL_ID)
        
        # Format-specific instructions are now handled in generate_response
        
        logger.info(f"Sending request to AWS Bedrock model: {model_id}")
        logger.debug(f"Request payload: {json.dumps(request_body, indent=2)}")
        
        try:
            # Call the Bedrock API
            response = bedrock.invoke_model(
                modelId=model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body)
            )
            
            # Parse the response
            response_text = response["body"].read().decode()
            logger.info("Bedrock API response received")
            
            # Try to parse as JSON first
            try:
                response_body = json.loads(response_text)
                logger.debug(f"Response: {json.dumps(response_body, indent=2)}")
                
                # Handle Claude 3 response format
                if isinstance(response_body, dict) and 'content' in response_body and len(response_body['content']) > 0:
                    result = response_body['content'][0]['text'].strip()
                else:
                    # If not in expected format, try to extract the content directly
                    logger.warning("Unexpected response format, trying to extract content")
                    result = response_text.strip()
                
                # For JSON responses, validate the format
                if response_format == "json":
                    try:
                        # Try to parse the response as JSON to validate it
                        parsed = json.loads(result)
                        # If we got here, the JSON is valid
                        return json.dumps(parsed, indent=2)
                    except json.JSONDecodeError as e:
                        logger.warning(f"Invalid JSON response: {str(e)}")
                        # Try to extract JSON from markdown code blocks
                        import re
                        json_match = re.search(r'```(?:json)?\s*({.*?})\s*```', result, re.DOTALL)
                        if json_match:
                            try:
                                parsed = json.loads(json_match.group(1))
                                return json.dumps(parsed, indent=2)
                            except json.JSONDecodeError:
                                pass
                        return json.dumps({
                            "error": "Failed to generate valid JSON response",
                            "details": str(e),
                            "raw_response": result
                        }, indent=2)
                
                return result
                
            except json.JSONDecodeError:
                # If response is not JSON, return it as is
                logger.warning("Response is not valid JSON, returning raw response")
                return response_text
                
        except Exception as e:
            error_msg = f"Error calling Bedrock API: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return f"[LLM Error] {error_msg}"
            
    except Exception as e:
        error_msg = f"Unexpected error in call_llm_api: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"[LLM Error] {error_msg}"

# For backward compatibility
generate_response_with_payload = call_llm_api

def _bedrock_claude_fix_messages(messages):
    fixed = []
    for m in messages:
        role = m.get("role")
        content = m.get("content")
        # Convert content to string if not already
        if content is None:
            content = ""
        elif not isinstance(content, str):
            try:
                content = json.dumps(content, indent=2)
            except TypeError:
                content = str(content)
        # Map roles
        if role == "system" or role == "tool":
            # Bedrock only allows user/assistant, so treat as user
            role = "user"
        elif role not in ("user", "assistant"):
            role = "user"
        fixed.append({"role": role, "content": content})
    return fixed

def _bedrock_claude_merge_consecutive_roles(messages):
    if not messages:
        return []
    merged = [messages[0]]
    for m in messages[1:]:
        if m["role"] == merged[-1]["role"]:
            merged[-1]["content"] += "\n\n" + m["content"]
        else:
            merged.append(m)
    return merged

def generate_response(
    messages: Union[str, List[Dict[str, Any]]],
    max_tokens: int = 8192, # Increased from default to prevent truncation
    temperature: float = 0.3,
    response_format: ResponseFormat = "text",
    json_schema: Dict[str, Any] = None,
    response_structure: Union[str, Dict[str, Any]] = None,
    token_budget: int = None  # New parameter for token budgeting
) -> str:
    """
    Generate a response using the AWS Bedrock Claude 3 model with message-based input.
    
    Args:
        messages: Either a string prompt or a list of message dictionaries with 'role' and 'content'.
                 Role can be 'system', 'user', 'assistant', or 'tool'.
        max_tokens: Maximum number of tokens to generate
        temperature: Temperature for response generation (0.0 to 1.0)
        response_format: Format for the response (text, json, markdown, html)
        json_schema: Optional JSON schema for JSON responses
        response_structure: Predefined structure name or custom schema for JSON responses
        
    Returns:
        The generated response text in the requested format
    """
    try:
        # Use the default model ID from constants
        model_id = DEFAULT_MODEL_ID
        
        # Prepare messages in Claude-compatible format
        if isinstance(messages, str):
            messages_to_send = [{"role": "user", "content": messages}]
        elif isinstance(messages, list) and all(isinstance(m, dict) and 'content' in m and 'role' in m for m in messages):
            messages_to_send = messages.copy()
        else:
            raise ValueError("Messages must be a string or a list of dictionaries with 'role' and 'content' keys")

        # Fix messages for Bedrock Claude
        messages_to_send = _bedrock_claude_fix_messages(messages_to_send)

        # Merge consecutive messages with the same role
        messages_to_send = _bedrock_claude_merge_consecutive_roles(messages_to_send)

        # Add JSON formatting instructions if needed
        if response_format == "json":
            if json_schema is None and response_structure is not None:
                if isinstance(response_structure, str) and response_structure in COMMON_STRUCTURES:
                    json_schema = COMMON_STRUCTURES[response_structure]
                elif isinstance(response_structure, dict):
                    json_schema = response_structure
            if json_schema:
                schema_instruction = f"Please respond with a valid JSON object that follows this schema:\n{json.dumps(json_schema, indent=2)}\nYour response must be a valid JSON object that matches the schema exactly."
                messages_to_send.append({"role": "system", "content": schema_instruction})
        
        # Prepare the request payload
        payload = {
            "modelId": model_id,
            "contentType": "application/json",
            "accept": "*/*",
            "body": {
                "anthropic_version": ANTHROPIC_VERSION,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "top_p": DEFAULT_TOP_P,
                "top_k": DEFAULT_TOP_K,
                "messages": messages_to_send
            }
        }
        
        # Call the API
        response = call_llm_api(payload, response_format)

        # --- Token counting and budgeting ---
        global AGENT_TOKEN_COUNTER
        # Count tokens for all message contents
        prompt_tokens = sum(count_tokens(m["content"]) for m in messages_to_send)
        response_tokens = count_tokens(response)
        
        # Check token budget if specified
        if token_budget is not None:
            total_tokens_this_call = prompt_tokens + response_tokens
            if total_tokens_this_call > token_budget:
                logger.warning(f"Token budget exceeded: {total_tokens_this_call} > {token_budget}")
                # Truncate response if needed
                if response_tokens > token_budget // 2:
                    response = response[:token_budget // 2] + "... [truncated]"
                    response_tokens = count_tokens(response)
        
        if AGENT_TOKEN_COUNTER is not None:
            AGENT_TOKEN_COUNTER['prompt'] += prompt_tokens
            AGENT_TOKEN_COUNTER['response'] += response_tokens
            AGENT_TOKEN_COUNTER['total'] += prompt_tokens + response_tokens
        # --- End token counting ---
        
        # For JSON responses, ensure the response is valid JSON
        if response_format == "json":
            try:
                # Try to parse the response to ensure it's valid JSON
                json.loads(response)
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON response, attempting to fix: {response[:200]}...")
                # Try to fix common JSON issues
                fixed_response = _fix_json_response(response)
                try:
                    json.loads(fixed_response)
                    logger.info("Successfully fixed JSON response")
                    return fixed_response
                except json.JSONDecodeError:
                    logger.error(f"Could not fix JSON response: {response}")
                    # Return a default error response in the expected format
                    error_response = {"error": "Failed to generate valid JSON response"}
                    if json_schema:
                        error_response["schema_required"] = json_schema
                    return json.dumps(error_response, indent=2)
        
        return response
        
    except Exception as e:
        error_msg = f"Error in generate_response: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"[LLM Error] {error_msg}"


def _fix_json_response(response: str) -> str:
    """Fix common JSON formatting issues in LLM responses."""
    import re
    
    # Replace single quotes with double quotes (but be careful with apostrophes)
    # This is a simple approach - in production you might want more sophisticated handling
    fixed = response
    
    # Fix single-quoted property names and string values
    # Pattern: 'property': 'value' -> "property": "value"
    fixed = re.sub(r"'([^']+)':\s*'([^']*)'", r'"\1": "\2"', fixed)
    
    # Fix single-quoted property names with non-string values
    # Pattern: 'property': value -> "property": value
    fixed = re.sub(r"'([^']+)':\s*([^,}\]]+)", r'"\1": \2', fixed)
    
    # Fix remaining single quotes in property names
    fixed = re.sub(r"'([^']+)':", r'"\1":', fixed)
    
    return fixed


def generate_json_response(
    messages: Union[str, List[Dict[str, Any]]],
    json_schema: Dict[str, Any] = None,
    max_tokens: int = 1000,
    temperature: float = 0.3,
    response_structure: Union[str, Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Generate a response in JSON format using the AWS Bedrock Claude 3 model.
    
    Args:
        messages: Either a string prompt or a list of message dictionaries with 'role' and 'content'.
                 Role can be 'system', 'user', 'assistant', or 'tool'.
        json_schema: JSON schema defining the expected response structure
        max_tokens: Maximum number of tokens to generate
        temperature: Temperature for response generation (0.0 to 1.0)
        response_structure: Predefined structure name ("qa", "analysis", "classification") or custom schema
        
    Returns:
        The generated response as a Python dictionary
        
    Raises:
        ValueError: If the response cannot be parsed as valid JSON or if the structure is invalid
    """
    try:
        # Determine which schema to use
        schema_to_use = None
        
        # If a predefined structure is requested
        if isinstance(response_structure, str):
            if response_structure in COMMON_STRUCTURES:
                schema_to_use = COMMON_STRUCTURES[response_structure]
                logger.info(f"Using predefined structure: {response_structure}")
            else:
                available_structures = list(COMMON_STRUCTURES.keys())
                error_msg = f"Unknown response structure '{response_structure}'. Available structures: {available_structures}"
                logger.error(error_msg)
                raise ValueError(error_msg)
        # If a custom schema is provided
        elif isinstance(response_structure, dict):
            schema_to_use = response_structure
            logger.info("Using custom response structure")
        # Otherwise use the provided json_schema
        elif json_schema:
            schema_to_use = json_schema
            logger.info("Using provided JSON schema")
        # If no schema is provided, use a default one
        else:
            schema_to_use = {
                "type": "object",
                "properties": {
                    "response": {"type": "string"},
                    "metadata": {"type": "object"}
                },
                "required": ["response"]
            }
            logger.info("Using default JSON schema")
        
        # Generate response with JSON format and the selected schema
        json_response = generate_response(
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            response_format="json",
            json_schema=schema_to_use
        )
        
        # Parse the response
        try:
            if isinstance(json_response, str):
                result = json.loads(json_response)
            else:
                result = json_response
                
            # If the response is an error object, convert it to a proper error
            if isinstance(result, dict) and 'error' in result:
                error_msg = result.get('details', result['error'])
                raise ValueError(f"Error generating response: {error_msg}")
                
            return result
            
        except json.JSONDecodeError as e:
            error_msg = f"Failed to parse JSON response: {str(e)}\nResponse: {json_response}"
            logger.error(error_msg)
            raise ValueError(error_msg)
            
    except Exception as e:
        if not isinstance(e, ValueError):
            error_msg = f"Error generating JSON response: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise ValueError(error_msg)
        raise
