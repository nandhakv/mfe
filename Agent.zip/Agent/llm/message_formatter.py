"""
Message formatting utilities for Claude API compatibility.
"""

from typing import List, Dict, Any

def format_messages_for_claude(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Format messages to ensure they follow Claude's requirements:
    - Roles must alternate between 'user' and 'assistant'
    - Cannot have consecutive messages with the same role
    
    Args:
        messages: Original message list
        
    Returns:
        Properly formatted message list for Claude API
    """
    if not messages:
        return []
    
    formatted_messages = []
    last_role = None
    
    for i, msg in enumerate(messages):
        role = msg.get("role", "")
        
        # Skip empty messages
        if not msg.get("content"):
            continue
            
        # Handle the first message
        if last_role is None:
            formatted_messages.append(msg)
            last_role = role
            continue
        
        # If current message has same role as previous, merge them
        if role == last_role:
            # Merge with previous message
            prev_msg = formatted_messages[-1]
            prev_content = prev_msg.get("content", "")
            curr_content = msg.get("content", "")
            
            # Combine content with clear separation
            if role == "user":
                separator = "\n\nAdditional information:\n"
            else:
                separator = "\n\nContinuing response:\n"
                
            combined_content = f"{prev_content}{separator}{curr_content}"
            formatted_messages[-1]["content"] = combined_content
        else:
            # Different role, add as new message
            formatted_messages.append(msg)
            last_role = role
    
    # Ensure the conversation starts with a user message
    if formatted_messages and formatted_messages[0].get("role") != "user":
        # Insert a system message as the first user message
        formatted_messages.insert(0, {
            "role": "user",
            "content": "I need your assistance with the following task."
        })
    
    return formatted_messages
