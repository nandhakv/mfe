def append_unique_message(messages, new_message):
    """Append a message only if it is not a duplicate of the last message."""
    if not messages or messages[-1] != new_message:
        messages.append(new_message)
