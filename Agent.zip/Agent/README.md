# Agent Package

A Python package for processing and managing document-related tasks.

## Features

- Document processing pipeline
- Configuration management
- Error handling and logging
- Utility functions for common tasks

## Installation

```bash
# Install the package in development mode
pip install -e /path/to/Agent
```

## Usage

```python
from Agent import Agent

# Initialize the agent
with Agent() as agent:
    # Process a document
    result = agent.process_document("path/to/document.pdf")
    print(f"Processing result: {result}")
```

## Configuration

The agent can be configured using environment variables with the `AGENT_` prefix:

- `AGENT_LOG_LEVEL`: Logging level (default: INFO)
- `AGENT_MAX_RETRIES`: Maximum number of retries for operations (default: 3)
- `AGENT_TIMEOUT`: Timeout for operations in seconds (default: 30)

## Development

### Running Tests

```bash
# Install test dependencies
pip install -e ".[test]"

# Run tests
pytest
```

### Code Style

This project uses `black` for code formatting and `flake8` for linting.

```bash
# Format code
black .

# Run linter
flake8
```

## License

MIT
