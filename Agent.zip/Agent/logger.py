"""Logging configuration for the agent."""

import logging
import sys
from typing import Optional

# Configure the root logger
def setup_logger(name: str = "agent", log_level: int = logging.INFO) -> logging.Logger:
    """Set up and return a logger with the given name and log level.
    
    Args:
        name: Name of the logger
        log_level: Logging level (e.g., logging.INFO, logging.DEBUG)
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(log_level)
    
    # Create console handler with a higher log level
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(log_level)
    
    # Create formatter and add it to the handlers
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    ch.setFormatter(formatter)
    
    # Add the handlers to the logger
    if not logger.handlers:
        logger.addHandler(ch)
    
    # Prevent duplicate logs in some environments
    logger.propagate = False
    
    return logger

# Create a default logger instance
logger = setup_logger()

# This allows importing the logger directly: from logger import logger
__all__ = ['logger', 'setup_logger']
