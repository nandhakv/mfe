---
trigger: always_on
---

Always use or activate venv before running any python code