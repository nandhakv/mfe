from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
import uvicorn
import os
import sys

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import agent and tools
from agent import Agent
from tools.registry import TOOL_REGISTRY
from tools.search import get_search_tools
from tools.freshdesk import get_freshdesk_tools
from database import get_database
from constants import DEFAULT_DB_URL

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database and tools once when the app starts
os.environ["DATABASE_URL"] = DEFAULT_DB_URL
db = get_database()
get_search_tools(db)
get_freshdesk_tools()  # This registers Freshdesk tools

import json

@app.post("/api/agent/stream")
async def agent_stream(request: Request):
    data = await request.json()
    query = data.get("query")
    if not query:
        return {"error": "No query provided"}, 400

    agent = Agent()
    async def event_stream():
        try:
            for chunk in agent.run(query, stream=True):
                yield f"data: {chunk}\n\n"
        except Exception as e:
            yield f"data: Error: {str(e)}\n\n"
        finally:
            yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )

if __name__ == "__main__":
    uvicorn.run("webui.api:app", host="0.0.0.0", port=8000, reload=True)