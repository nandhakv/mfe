# FinanceBot Web UI

This folder contains a simple web UI and FastAPI WebSocket backend for interacting with the FinanceBot agent.

## Files
- `client.html`: A modern, minimal chat UI for user interaction.
- `api.py`: FastAPI WebSocket API that connects the UI to the agent.

## Usage
1. Start the API server:
   ```bash
   uvicorn webui.api:app --reload
   ```
2. Open `client.html` in your browser.

## Requirements
- Python 3.9+
- FastAPI
- Uvicorn
- Your venv activated (see project root README)
