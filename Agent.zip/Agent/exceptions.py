"""
Custom exceptions for the Agent package.
"""

class AgentError(Exception):
    """Base exception for all Agent-related errors."""
    pass

class ConfigurationError(AgentError):
    """Raised when there is a configuration error."""
    pass

class ProcessingError(AgentError):
    """Raised when document processing fails."""
    pass

class ValidationError(AgentError):
    """Raised when input validation fails."""
    pass

class ResourceError(AgentError):
    """Raised when there's an error accessing required resources."""
    pass

class SearchError(AgentError):
    """Raised when a search operation fails or is invalid."""
    pass

class ClassificationError(AgentError):
    """Raised when a classification operation fails or is invalid."""
    pass