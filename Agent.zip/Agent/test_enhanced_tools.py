#!/usr/bin/env python3
"""
Test script for enhanced tools functionality.
"""

import os
import sys
import time
from constants import EnvVars, DEFAULT_DB_URL

# Set up environment variables
os.environ["AWS_ACCESS_KEY_ID"] = EnvVars.AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = EnvVars.AWS_SECRET_ACCESS_KEY
os.environ["AWS_REGION"] = EnvVars.AWS_REGION
os.environ["DATABASE_URL"] = DEFAULT_DB_URL

def test_enhanced_tools():
    """Test the enhanced tools functionality."""
    print("🧪 Testing Enhanced Tools")
    print("=" * 50)
    
    try:
        # Import tools
        from tools import (
            initialize_enhanced_tools,
            get_registry,
            get_executor,
            get_tool_performance_stats,
            health_check_all_tools
        )
        from database import get_database
        
        print("✅ Enhanced tools imported successfully")
        
        # Initialize database
        db = get_database()
        print("✅ Database initialized")
        
        # Initialize enhanced tools
        print("\n🛠️ Initializing enhanced tools...")
        tools = initialize_enhanced_tools(db)
        print("✅ Enhanced tools initialized")
        
        # Get registry and executor
        registry = get_registry()
        executor = get_executor()
        
        # List registered tools
        print(f"\n📋 Registered Tools: {len(registry.list_tools())}")
        for tool_info in registry.list_tools():
            print(f"  - {tool_info['name']} ({tool_info['metadata'].category})")
        
        # Test tool execution
        print("\n🚀 Testing tool execution...")
        
        # Test knowledge base search
        test_query = "What is the difference between SCF and colending products?"
        
        print(f"Query: {test_query}")
        
        # Execute with improved executor
        from tools.models import KnowledgeBaseSearchInput
        tool_calls = [
            {
                "name": "knowledge_base_search",
                "parameters": {
                    "input": KnowledgeBaseSearchInput(
                        query=test_query,
                        threshold=0.1,
                        limit=3,
                        type=None,
                        include_metadata=False
                    )
                }
            }
        ]
        
        from tools import ExecutionStrategy
        result = executor.execute_plan(
            strategy=ExecutionStrategy.SEQUENTIAL,
            tool_calls=tool_calls
        )
        
        print(f"✅ Execution completed in {result['execution_time']:.3f}s")
        print(f"   Successful tools: {result['successful_tools']}")
        print(f"   Failed tools: {result['failed_tools']}")
        
        # Show results
        for execution_result in result['results']:
            if execution_result.error:
                print(f"❌ {execution_result.tool_name}: {execution_result.error}")
            else:
                print(f"✅ {execution_result.tool_name}: {execution_result.execution_time:.3f}s")
                if hasattr(execution_result.result, 'chunks'):
                    print(f"   Found {len(execution_result.result.chunks)} results")
        
        # Test parallel execution
        print("\n🔄 Testing parallel execution...")
        
        parallel_tool_calls = [
            {
                "name": "knowledge_base_search",
                "parameters": {
                    "input": KnowledgeBaseSearchInput(query="SCF products", limit=2, threshold=0.1, type=None, include_metadata=False)
                }
            },
            {
                "name": "knowledge_base_search", 
                "parameters": {
                    "input": KnowledgeBaseSearchInput(query="colending products", limit=2, threshold=0.1, type=None, include_metadata=False)
                }
            }
        ]
        
        parallel_result = executor.execute_plan(
            strategy=ExecutionStrategy.PARALLEL,
            tool_calls=parallel_tool_calls
        )
        
        print(f"✅ Parallel execution completed in {parallel_result['execution_time']:.3f}s")
        print(f"   Sequential time would be: {sum(r.execution_time for r in parallel_result['results']):.3f}s")
        print(f"   Speedup: {sum(r.execution_time for r in parallel_result['results']) / parallel_result['execution_time']:.1f}x")
        
        # Get performance stats
        print("\n📊 Performance Statistics:")
        stats = get_tool_performance_stats()
        
        registry_stats = stats['registry_stats']
        print(f"  Registry Stats:")
        print(f"    Total tools: {registry_stats['total_tools']}")
        print(f"    Active tools: {registry_stats['active_tools']}")
        print(f"    Total calls: {registry_stats['total_calls']}")
        print(f"    Success rate: {registry_stats['success_rate']:.1%}")
        print(f"    Avg execution time: {registry_stats['average_execution_time']:.3f}s")
        
        executor_stats = stats['executor_stats']
        print(f"  Executor Stats:")
        print(f"    Total executions: {executor_stats['total_executions']}")
        print(f"    Success rate: {executor_stats['success_rate']:.1%}")
        print(f"    Avg execution time: {executor_stats['average_execution_time']:.3f}s")
        
        # Health check
        print("\n🏥 Health Check:")
        health_results = health_check_all_tools()
        for tool_name, is_healthy in health_results.items():
            status = "✅" if is_healthy else "❌"
            print(f"  {status} {tool_name}")
        
        # Test caching
        print("\n💾 Testing caching...")
        
        # First call (cache miss)
        start_time = time.time()
        result1 = registry.call("knowledge_base_search", input=KnowledgeBaseSearchInput(query=test_query, limit=1, threshold=0.1, type=None, include_metadata=False))
        time1 = time.time() - start_time
        
        # Second call (cache hit)
        start_time = time.time()
        result2 = registry.call("knowledge_base_search", input=KnowledgeBaseSearchInput(query=test_query, limit=1, threshold=0.1, type=None, include_metadata=False))
        time2 = time.time() - start_time
        
        print(f"  First call: {time1:.3f}s")
        print(f"  Second call: {time2:.3f}s")
        print(f"  Cache speedup: {time1/time2:.1f}x")
        
        print("\n🎉 All tests completed successfully!")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def test_legacy_compatibility():
    """Test backward compatibility with legacy tools."""
    print("\n🔄 Testing Legacy Compatibility")
    print("=" * 50)
    
    try:
        # Import tools
        from tools import get_search_tools, get_registry
        from database import get_database
        
        print("✅ Legacy tools imported successfully")
        
        # Initialize database
        db = get_database()
        
        # Initialize search tools and registry
        search_tools = get_search_tools(db)
        registry = get_registry()
        print("✅ Search tools initialized")
        
        # Test tool execution
        test_query = "SCF products"
        
        print(f"Query: {test_query}")
        
        # Use search tools
        from tools.models import KnowledgeBaseSearchInput
        result = registry.call("knowledge_base_search", input=KnowledgeBaseSearchInput(
            query=test_query,
            limit=2,
            threshold=0.1,
            type=None,
            include_metadata=False
        ))
        
        print(f"✅ Execution completed")
        print(f"   Found {len(result.chunks)} results")
        
        print("🎉 Compatibility test passed!")
        
    except Exception as e:
        print(f"❌ Legacy test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == "__main__":
    print("🧪 Enhanced Tools Test Suite")
    print("=" * 60)
    
    # Test enhanced tools
    enhanced_success = test_enhanced_tools()
    
    # Test legacy compatibility
    legacy_success = test_legacy_compatibility()
    
    # Summary
    print("\n📋 Test Summary")
    print("=" * 30)
    print(f"Enhanced Tools: {'✅ PASSED' if enhanced_success else '❌ FAILED'}")
    print(f"Legacy Compatibility: {'✅ PASSED' if legacy_success else '❌ FAILED'}")
    
    if enhanced_success and legacy_success:
        print("\n🎉 All tests passed! Enhanced tools are working correctly.")
        sys.exit(0)
    else:
        print("\n❌ Some tests failed. Please check the errors above.")
        sys.exit(1) 