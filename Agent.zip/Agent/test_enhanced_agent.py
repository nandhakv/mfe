#!/usr/bin/env python3
"""
Test script for the enhanced agent implementation.
"""

import os
import sys
from datetime import datetime

# Add the current directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_agent_creation():
    """Test agent creation and configuration."""
    print("🧪 Testing agent creation...")
    
    from agent import SimplifiedAgent, AgentConfig, create_agent
    
    # Test with default config
    agent1 = SimplifiedAgent()
    print(f"✅ Default agent created: {agent1.config.name}")
    
    # Test with custom config
    config = AgentConfig(
        name="TestAgent",
        max_iterations=5,
        debug_mode=True
    )
    agent2 = SimplifiedAgent(config)
    print(f"✅ Custom agent created: {agent2.config.name}")
    
    # Test factory function
    agent3 = create_agent(
        name="FactoryAgent",
        max_iterations=8,
        enable_streaming=True
    )
    print(f"✅ Factory agent created: {agent3.config.name}")
    
    # Test status
    status = agent1.get_status()
    print(f"✅ Agent status: {status}")
    
    return True

def test_agent_imports():
    """Test that all agent components import correctly."""
    print("🧪 Testing agent imports...")
    
    try:
        from agent import SimplifiedAgent, AgentConfig, create_agent, Agent
        from state import AgentState, get_initial_state
        from nodes.planner import PlannerNode
        from nodes.tool_executor import ToolExecutorNode
        from nodes.reflect import ReflectNode
        from nodes.generator import GeneratorNode
        print("✅ All agent components imported successfully")
        return True
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False

def test_state_management():
    """Test state management functionality."""
    print("🧪 Testing state management...")
    
    from state import get_initial_state, AgentState
    
    # Test initial state creation
    query = "Test query"
    initial_state = get_initial_state(query)
    
    # Check required fields
    required_fields = [
        "messages", "tool_execution_plans", "tool_results", 
        "last_reflection_decision", "output", "error", "response_ready",
        "status", "iteration_count", "start_time"
    ]
    
    for field in required_fields:
        if field not in initial_state:
            print(f"❌ Missing field: {field}")
            return False
    
    print("✅ State management working correctly")
    return True

def test_tool_registration():
    """Test tool registration and availability."""
    print("🧪 Testing tool registration...")
    
    try:
        # Set up environment
        from constants import DEFAULT_DB_URL
        os.environ["DATABASE_URL"] = DEFAULT_DB_URL
        
        # Initialize tools
        from database import get_database
        from tools.search import get_search_tools
        from tools.freshdesk import get_freshdesk_tools
        from tools.registry import get_registry
        
        db = get_database()
        get_search_tools(db)
        get_freshdesk_tools()
        
        # Check tool registry
        registry = get_registry()
        tools = registry.list_tools()
        
        print(f"✅ Tools registered successfully: {len(tools)} tools available")
        
        # List available tools
        tool_names = [tool["name"] for tool in tools]
        print(f"📋 Available tools: {', '.join(tool_names)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Tool registration error: {e}")
        return False

def main():
    """Run all tests."""
    print("🚀 Starting Enhanced Agent Tests")
    print("=" * 50)
    
    tests = [
        ("Agent Imports", test_agent_imports),
        ("Agent Creation", test_agent_creation),
        ("State Management", test_state_management),
        ("Tool Registration", test_tool_registration),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name} PASSED")
            else:
                print(f"❌ {test_name} FAILED")
        except Exception as e:
            print(f"❌ {test_name} ERROR: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Enhanced agent is ready to use.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the issues above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 