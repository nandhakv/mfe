# state.py
"""Agent state management for the ReAct architecture."""
from typing import List, Dict, Any, Optional, TypedDict

class AgentState(TypedDict):
    """
    Represents the state of our agent for the ReAct architecture.

    Attributes:
        query: The user query to process.
        messages: The history of messages in the conversation.
        tool_execution_plans: The plan for the next single tool call.
        tool_results: A list of all tool results so far.
        last_reflection_decision: The decision from the last reflection step ('call_tool' or 'generate').
        output: The final response from the agent.
        error: Any error that occurred during execution.
        response_ready: A flag to indicate that the response is ready.
        status: Current status of the agent execution.
        iteration_count: Number of tool execution iterations completed.
        start_time: Timestamp when execution started.
    """
    query: str
    messages: List[Dict[str, Any]]
    tool_execution_plans: Optional[Dict[str, Any]]
    tool_results: List[Dict[str, Any]]
    last_reflection_decision: Optional[str]
    output: Optional[str]
    error: Optional[str]
    response_ready: bool
    status: Optional[str]
    iteration_count: Optional[int]
    start_time: Optional[str]

def get_initial_state(query: str) -> Dict[str, Any]:
    """Returns the initial state for the agent as a dictionary."""
    return {
        "query": query,  # Add the query field that the planner expects
        "messages": [],  # Empty messages list - planner will add the user query
        "tool_execution_plans": None,
        "tool_results": [],
        "last_reflection_decision": None,
        "output": None,
        "error": None,
        "response_ready": False,
        "status": None,
        "iteration_count": None,
        "start_time": None,
    }
