# state.py
"""Agent state management for the ReAct architecture."""
from typing import List, Dict, Any, Optional, TypedDict

class AgentState(TypedDict):
    """
    Represents the state of our agent for the ReAct architecture.

    Attributes:
        messages: The history of messages in the conversation.
        tool_execution_plans: The plan for the next single tool call.
        tool_results: A list of all tool results so far.
        last_reflection_decision: The decision from the last reflection step ('call_tool' or 'generate').
        output: The final response from the agent.
        error: Any error that occurred during execution.
        response_ready: A flag to indicate that the response is ready.
    """
    def __init__(self, 
                 messages: List[Dict[str, Any]], 
                 tool_execution_plans: Optional[Dict[str, Any]], 
                 tool_results: List[Dict[str, Any]], 
                 last_reflection_decision: Optional[str], 
                 output: Optional[str],
                 error: Optional[str],
                 response_ready: bool):
        self.messages = messages
        self.tool_execution_plans = tool_execution_plans
        self.tool_results = tool_results
        self.last_reflection_decision = last_reflection_decision
        self.output = output
        self.error = error
        self.response_ready = response_ready

    messages: List[Dict[str, Any]]
    tool_execution_plans: Optional[Dict[str, Any]]
    tool_results: List[Dict[str, Any]]
    last_reflection_decision: Optional[str]
    output: Optional[str]
    error: Optional[str]
    response_ready: bool

def get_initial_state(query: str) -> Dict[str, Any]:
    """Returns the initial state for the agent as a dictionary."""
    return {
        "messages": [{"role": "user", "content": query}],
        "tool_execution_plans": None,
        "tool_results": [],
        "last_reflection_decision": None,
        "output": None,
        "error": None,
        "response_ready": False,
    }
    state["messages"].append({"role": "user", "content": query})
    
    return state
