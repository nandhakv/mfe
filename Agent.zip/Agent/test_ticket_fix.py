#!/usr/bin/env python3
"""
Test script to verify ticket analysis workflow with proper temperature setting.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent import create_agent
import os
from constants import DEFAULT_DB_URL
from database import get_database
from tools.search import get_search_tools
from tools.freshdesk import get_freshdesk_tools

def test_ticket_analysis():
    """Test the agent with ticket analysis query."""
    
    # Set up database and tools
    os.environ["DATABASE_URL"] = DEFAULT_DB_URL
    db = get_database()
    get_search_tools(db)
    get_freshdesk_tools()
    
    # Initialize the agent
    agent = create_agent(debug_mode=False)
    
    # Test query for ticket analysis
    query = "What was the root cause of ticket 114781? analyse the code and provide the fix with example"
    
    print("Testing ticket analysis workflow...")
    print(f"Query: {query}")
    print("-" * 50)
    
    # Run the agent
    response = agent.run(query)
    
    print("\n" + "="*50)
    print("FINAL RESPONSE:")
    print("="*50)
    print(response)

if __name__ == "__main__":
    test_ticket_analysis() 