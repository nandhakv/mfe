# test_kb_search.py

import os
from constants import DEFAULT_DB_URL
from database import get_database
from tools.search import get_search_tools, KnowledgeBaseSearchInput

def main():
    # Set up DB connection
    os.environ["DATABASE_URL"] = DEFAULT_DB_URL
    db = get_database()
    search_tools = get_search_tools(db)

    # Test input (change query to match your KBs)
    kb_query = "scf"  # <-- Replace with a real product name in your KBs
    input_data = KnowledgeBaseSearchInput(query=kb_query, threshold=0.0, limit=5, type=None)

    # Run the search
    result = search_tools.knowledge_base_search(input_data)

    # Print results
    print("Knowledge Base Search Results:")
    for match in result.chunks:
        print(f"- ID: {match.id}, Name: {match.name}, Description: {match.description}, Score: {match.score}")

    # --- Test document_search ---
    test_kb_id = result.chunks[0].id if result.chunks else None
    if test_kb_id:
        from tools.search import DocumentSearchInput
        doc_query = "product page crash white screen"
        doc_input = DocumentSearchInput(query=doc_query, kb_id=test_kb_id, limit=5, threshold=0.1)
        doc_result = search_tools.document_search(doc_input)
        print("\nDocument Search Results:")
        if doc_result.chunks:
            for chunk in doc_result.chunks:
                print(f"- ID: {chunk.id}, KB: {chunk.kb_id}, Content: {getattr(chunk, 'content', '')}, Score: {chunk.score}")
        else:
            print("No document chunks found for this KB.")
    else:
        print("No KBs found for document_search test.")

    # --- Find repository_id for the KB ---
    repo_id = None
    with db.engine.connect() as conn:
        from sqlalchemy import text
        result_repo = conn.execute(
            text("SELECT id FROM repositories WHERE knowledge_base_id = :kb_id"),
            {"kb_id": test_kb_id}
        )
        rows = result_repo.fetchall()
        print(f"\nRepositories for KB {test_kb_id}: {[str(row[0]) for row in rows]}")
        if rows:
            repo_id = rows[0][0]

    # --- Test code_search ---
    if test_kb_id:
        from tools.search import CodeSearchInput
        # Search across all linked repositories
        code_query = "yubi Flow product page crash"
        print(f"\nCode Search Query: {code_query}")
        try:
            code_input = CodeSearchInput(knowledge_base_id=test_kb_id, query=code_query)
            code_result = search_tools.code_search(code_input)
            print("\nCode Search Results:")
            if code_result.chunks:
                for chunk in code_result.chunks:
                    print(f"- ID: {chunk.id}, Repo: {chunk.repository_id}, Path: {chunk.file_path}, Score: {chunk.score}")
                    print(f'  Code: "{chunk.code[:200]}..."')
            else:
                print("No code chunks found for this knowledge base.")
        except Exception as e:
            print(f"Code search failed: {e}")
    else:
        print("No repository found for the selected KB.")

if __name__ == "__main__":
    main()