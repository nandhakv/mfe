"""
Agent package for processing and managing document-related tasks.
"""

__version__ = "0.1.0"

# Import key components to make them available at package level
from .agent import Agent  # noqa: F401
from .exceptions import AgentError  # noqa: F401
from .logger import logger, setup_logger  # noqa: F401

# Update __all__ to include the logger
__all__ = ['Agent', 'AgentError', 'logger', 'setup_logger']
