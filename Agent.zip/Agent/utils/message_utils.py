"""
Utility functions for message handling in the agent system.
"""

from datetime import datetime
from typing import List, Dict, Any


def add_message_to_list(messages: List[Dict], role: str, content: Any) -> List[Dict]:
    """
    Appends a new message to a list of messages and returns the new list.
    
    Args:
        messages: List of existing messages
        role: Role of the message sender (user, assistant, system, etc.)
        content: Content of the message
        
    Returns:
        Updated list of messages
    """
    messages.append({
        "role": role, 
        "content": content, 
        "timestamp": datetime.now().isoformat()
    })
    return messages


def create_message(role: str, content: Any) -> Dict[str, Any]:
    """
    Create a new message with timestamp.
    
    Args:
        role: Role of the message sender
        content: Content of the message
        
    Returns:
        Message dictionary
    """
    return {
        "role": role,
        "content": content,
        "timestamp": datetime.now().isoformat()
    }


def get_last_user_message(messages: List[Dict]) -> str:
    """
    Get the content of the last user message.
    
    Args:
        messages: List of messages
        
    Returns:
        Content of the last user message or empty string
    """
    for message in reversed(messages):
        if message.get("role") == "user":
            return message.get("content", "")
    return ""


def get_conversation_summary(messages: List[Dict], max_messages: int = 10) -> List[Dict]:
    """
    Get a summary of recent messages for context.
    
    Args:
        messages: List of all messages
        max_messages: Maximum number of recent messages to include
        
    Returns:
        List of recent messages
    """
    return messages[-max_messages:] if len(messages) > max_messages else messages 