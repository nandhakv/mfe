"""Test the simplified reflect node."""

import pytest
from unittest.mock import patch, MagicMock
from nodes.reflect import ReflectNode

def test_reflect_node_creation():
    """Test that the reflect node can be created."""
    reflect_node = ReflectNode()
    assert reflect_node is not None
    assert hasattr(reflect_node, 'tool_registry')

def test_reflect_node_with_tool_results():
    """Test reflect node with tool results."""
    reflect_node = ReflectNode()
    
    # Mock state with tool results
    state = {
        "query": "What was the root cause of ticket 114781?",
        "tool_results": [
            {
                "tool_name": "get_ticket",
                "success": True,
                "result": {"id": 114781, "subject": "Product page getting crashed"}
            }
        ],
        "messages": [
            {"role": "user", "content": "What was the root cause of ticket 114781?"}
        ]
    }
    
    # Mock the LLM response
    mock_response = '''```json
{
  "reasoning": "I have the ticket details but need to search for relevant code to understand the root cause",
  "tool_calls": [
    {
      "tool_name": "knowledge_base_search",
      "parameters": {
        "query": "product page crash white screen"
      }
    }
  ]
}
```'''
    
    with patch('llm.generate_response', return_value=mock_response):
        result = reflect_node(state)
        
        assert "tool_execution_plans" in result
        assert result["last_reflection_decision"] == "call_tool"
        assert len(result["tool_execution_plans"]["tool_calls"]) == 1
        assert result["tool_execution_plans"]["tool_calls"][0]["tool_name"] == "knowledge_base_search"

def test_reflect_node_generate_response():
    """Test reflect node deciding to generate response."""
    reflect_node = ReflectNode()
    
    # Mock state with tool results
    state = {
        "query": "What was the root cause of ticket 114781?",
        "tool_results": [
            {
                "tool_name": "get_ticket",
                "success": True,
                "result": {"id": 114781, "subject": "Product page getting crashed"}
            },
            {
                "tool_name": "code_search",
                "success": True,
                "result": {"files": ["product.js"], "content": "Error in render function"}
            }
        ],
        "messages": [
            {"role": "user", "content": "What was the root cause of ticket 114781?"}
        ]
    }
    
    # Mock the LLM response
    mock_response = '''```json
{
  "reasoning": "I have enough evidence to provide a complete analysis",
  "response": "The root cause was an error in the render function in product.js"
}
```'''
    
    with patch('llm.generate_response', return_value=mock_response):
        result = reflect_node(state)
        
        assert "last_reflection_decision" in result
        assert result["last_reflection_decision"] == "generate"
        assert "reasoning" in result

def test_reflect_node_error_handling():
    """Test reflect node error handling."""
    reflect_node = ReflectNode()
    
    state = {
        "query": "What was the root cause of ticket 114781?",
        "tool_results": [],
        "messages": []
    }
    
    # Mock LLM error
    with patch('llm.generate_response', side_effect=Exception("LLM Error")):
        result = reflect_node(state)
        
        assert "error" in result
        assert result["last_reflection_decision"] == "generate"

if __name__ == "__main__":
    pytest.main([__file__, "-v"]) 