"""
Simplified and improved agent implementation with better type safety and error handling.
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional, Union, Callable
from dataclasses import dataclass
from enum import Enum

from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages

from state import AgentState, get_initial_state
from utils.logging_utils import logger

class AgentStatus(str, Enum):
    """Agent execution status."""
    IDLE = "idle"
    PLANNING = "planning"
    EXECUTING = "executing"
    REFLECTING = "reflecting"
    GENERATING = "generating"
    COMPLETED = "completed"
    ERROR = "error"

@dataclass
class AgentConfig:
    """Configuration for the agent."""
    name: str = "Phoenix"
    max_iterations: int = 10
    timeout_seconds: int = 300
    enable_streaming: bool = False
    debug_mode: bool = False

class SimplifiedAgent:
    """
    Simplified agent with improved type safety and error handling.
    
    Key improvements:
    - Type-safe node implementations
    - Better error handling and recovery
    - Simplified configuration
    - Improved logging and debugging
    - Cleaner separation of concerns
    """
    
    def __init__(self, config: Optional[AgentConfig] = None):
        """Initialize the agent with configuration."""
        self.config = config or AgentConfig()
        self.logger = logger
        
        # Initialize components
        self._init_components()
        self._build_graph()
        
        self.logger.info(f"Initialized agent '{self.config.name}' with {self.config.max_iterations} max iterations")
    
    def _init_components(self):
        """Initialize agent components."""
        from nodes.planner import PlannerNode
        from nodes.tool_executor import ToolExecutorNode
        from nodes.reflect import ReflectNode
        from nodes.generator import GeneratorNode
        
        # Initialize tools first
        import os
        from constants import DEFAULT_DB_URL
        from database import get_database
        from tools import initialize_enhanced_tools
        
        # Set database URL if not already set
        if "DATABASE_URL" not in os.environ:
            os.environ["DATABASE_URL"] = DEFAULT_DB_URL
        
        db = get_database()
        initialize_enhanced_tools(db)
        
        self.planner = PlannerNode()
        self.tool_executor = ToolExecutorNode()
        self.reflector = ReflectNode()
        self.generator = GeneratorNode()
    
    def _build_graph(self):
        """Build the execution graph with proper type handling."""
        # Create the state graph
        workflow = StateGraph(AgentState)
        
        # Add nodes with proper function signatures
        workflow.add_node("planner", self._planner_node)
        workflow.add_node("executor", self._executor_node)
        workflow.add_node("reflector", self._reflector_node)
        workflow.add_node("generator", self._generator_node)
        
        # Set entry point
        workflow.set_entry_point("planner")
        
        # Conditional routing after planner
        workflow.add_conditional_edges(
            "planner",
            self._route_after_planning,
            {
                "executor": "executor",
                "generator": "generator"
            }
        )
        
        # Add edges
        workflow.add_edge("executor", "reflector")
        
        # Conditional routing after reflection
        workflow.add_conditional_edges(
            "reflector",
            self._route_after_reflection,
            {
                "executor": "executor",
                "generator": "generator"
            }
        )
        
        workflow.add_edge("generator", END)
        
        # Compile the graph
        self.graph = workflow.compile()
    
    def _planner_node(self, state: AgentState) -> AgentState:
        """Planner node with proper error handling."""
        try:
            self.logger.info("Executing planner node")
            state["status"] = AgentStatus.PLANNING
            
            # Call the planner with dict conversion
            result = self.planner(dict(state))
            
            # Update state with planner results
            for key, value in result.items():
                state[key] = value
            
            # Set status based on whether tools will be used
            tool_execution_plans = state.get("tool_execution_plans")
            tool_calls = tool_execution_plans.get("tool_calls", []) if tool_execution_plans else []
            
            if tool_calls:
                state["status"] = AgentStatus.EXECUTING
                self.logger.info(f"Planner completed with {len(tool_calls)} tool calls")
            else:
                state["status"] = AgentStatus.GENERATING
                self.logger.info("Planner completed - no tools needed, going to generator")
            
            return state
            
        except Exception as e:
            self.logger.error(f"Planner failed: {e}")
            state["error"] = f"Planning failed: {str(e)}"
            state["status"] = AgentStatus.ERROR
            return state
    
    def _executor_node(self, state: AgentState) -> AgentState:
        """Executor node with proper error handling."""
        try:
            self.logger.info("Executing tool executor node")
            state["status"] = AgentStatus.EXECUTING
            
            # Call the tool executor with dict conversion
            result = self.tool_executor(dict(state))
            
            # Update state with execution results
            for key, value in result.items():
                state[key] = value
            state["status"] = AgentStatus.REFLECTING
            
            self.logger.info("Tool execution completed successfully")
            return state
            
        except Exception as e:
            self.logger.error(f"Tool execution failed: {e}")
            state["error"] = f"Tool execution failed: {str(e)}"
            state["status"] = AgentStatus.ERROR
            return state
    
    def _reflector_node(self, state: AgentState) -> AgentState:
        """Reflector node with proper error handling."""
        try:
            self.logger.info("Executing reflector node")
            state["status"] = AgentStatus.REFLECTING
            
            # Call the reflector with dict conversion
            result = self.reflector(dict(state))
            
            # Update state with reflection results
            for key, value in result.items():
                state[key] = value
            
            self.logger.info("Reflection completed successfully")
            return state
            
        except Exception as e:
            self.logger.error(f"Reflection failed: {e}")
            state["error"] = f"Reflection failed: {str(e)}"
            state["status"] = AgentStatus.ERROR
            return state
    
    def _generator_node(self, state: AgentState) -> AgentState:
        """Generator node with proper error handling."""
        try:
            self.logger.info("Executing generator node")
            state["status"] = AgentStatus.GENERATING
            
            # Call the generator with dict conversion
            result = self.generator(dict(state))
            
            # Update state with generation results
            for key, value in result.items():
                state[key] = value
            state["status"] = AgentStatus.COMPLETED
            
            self.logger.info("Generation completed successfully")
            return state
            
        except Exception as e:
            self.logger.error(f"Generation failed: {e}")
            state["error"] = f"Generation failed: {str(e)}"
            state["status"] = AgentStatus.ERROR
            return state
    
    def _route_after_planning(self, state: AgentState) -> str:
        """Route to next node based on planning decision."""
        # Check if planner decided to use tools
        tool_execution_plans = state.get("tool_execution_plans")
        tool_calls = tool_execution_plans.get("tool_calls", []) if tool_execution_plans else []
        
        self.logger.info(f"Planning decision: {len(tool_calls)} tool calls planned")
        
        # If no tools are planned, go directly to generator
        if not tool_calls:
            self.logger.info("No tools planned, routing directly to generator")
            return "generator"
        
        # If tools are planned, go to executor
        self.logger.info(f"Routing to executor with {len(tool_calls)} tool calls")
        return "executor"
    
    def _route_after_reflection(self, state: AgentState) -> str:
        """Route to next node based on reflection decision."""
        decision = state.get("last_reflection_decision")
        if decision is None:
            decision = "generate"
        else:
            decision = decision.lower()
            
        iteration_count = state.get("iteration_count")
        if iteration_count is None:
            iteration_count = 0
        
        self.logger.info(f"Routing decision: {decision}, iteration: {iteration_count}")
        
        # Check for infinite loops
        if iteration_count >= self.config.max_iterations:
            self.logger.warning(f"Max iterations ({self.config.max_iterations}) reached, forcing generation")
            return "generator"
        
        # Check for errors
        if state.get("error"):
            self.logger.warning("Error detected, forcing generation")
            return "generator"
        
        if decision == "call_tool":
            # Increment iteration count
            state["iteration_count"] = iteration_count + 1
            return "executor"
        else:
            return "generator"
    
    def run(self, query: str, stream: bool = False) -> Union[str, List[str]]:
        """
        Run the agent with the given query.
        
        Args:
            query: The user query to process
            stream: Whether to stream the response
            
        Returns:
            The agent's response (string or list of strings for streaming)
        """
        self.logger.info(f"Starting agent execution with query: {query[:100]}...")
        
        try:
            # Initialize state
            initial_state = get_initial_state(query)
            initial_state["status"] = AgentStatus.IDLE
            initial_state["iteration_count"] = 0
            initial_state["start_time"] = datetime.now().isoformat()
            
            # Execute the graph
            final_state = self.graph.invoke(initial_state)  # type: ignore
            
            # Extract response
            response = final_state.get("output", "I'm sorry, I couldn't generate a response.")
            error = final_state.get("error")
            
            # Log completion
            execution_time = datetime.now().isoformat()
            self.logger.info(f"Agent execution completed in {execution_time}")
            
            if error:
                self.logger.error(f"Agent execution finished with error: {error}")
                response = f"I encountered an error: {error}"
            
            # Handle streaming
            if stream and self.config.enable_streaming:
                return self._stream_response(response)
            else:
                return response
                
        except Exception as e:
            error_msg = f"Agent execution failed: {str(e)}"
            self.logger.error(error_msg)
            
            if stream:
                return [error_msg]
            else:
                return error_msg
    
    def _stream_response(self, response: str) -> List[str]:
        """Convert response to streaming format."""
        lines = []
        for line in response.splitlines():
            if line.strip():
                lines.append(line.strip())
        return lines
    
    async def run_async(self, query: str) -> Union[str, List[str]]:
        """Run the agent asynchronously."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.run, query)
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status and statistics."""
        return {
            "name": self.config.name,
            "max_iterations": self.config.max_iterations,
            "timeout_seconds": self.config.timeout_seconds,
            "enable_streaming": self.config.enable_streaming,
            "debug_mode": self.config.debug_mode
        }

# Backward compatibility alias
Agent = SimplifiedAgent

def create_agent(
    name: str = "Phoenix",
    max_iterations: int = 10,
    timeout_seconds: int = 300,
    enable_streaming: bool = False,
    debug_mode: bool = False
) -> SimplifiedAgent:
    """
    Factory function to create an agent with custom configuration.
    
    Args:
        name: Agent name
        max_iterations: Maximum number of tool execution iterations
        timeout_seconds: Maximum execution time in seconds
        enable_streaming: Whether to enable streaming responses
        debug_mode: Whether to enable debug logging
        
    Returns:
        Configured agent instance
    """
    config = AgentConfig(
        name=name,
        max_iterations=max_iterations,
        timeout_seconds=timeout_seconds,
        enable_streaming=enable_streaming,
        debug_mode=debug_mode
    )
    return SimplifiedAgent(config)

if __name__ == "__main__":
    # --- TOOL REGISTRATION ---
    import os
    from constants import DEFAULT_DB_URL
    os.environ["DATABASE_URL"] = DEFAULT_DB_URL
    from database import get_database
    from tools.search import get_search_tools
    from tools.freshdesk import get_freshdesk_tools

    # Initialize and register all tools
    db = get_database()
    get_search_tools(db)
    get_freshdesk_tools()

    # --- AGENT EXECUTION ---
    agent = create_agent(
        name="Phoenix",
        max_iterations=10,
        debug_mode=True
    )

    # Sample query to test
    query = "What was the root cause of ticket 114781? analyse the code and provide the fix with example"
    print(f"\n💭 Query: {query}")
    
    try:
        response = agent.run(query)
        print(f"\n✅ Agent execution completed successfully")
    except KeyboardInterrupt:
        print("\n\nAgent execution interrupted by user.")
    except Exception as e:
        print(f"\n❌ Error processing query: {str(e)}")
        import traceback
        traceback.print_exc()