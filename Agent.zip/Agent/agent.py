# agent.py
"""Main agent implementation using a ReAct-style node-based architecture."""

import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional
import time

from langgraph.graph import StateGraph, END

from nodes.planner import PlannerNode
from nodes.tool_executor import ToolExecutorNode
from nodes.reflect import ReflectNode
from nodes.generator import GeneratorNode
from state import AgentState, get_initial_state
from tools.registry import ToolRegistry
from utils.logging_utils import logger
import llm.llm as llm_mod

class Agent:
    """The main agent class that orchestrates the execution flow."""

    def __init__(self, name="Phoenix", system_prompt=None):
        logger.info("Initializing agent...")
        self.name = name
        self.system_prompt = system_prompt or f"You are {name}, a helpful AI assistant."
        self.tool_registry = ToolRegistry()
        self.planner_node = self._create_planner_node()
        self.tool_executor_node = self._create_tool_executor_node()
        self.reflect_node = self._create_reflect_node()
        self.generator_node = self._create_generator_node()
        self.graph = self._build_graph()

    @staticmethod
    def add_message_to_list(messages: List[Dict], role: str, content: Any) -> List[Dict]:
        """Appends a new message to a list of messages and returns the new list. Only allows Claude 3.5 supported roles."""
        # Map custom/internal roles to Claude-supported roles
        role_map = {
            "system": "system",
            "user": "user",
            "assistant": "assistant",
            "tool": "tool",
            "internal reflection": "assistant",
            "internal action planning": "assistant",
            "internal action tool results": "tool",
            "internal action no tools": "assistant",
            "internal action error": "assistant",
            # Add more mappings as needed
        }
        mapped_role = role_map.get(role, "assistant")
        messages.append({"role": mapped_role, "content": content, "timestamp": datetime.now().isoformat()})
        return messages

    def _route_after_reflection(self, state: Dict[str, Any]) -> str:
        """Routes based on the reflector's decision to either call another tool or generate a response."""
        decision = state.get("last_reflection_decision", "generate").lower()
        logger.info(f"Routing after reflection. Decision: '{decision}'.")

        if decision == "call_tool":
            logger.info("Routing back to tool executor for the next action.")
            return "run_tools"
        else:  # Default to generation
            logger.info("Routing to generator to create the final response.")
            return "generator"

    def _build_graph(self) -> StateGraph:
        """Build the agent's execution graph with a ReAct-style loop."""
        graph = StateGraph(AgentState)

        graph.add_node("planner", self.planner_node)
        graph.add_node("run_tools", self.tool_executor_node)
        graph.add_node("reflect", self.reflect_node)
        graph.add_node("generator", self.generator_node)

        graph.set_entry_point("planner")

        # After the planner, always go to the tool executor for the first action
        graph.add_edge("planner", "run_tools")

        # After executing a tool, always reflect
        graph.add_edge("run_tools", "reflect")

        # After reflecting, decide whether to call another tool or generate a response
        graph.add_conditional_edges(
            "reflect",
            self._route_after_reflection,
            {
                "run_tools": "run_tools",
                "generator": "generator"
            }
        )
        
        graph.add_edge("generator", END)

        return graph.compile()

    def _create_planner_node(self):
        return PlannerNode()

    def _create_tool_executor_node(self):
        return ToolExecutorNode()

    def _create_reflect_node(self):
        return ReflectNode()

    def _create_generator_node(self):
        return GeneratorNode()

    def run(self, query):
        # Set up token counter for this run
        llm_mod.AGENT_TOKEN_COUNTER = {'prompt': 0, 'response': 0, 'total': 0}
        start_time = time.time()
        
        # Performance metrics
        metrics = {
            'start_time': start_time,
            'tool_calls': 0,
            'llm_calls': 0,
            'errors': 0
        }
        
        initial_state = get_initial_state(query)
        final_state = self.graph.invoke(initial_state)
        elapsed = time.time() - start_time
        
        response = final_state.get("output", "I'm sorry, I couldn't generate a response.")
        if final_state.get("error"):
            logger.error(f"Agent run finished with error: {final_state['error']}")
            metrics['errors'] += 1
        
        # Calculate metrics from final state
        tool_results = final_state.get("tool_results", [])
        metrics['tool_calls'] = len(tool_results)
        
        # Print timing, token, and cost info with performance metrics
        token_counter = llm_mod.AGENT_TOKEN_COUNTER
        prompt_tokens = token_counter['prompt']
        response_tokens = token_counter['response']
        total_tokens = token_counter['total']
        
        # Claude 3.5 Sonnet pricing
        input_cost = (prompt_tokens / 1000) * 0.003
        output_cost = (response_tokens / 1000) * 0.015
        total_cost = input_cost + output_cost
        
        # Calculate efficiency metrics
        tokens_per_second = total_tokens / elapsed if elapsed > 0 else 0
        cost_per_tool_call = total_cost / metrics['tool_calls'] if metrics['tool_calls'] > 0 else 0
        
        print(f"\n---")
        print(f"⏱️  Performance Metrics:")
        print(f"   Time taken: {elapsed:.2f} seconds")
        print(f"   Tool calls: {metrics['tool_calls']}")
        print(f"   Errors: {metrics['errors']}")
        print(f"   Tokens/sec: {tokens_per_second:.1f}")
        print(f"   Cost/tool: ${cost_per_tool_call:.6f}")
        print(f"")
        print(f"💰 Cost Analysis:")
        print(f"   Total tokens: {total_tokens} (prompt: {prompt_tokens}, response: {response_tokens})")
        print(f"   Total cost: ${total_cost:.6f} (input: ${input_cost:.6f}, output: ${output_cost:.6f})")
        print(f"---")
        
        return response

    def run_stream(self, query):
        response = self.run(query)
        for line in response.splitlines():
            if line.strip():
                yield line


if __name__ == "__main__":
    # --- TOOL REGISTRATION ---
    import os
    from constants import DEFAULT_DB_URL
    os.environ["DATABASE_URL"] = DEFAULT_DB_URL
    from database import get_database
    from tools.search import get_search_tools
    from tools.freshdesk import get_freshdesk_tools
    from tools.registry import TOOL_REGISTRY

    # Initialize and register all tools
    db = get_database()
    get_search_tools(db)
    get_freshdesk_tools()

    print("\n🛠️  Registered Tools:")
    for tool_name in TOOL_REGISTRY.tools.keys():
        print(f"  - {tool_name}")

    # --- AGENT EXECUTION ---
    agent = Agent()

    # Print available tools ONCE
    print("\n🛠️  Registered Tools:")
    for tool_name in TOOL_REGISTRY.tools.keys():
        print(f"  - {tool_name}")

    # Sample queries to test
    test_queries = [
        # "What is the difference between SCF and colending products?",
        # "Explain how service wise poc and alert works",
        # "What is the status of ticket 114737?",
        # "How much support tickets we received yesterday on our organisation and how many of them closed?",
        "Explain this ticket 114830 first then provide a way to solve the problem and find the root cause"
    ]

    for query in test_queries:
        print(f"\n💭 Query: {query}")
        try:
            response = agent.run(query)
            print("\n🧠 Response:")
            print(response)
        except KeyboardInterrupt:
            print("\n\nAgent execution interrupted by user.")
            break
        except Exception as e:
            print(f"\n❌ Error processing query: {str(e)}")