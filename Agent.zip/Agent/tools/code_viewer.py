"""
Code Viewer Tool - Read and view code files from repositories.

This tool fetches code chunks from the database and reconstructs the full file content
for viewing and analysis purposes.
"""

from typing import Optional, List
from tools.registry import TOOL_REGISTRY
from tools.base import ToolCategory, ToolPriority
from tools.models import CodeViewerInput, CodeViewerResult
import os

from database import get_database

def view_code_file(input: CodeViewerInput) -> CodeViewerResult:
    """
    Fetch all code_chunks from the database matching repository_id and file_path, 
    merge chunk_texts in order, and return the full file content with metadata.
    
    Args:
        input: CodeViewerInput containing repository_id and file_path
        
    Returns:
        CodeViewerResult with reconstructed file content and metadata
        
    Raises:
        FileNotFoundError: If no code chunks found for the specified file
    """
    db = get_database()
    session_factory = db.session_factory
    
    with session_factory() as session:
        from sqlalchemy import text
        
        # Get all code chunks for the file
        rows = session.execute(
            text("""
            SELECT chunk_text, start_line, end_line, id
            FROM code_chunks
            WHERE repository_id = :repository_id AND file_path = :file_path
            ORDER BY start_line ASC NULLS FIRST, id ASC
            """),
            {"repository_id": input.repository_id, "file_path": input.file_path}
        ).fetchall()
        
        if not rows:
            raise FileNotFoundError(
                f"No code chunks found for repository_id={input.repository_id}, "
                f"file_path={input.file_path}"
            )
        
        # Reconstruct the file content
        content = "".join(row.chunk_text for row in rows)
        
        # Calculate metadata
        total_lines = len(content.splitlines())
        file_size = len(content.encode('utf-8'))
        chunks_count = len(rows)
        
        # Build metadata if requested
        metadata = None
        if input.include_metadata:
            metadata = {
                "chunks": [
                    {
                        "chunk_id": row.id,
                        "start_line": row.start_line,
                        "end_line": row.end_line,
                        "chunk_size": len(row.chunk_text)
                    }
                    for row in rows
                ],
                "file_extension": os.path.splitext(input.file_path)[1],
                "file_name": os.path.basename(input.file_path),
                "directory": os.path.dirname(input.file_path)
            }
        
        return CodeViewerResult(
            repository_id=input.repository_id,
            file_path=input.file_path,
            content=content,
            total_lines=total_lines,
            file_size=file_size,
            chunks_count=chunks_count,
            metadata=metadata
        )

# Register with enhanced registry
@TOOL_REGISTRY.register(
    name="view_code_file",
    description="View the full content of a code file from a repository by repository_id and file_path.",
    category=ToolCategory.UTILITY,
    priority=ToolPriority.NORMAL,
    timeout=30.0,
    max_retries=2,
    cache_ttl=300,  # 5 minutes
    rate_limit=10.0,  # 10 requests per second
    tags=["code", "repository", "file", "viewer"]
)
def enhanced_view_code_file(input: CodeViewerInput) -> CodeViewerResult:
    """Enhanced version of view_code_file with better error handling and performance."""
    return view_code_file(input)

# Legacy function for backward compatibility
def view_file(input: CodeViewerInput) -> CodeViewerResult:
    """Legacy function for backward compatibility."""
    return view_code_file(input)
