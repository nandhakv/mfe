"""
Base tool classes and utilities for improved tool architecture.
"""

import asyncio
import functools
import logging
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type, TypeVar, Callable, Union
from dataclasses import dataclass
from enum import Enum
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager

from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

# Type variables
T = TypeVar('T')
InputT = TypeVar('InputT', bound=BaseModel)
OutputT = TypeVar('OutputT', bound=BaseModel)

class ToolCategory(str, Enum):
    """Categories for organizing tools."""
    SEARCH = "search"
    EXTERNAL_API = "external_api"
    DATABASE = "database"
    UTILITY = "utility"
    ANALYSIS = "analysis"

class ToolPriority(int, Enum):
    """Priority levels for tool execution."""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

@dataclass
class ToolMetadata:
    """Metadata for tool registration and management."""
    name: str
    description: str
    category: ToolCategory
    priority: ToolPriority = ToolPriority.NORMAL
    version: str = "1.0.0"
    timeout: float = 30.0
    max_retries: int = 3
    cache_ttl: int = 300  # 5 minutes
    rate_limit: Optional[float] = None  # requests per second
    requires_auth: bool = False
    tags: Optional[List[str]] = None

class ToolError(Exception):
    """Base exception for tool-related errors."""
    def __init__(self, message: str, tool_name: Optional[str] = None, retryable: bool = True):
        super().__init__(message)
        self.tool_name = tool_name
        self.retryable = retryable

class ToolTimeoutError(ToolError):
    """Raised when a tool execution times out."""
    def __init__(self, tool_name: str, timeout: float):
        super().__init__(f"Tool '{tool_name}' timed out after {timeout}s", tool_name, retryable=True)

class ToolValidationError(ToolError):
    """Raised when tool input validation fails."""
    def __init__(self, tool_name: str, validation_errors: List[str]):
        super().__init__(f"Validation failed for tool '{tool_name}': {validation_errors}", tool_name, retryable=False)

class CacheManager:
    """Simple in-memory cache with TTL support."""
    
    def __init__(self):
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._executor = ThreadPoolExecutor(max_workers=4)
    
    def _generate_key(self, tool_name: str, params: Dict[str, Any]) -> str:
        """Generate a cache key from tool name and parameters."""
        param_str = json.dumps(params, sort_keys=True)
        return hashlib.md5(f"{tool_name}:{param_str}".encode()).hexdigest()
    
    def get(self, tool_name: str, params: Dict[str, Any]) -> Optional[Any]:
        """Get a cached result if it exists and is not expired."""
        key = self._generate_key(tool_name, params)
        if key in self._cache:
            entry = self._cache[key]
            if time.time() < entry['expires_at']:
                logger.debug(f"Cache hit for tool '{tool_name}'")
                return entry['value']
            else:
                del self._cache[key]
        return None
    
    def set(self, tool_name: str, params: Dict[str, Any], value: Any, ttl: int):
        """Cache a result with TTL."""
        key = self._generate_key(tool_name, params)
        self._cache[key] = {
            'value': value,
            'expires_at': time.time() + ttl
        }
        logger.debug(f"Cached result for tool '{tool_name}' with TTL {ttl}s")
    
    def clear(self):
        """Clear all cached entries."""
        self._cache.clear()
        logger.info("Cache cleared")

class RateLimiter:
    """Simple rate limiter for tools."""
    
    def __init__(self):
        self._last_call: Dict[str, float] = {}
        self._min_interval: Dict[str, float] = {}
    
    def set_rate_limit(self, tool_name: str, requests_per_second: float):
        """Set rate limit for a tool."""
        if requests_per_second > 0:
            self._min_interval[tool_name] = 1.0 / requests_per_second
    
    def wait_if_needed(self, tool_name: str):
        """Wait if necessary to respect rate limits."""
        if tool_name in self._min_interval:
            min_interval = self._min_interval[tool_name]
            last_call = self._last_call.get(tool_name, 0)
            time_since_last = time.time() - last_call
            
            if time_since_last < min_interval:
                sleep_time = min_interval - time_since_last
                logger.debug(f"Rate limiting tool '{tool_name}' for {sleep_time:.2f}s")
                time.sleep(sleep_time)
            
            self._last_call[tool_name] = time.time()

class BaseTool(ABC):
    """Base class for all tools with common functionality."""
    
    def __init__(self, metadata: ToolMetadata):
        self.metadata = metadata
        self.cache = CacheManager()
        self.rate_limiter = RateLimiter()
        if metadata.rate_limit:
            self.rate_limiter.set_rate_limit(metadata.name, metadata.rate_limit)
    
    @abstractmethod
    def execute(self, input_data: InputT) -> OutputT:
        """Execute the tool with the given input."""
        pass
    
    def execute_with_retry(self, input_data: InputT) -> OutputT:
        """Execute the tool with retry logic and error handling."""
        last_error = None
        
        for attempt in range(self.metadata.max_retries + 1):
            try:
                # Check cache first
                if self.metadata.cache_ttl > 0 and input_data is not None:
                    cached_result = self.cache.get(self.metadata.name, input_data.dict())
                    if cached_result is not None:
                        return cached_result
                
                # Rate limiting
                self.rate_limiter.wait_if_needed(self.metadata.name)
                
                # Execute with timeout
                if asyncio.iscoroutinefunction(self.execute):
                    # Async execution
                    loop = asyncio.get_event_loop()
                    result = loop.run_until_complete(
                        asyncio.wait_for(self.execute(input_data), timeout=self.metadata.timeout)
                    )
                else:
                    # Sync execution with timeout
                    with ThreadPoolExecutor(max_workers=1) as executor:
                        future = executor.submit(self.execute, input_data)
                        result = future.result(timeout=self.metadata.timeout)
                
                # Cache the result
                if self.metadata.cache_ttl > 0:
                    self.cache.set(self.metadata.name, input_data.dict(), result, self.metadata.cache_ttl)
                
                return result  # type: ignore
                
            except asyncio.TimeoutError:
                error = ToolTimeoutError(self.metadata.name, self.metadata.timeout)
                logger.warning(f"Attempt {attempt + 1} failed: {error}")
                last_error = error
                
            except ValidationError as e:
                error = ToolValidationError(self.metadata.name, [str(err) for err in e.errors()])
                logger.error(f"Validation error: {error}")
                raise error
                
            except Exception as e:
                error = ToolError(f"Tool execution failed: {str(e)}", self.metadata.name)
                logger.warning(f"Attempt {attempt + 1} failed: {error}")
                last_error = error
                
                if attempt == self.metadata.max_retries:
                    break
                
                # Exponential backoff
                if attempt < self.metadata.max_retries:
                    wait_time = 2 ** attempt
                    logger.info(f"Retrying in {wait_time}s...")
                    time.sleep(wait_time)
        
        # All retries exhausted
        raise last_error or ToolError("Unknown error occurred", self.metadata.name)

class AsyncBaseTool(BaseTool):
    """Base class for async tools."""
    
    @abstractmethod
    async def execute(self, input_data: InputT) -> OutputT:
        """Execute the tool asynchronously."""
        pass

def tool_decorator(
    name: str,
    description: str,
    category: ToolCategory = ToolCategory.UTILITY,
    priority: ToolPriority = ToolPriority.NORMAL,
    version: str = "1.0.0",
    timeout: float = 30.0,
    max_retries: int = 3,
    cache_ttl: int = 300,
    rate_limit: Optional[float] = None,
    requires_auth: bool = False,
    tags: Optional[List[str]] = None
):
    """Decorator for registering tools with metadata."""
    def decorator(func: Callable) -> Callable:
        metadata = ToolMetadata(
            name=name,
            description=description,
            category=category,
            priority=priority,
            version=version,
            timeout=timeout,
            max_retries=max_retries,
            cache_ttl=cache_ttl,
            rate_limit=rate_limit,
            requires_auth=requires_auth,
            tags=tags or []
        )
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create a temporary tool instance for execution
            class TempTool(BaseTool):
                def execute(self, input_data):
                    return func(*args, **kwargs)
            
            tool = TempTool(metadata)
            # Create a dummy input model for compatibility
            class DummyInput(BaseModel):
                pass
            dummy_input = DummyInput()
            return tool.execute_with_retry(dummy_input)  # No input validation for now
        
        # Attach metadata to the function
        setattr(wrapper, 'metadata', metadata)
        setattr(wrapper, 'is_tool', True)
        
        return wrapper
    return decorator 