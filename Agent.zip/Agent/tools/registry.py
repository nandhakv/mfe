"""
Simplified tool registry for the agent workflow.
"""

import asyncio
import logging
import time
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import json

from .base import ToolMetadata, ToolCategory, ToolPriority, ToolError

logger = logging.getLogger(__name__)

class ToolStatus(str, Enum):
    """Status of a tool."""
    ACTIVE = "active"
    DISABLED = "disabled"

@dataclass
class ToolExecutionStats:
    """Statistics for tool execution."""
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    last_error: Optional[str] = None

class ToolRegistry:
    """
    Simplified tool registry for the agent workflow.
    Focuses on core functionality: registration, async handling, and model conversion.
    """
    
    def __init__(self):
        self._tools: Dict[str, Dict[str, Any]] = {}
        self._tool_stats: Dict[str, ToolExecutionStats] = {}
        
    def register(
        self,
        name: str,
        description: str = "",
        category: ToolCategory = ToolCategory.UTILITY,
        priority: ToolPriority = ToolPriority.NORMAL,
        version: str = "1.0.0",
        timeout: float = 30.0,
        max_retries: int = 3,
        cache_ttl: int = 300,
        rate_limit: Optional[float] = None,
        requires_auth: bool = False,
        tags: Optional[List[str]] = None,
        dependencies: Optional[List[str]] = None,
        health_check: Optional[Callable] = None
    ) -> Callable:
        """
        Decorator to register a tool function with metadata.
        """
        def decorator(func: Callable) -> Callable:
            metadata = ToolMetadata(
                name=name,
                description=description,
                category=category,
                priority=priority,
                version=version,
                timeout=timeout,
                max_retries=max_retries,
                cache_ttl=cache_ttl,
                rate_limit=rate_limit,
                requires_auth=requires_auth,
                tags=tags or []
            )
            
            # Store tool metadata
            self._tools[name] = {
                "function": func,
                "metadata": metadata,
                "status": ToolStatus.ACTIVE,
                "registered_at": time.time()
            }
            
            # Initialize stats
            self._tool_stats[name] = ToolExecutionStats()
            
            logger.info(f"Registered tool '{name}' with metadata: {metadata}")
            return func
            
        return decorator
    
    def call(self, name: str, **kwargs) -> Any:
        """Call a registered tool by name with proper async handling and model conversion."""
        if name not in self._tools:
            raise ValueError(f"Tool '{name}' not found. Available tools: {', '.join(self._tools.keys())}")
        
        tool = self._tools[name]
        func = tool["function"]
        stats = self._tool_stats[name]
        
        logger.debug(f"Tool '{name}' called with kwargs: {kwargs}")
        
        try:
            # Import models
            from .models import (
                GetTicketInput, GetTicketConversationInput, GetTicketsInput,
                SearchTicketsInput, GetAgentsInput, ListContactsInput,
                GetContactInput, SearchContactsInput,
                KnowledgeBaseSearchInput, DocumentSearchInput, CodeSearchInput,
                CodeViewerInput
            )
            
            # Map tool names to their input models
            model_map = {
                "get_ticket": GetTicketInput,
                "get_ticket_conversation": GetTicketConversationInput,
                "get_tickets": GetTicketsInput,
                "search_tickets": SearchTicketsInput,
                "get_agents": GetAgentsInput,
                "list_contacts": ListContactsInput,
                "get_contact": GetContactInput,
                "search_contacts": SearchContactsInput,
                "knowledge_base_search": KnowledgeBaseSearchInput,
                "document_search": DocumentSearchInput,
                "code_search": CodeSearchInput,
                "view_code_file": CodeViewerInput
            }
            
            if name in model_map:
                # Create the input model from kwargs
                input_model = model_map[name](**kwargs)
                logger.debug(f"Created {model_map[name].__name__} for tool '{name}': {input_model}")
                
                # Execute function with model (both sync and async)
                if asyncio.iscoroutinefunction(func):
                    result = self._run_async_function(func, input_model)
                else:
                    result = func(input_model)
            else:
                # For other functions, try calling directly with kwargs
                if asyncio.iscoroutinefunction(func):
                    result = self._run_async_function(func, **kwargs)
                else:
                    result = func(**kwargs)
            
            # Update stats
            stats.total_calls += 1
            stats.successful_calls += 1
            
            return result
            
        except Exception as e:
            # Update stats
            stats.total_calls += 1
            stats.failed_calls += 1
            stats.last_error = str(e)
            
            logger.error(f"Tool '{name}' failed: {str(e)}")
            raise ToolError(f"Tool execution failed: {str(e)}", name)
    

    
    def _run_async_function(self, func: Callable, *args, **kwargs) -> Any:
        """Run an async function in the appropriate context."""
        try:
            # Try to get the current event loop
            loop = asyncio.get_running_loop()
            
            # If we're in an event loop, create a new one in a thread
            import threading
            result_container = {}
            
            def run_in_new_loop():
                new_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(new_loop)
                try:
                    if args and not kwargs:
                        result_container['result'] = new_loop.run_until_complete(func(*args))
                    else:
                        result_container['result'] = new_loop.run_until_complete(func(**kwargs))
                finally:
                    new_loop.close()
            
            t = threading.Thread(target=run_in_new_loop)
            t.start()
            t.join()
            
            if 'error' in result_container:
                raise result_container['error']
            
            return result_container['result']
            
        except RuntimeError:
            # No running event loop, create a new one
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if args and not kwargs:
                    return loop.run_until_complete(func(*args))
                else:
                    return loop.run_until_complete(func(**kwargs))
            finally:
                loop.close()
    
    def get_tool_info(self, name: str) -> Dict[str, Any]:
        """Get detailed information about a tool."""
        if name not in self._tools:
            raise ValueError(f"Tool '{name}' not found")
        
        tool = self._tools[name]
        stats = self._tool_stats[name]
        
        return {
            "name": name,
            "metadata": tool["metadata"],
            "status": tool["status"],
            "stats": stats,
            "registered_at": tool["registered_at"]
        }
    
    def list_tools(self, category: Optional[ToolCategory] = None) -> List[Dict[str, Any]]:
        """List all tools with optional filtering by category."""
        tools = []
        for name in self._tools:
            tool_info = self.get_tool_info(name)
            if category is None or tool_info["metadata"].category == category:
                tools.append(tool_info)
        return tools
    
    def get_stats(self) -> Dict[str, Any]:
        """Get overall registry statistics."""
        total_tools = len(self._tools)
        active_tools = sum(1 for t in self._tools.values() if t["status"] == ToolStatus.ACTIVE)
        total_calls = sum(s.total_calls for s in self._tool_stats.values())
        total_successful = sum(s.successful_calls for s in self._tool_stats.values())
        total_failed = sum(s.failed_calls for s in self._tool_stats.values())
        
        return {
            "total_tools": total_tools,
            "active_tools": active_tools,
            "total_calls": total_calls,
            "successful_calls": total_successful,
            "failed_calls": total_failed,
            "success_rate": total_successful / total_calls if total_calls > 0 else 0
        }

# Global registry instance
TOOL_REGISTRY = ToolRegistry()

def get_registry() -> ToolRegistry:
    """Get the global tool registry instance."""
    return TOOL_REGISTRY 