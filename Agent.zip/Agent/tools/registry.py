"""
Tool registry for managing and accessing tools.
"""

from typing import Dict, Callable, List, Any, Optional, Type, TypeVar
from functools import wraps
import inspect
import logging

logger = logging.getLogger(__name__)


T = TypeVar('T')

class ToolRegistry:
    """
    Registry for managing tools in a centralized way.
    """
    def __init__(self):
        self.tools: Dict[str, dict] = {}

    def register(
        self,
        name: str,
        description: str = "",
        input_model: Optional[Type[Any]] = None,
        output_model: Optional[Type[Any]] = None
    ) -> Callable:
        """
        Decorator to register a tool function.
        
        Args:
            name: Unique name for the tool
            description: Description of what the tool does
            input_model: Optional Pydantic model for input validation
            output_model: Optional Pydantic model for output validation
        """
        def decorator(func: Callable) -> Callable:
            # Get function signature and parameters
            sig = inspect.signature(func)
            params = {}
            
            for param in sig.parameters.values():
                params[param.name] = {
                    "type": param.annotation if param.annotation != inspect.Parameter.empty else Any,
                    "default": param.default if param.default != inspect.Parameter.empty else None,
                    "required": param.default == inspect.Parameter.empty
                }
            
            # Store tool metadata
            self.tools[name] = {
                "function": func,
                "description": description or func.__doc__ or "",
                "parameters": params,
                "input_model": input_model,
                "output_model": output_model
            }
            
            @wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
                
            return wrapper
        return decorator

    def call(self, name: str, **kwargs) -> Any:
        """
        Call a registered tool by name.
        
        Args:
            name: Name of the tool to call
            **kwargs: Arguments to pass to the tool
            
        Returns:
            Result from the tool
            
        Raises:
            ValueError: If the tool is not found
        """
        if name not in self.tools:
            raise ValueError(f"Tool '{name}' not found. Available tools: {', '.join(self.tools.keys())}")
            
        tool = self.tools[name]
        
        # Validate input if input_model is provided
        if tool["input_model"] is not None:
            try:
                validated_input = tool["input_model"](**kwargs)
                kwargs = validated_input.dict()
            except Exception as e:
                raise ValueError(f"Invalid input for tool '{name}': {str(e)}")
        
        # Call the tool function
        try:
            result = tool["function"](**kwargs)
            
            # Validate output if output_model is provided
            if tool["output_model"] is not None:
                if isinstance(result, tool["output_model"]):
                    # If the result is already an instance of the output model, return it as is
                    return result
                elif isinstance(result, dict):
                    # If the result is a dict, try to create a new instance from it
                    result = tool["output_model"](**result)
                else:
                    # For other types, try to create a new instance with the result as a single argument
                    result = tool["output_model"](result)
                    
            return result
            
        except Exception as e:
            logger.error(f"Error calling tool '{name}': {str(e)}", exc_info=True)
            raise
    
    def get_tool_schema(self, name: str) -> dict:
        """Get the schema for a specific tool."""
        if name not in self.tools:
            raise ValueError(f"Tool '{name}' not found")
            
        tool = self.tools[name]
        return {
            "name": name,
            "description": tool["description"],
            "parameters": tool["parameters"],
            "input_model": tool["input_model"].schema() if tool["input_model"] else None,
            "output_model": tool["output_model"].schema() if tool["output_model"] else None
        }
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """List all registered tools with their schemas."""
        return [self.get_tool_schema(name) for name in self.tools]

# Global registry instance
TOOL_REGISTRY = ToolRegistry()

def format_tool_info_with_args(tools: dict) -> str:
    """
    Format tool info for planning prompts, including expanded argument schemas from pydantic models.
    Args:
        tools: Dictionary of tool metadata from the registry
    Returns:
        str: Formatted string listing tools, descriptions, and expanded argument schemas
    """
    if not tools:
        return "No tools available."
    lines = []
    for name, info in tools.items():
        desc = info.get("description", "No description")
        lines.append(f"- {name}: {desc}")
        params = info.get("parameters", {})
        # If input_model is a pydantic model, expand its fields
        input_model = info.get("input_model")
        if input_model and hasattr(input_model, '__fields__'):
            lines.append("  Arguments:")
            for field_name, field in input_model.__fields__.items():
                field_type = field.annotation.__name__ if hasattr(field.annotation, "__name__") else str(field.annotation)
                default = field.default if field.default is not None else "<required>"
                # Compatible with both Pydantic v1 and v2
                desc = getattr(getattr(field, "field_info", field), "description", "") or ""
                lines.append(f"    - {field_name} ({field_type}): {desc} Default: {default}")
        elif params:
            lines.append("  Arguments:")
            for param, meta in params.items():
                param_type = getattr(meta.get("type"), "__name__", str(meta.get("type")))
                param_desc = meta.get("description", "")
                required = meta.get("required", False)
                lines.append(f"    - {param} ({param_type}){' [required]' if required else ''}: {param_desc}")
    return "\n".join(lines)

def get_tool_registry() -> ToolRegistry:
    """Get the global tool registry instance."""
    return TOOL_REGISTRY
