"""
Enhanced tools for the Agent with improved performance, reliability, and usability.

This module provides a comprehensive tooling system with:
- Enhanced registry with performance monitoring
- Optimized search tools with caching
- Code viewer for repository file access
- Freshdesk integration tools
- Comprehensive search models
"""

import logging
import json
import os
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

# Enhanced components
from .base import (
    BaseTool, AsyncBaseTool, ToolMetadata, ToolCategory, ToolPriority,
    ToolError, ToolTimeoutError, ToolValidationError, CacheManager, RateLimiter
)
from .registry import TOOL_REGISTRY, get_registry
from .search import SearchTools, get_search_tools

# Models
from .models import (
    KnowledgeBaseSearchInput, DocumentSearchInput, CodeSearchInput,
    KnowledgeBaseSearchResult, DocumentSearchResult, CodeSearchResult,
    SearchStats, SearchFilter,
    GetTicketsInput, GetTicketInput, SearchTicketsInput, GetTicketConversationInput,
    GetAgentsInput, ListContactsInput, GetContactInput, SearchContactsInput,
    CodeViewerInput, CodeViewerResult
)

# Code viewer tool
from .code_viewer import (
    CodeViewerInput, CodeViewerResult, view_code_file, enhanced_view_code_file
)

# Freshdesk tools
from .freshdesk import (
    get_freshdesk_tools, get_enhanced_freshdesk_tools,
    # Individual tool functions
    get_ticket_fields, get_tickets, get_ticket, search_tickets,
    get_ticket_conversation, get_agents, list_contacts, get_contact, search_contacts
)

# Re-export all components
__all__ = [
    # Enhanced base classes
    "BaseTool",
    "AsyncBaseTool", 
    "ToolMetadata",
    "ToolCategory",
    "ToolPriority",
    "ToolError",
    "ToolTimeoutError",
    "ToolValidationError",
    "CacheManager",
    "RateLimiter",
    
    # Registry
    "TOOL_REGISTRY",
    "get_registry",
    
    # Search
    "SearchTools",
    "get_search_tools",
    
    # Models
    "KnowledgeBaseSearchInput",
    "DocumentSearchInput", 
    "CodeSearchInput",
    "KnowledgeBaseSearchResult",
    "DocumentSearchResult",
    "CodeSearchResult",
    "SearchStats",
    "SearchFilter",
    "GetTicketsInput",
    "GetTicketInput",
    "SearchTicketsInput",
    "GetTicketConversationInput",
    "GetAgentsInput",
    "ListContactsInput",
    "GetContactInput",
    "SearchContactsInput",
    "CodeViewerInput",
    "CodeViewerResult",
    
    # Code viewer
    "CodeViewerInput",
    "CodeViewerResult",
    "view_code_file",
    "enhanced_view_code_file",
    
    # Freshdesk tools
    "get_freshdesk_tools",
    "get_enhanced_freshdesk_tools",
    "get_ticket_fields",
    "get_tickets",
    "get_ticket",
    "search_tickets",
    "get_ticket_conversation",
    "get_agents",
    "list_contacts",
    "get_contact",
    "search_contacts",
    "load_tool_definitions",
    "get_tool_list",
    "get_tool_by_name"
]

def initialize_enhanced_tools(db, config=None):
    """
    Initialize and register all enhanced tools with the global registry.
    
    Args:
        db: Database instance
        config: Optional configuration dictionary
        
    Returns:
        Dictionary of initialized tool instances
    """
    # Initialize search tools
    search_tools = get_search_tools(db)
    
    # Get registry
    registry = get_registry()
    
    logger.info(f"Initialized enhanced tools: {len(registry.list_tools())} tools registered")
    
    return {
        "search": search_tools,
        "registry": registry
    }

def get_tool_performance_stats():
    """Get performance statistics for all tools."""
    registry = get_registry()
    
    return {
        "registry_stats": registry.get_stats()
    }

def health_check_all_tools():
    """Perform health checks for all tools."""
    registry = get_registry()
    # Simplified registry doesn't have health checks
    return {name: True for name in registry._tools.keys()}

def list_available_tools():
    """Get a list of all available tools with their metadata."""
    registry = get_registry()
    tools = registry.list_tools()
    
    return [
        {
            "name": tool["name"],
            "description": tool["metadata"].description,
            "category": tool["metadata"].category.value,
            "priority": tool["metadata"].priority.value,
            "tags": tool["metadata"].tags,
            "status": tool["status"].value
        }
        for tool in tools
    ]

def load_tool_definitions() -> Dict[str, Any]:
    """
    Load tool definitions from the JSON file.
    
    Returns:
        Dictionary containing tools and internal_tags
    """
    tool_definitions_path = os.path.join(os.path.dirname(__file__), 'tool_definitions.json')
    
    try:
        with open(tool_definitions_path, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Warning: Tool definitions file not found at {tool_definitions_path}")
        return {"tools": [], "internal_tags": []}

def get_tool_list() -> List[Dict[str, Any]]:
    """
    Get a list of all available tools for the LLM.
    
    Returns:
        List of tool definitions
    """
    definitions = load_tool_definitions()
    return definitions.get("tools", [])

def get_tool_by_name(name: str) -> Optional[Dict[str, Any]]:
    """
    Get a specific tool by name.
    
    Args:
        name: Tool name
        
    Returns:
        Tool definition or None if not found
    """
    tools = get_tool_list()
    for tool in tools:
        if tool.get("name") == name:
            return tool
    return None
