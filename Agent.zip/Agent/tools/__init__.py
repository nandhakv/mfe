"""
Tools for the Agent, including search, classification, and a tool registry.
"""

from .registry import TOOL_REGISTRY, ToolRegistry, get_tool_registry
from .search import SearchTools, get_search_tools
from . import search 


# Re-export the tool registry and related functions
__all__ = [
    "TOOL_REGISTRY",
    "ToolRegistry",
    "get_tool_registry",
    "SearchTools",
    "get_search_tools",
    "ClassificationTools",
    "get_classification_tools"
]

def initialize_tools(db, config=None):
    """
    Initialize and register all tools with the global registry.
    
    Args:
        db: Database instance
        config: Optional configuration
        
    Returns:
        Dictionary of initialized tool instances
    """
    # Initialize tool instances
    search_tools = get_search_tools(db)
    classification_tools = get_classification_tools(config)
    
    # All tools are automatically registered via their __init__ methods
    return {
        "search": search_tools,
        "classification": classification_tools
    }
