import logging
import base64
import re
from typing import Optional, Dict, Any, List
import httpx
from tools.registry import TOOL_REGISTRY
from tools.base import ToolCategory, ToolPriority
from tools.models import (
    GetTicketsInput,
    GetTicketInput,
    SearchTicketsInput,
    GetTicketConversationInput,
    GetAgentsInput,
    ListContactsInput,
    GetContactInput,
    SearchContactsInput
)
from constants import FRESHDESK_API_KEY, FRESHDESK_DOMAIN, FRESHDESK_COOKIE

logger = logging.getLogger(__name__)

# --- Enhanced Tool Functions ---

@TOOL_REGISTRY.register(
    name="get_ticket_fields",
    description="Get all available ticket fields from Freshdesk.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.NORMAL,
    timeout=30.0,
    max_retries=2,
    cache_ttl=3600,  # 1 hour
    rate_limit=5.0,  # 5 requests per second
    tags=["freshdesk", "tickets", "fields"]
)
async def get_ticket_fields() -> List[Dict[str, Any]]:
    """Get all available ticket fields from Freshdesk."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/ticket_fields"
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.json()

@TOOL_REGISTRY.register(
    name="get_tickets",
    description="Get tickets from Freshdesk with pagination support.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.NORMAL,
    timeout=60.0,
    max_retries=2,
    cache_ttl=300,  # 5 minutes
    rate_limit=3.0,  # 3 requests per second
    tags=["freshdesk", "tickets", "list"]
)
async def get_tickets(data: GetTicketsInput) -> List[Dict[str, Any]]:
    """Get tickets from Freshdesk with pagination support."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/tickets"
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    all_tickets = []
    page = data.page or 1
    per_page = data.per_page or 30
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        while True:
            params = {"page": page, "per_page": per_page}
            response = await client.get(url, params=params)
            response.raise_for_status()
            tickets = response.json()
            if not tickets:
                break
            all_tickets.extend(tickets)
            if len(tickets) < per_page:
                break
            page += 1
    return all_tickets

@TOOL_REGISTRY.register(
    name="get_ticket",
    description="Get a single ticket by its ID.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.HIGH,
    timeout=30.0,
    max_retries=3,
    cache_ttl=600,  # 10 minutes
    rate_limit=5.0,  # 5 requests per second
    tags=["freshdesk", "tickets", "detail"]
)
async def get_ticket(data: GetTicketInput) -> Dict[str, Any]:
    """Get a single ticket by its ID."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/tickets/{data.ticket_id}"
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url)
        response.raise_for_status()
        raw_data = response.json()
        cleaned_data = cleanup_freshdesk_response(raw_data)
        # logger.info(f"[TOOL] get_ticket: output={cleaned_data}")
        return cleaned_data

@TOOL_REGISTRY.register(
    name="search_tickets",
    description="Search for tickets using a KQL query string.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.NORMAL,
    timeout=45.0,
    max_retries=2,
    cache_ttl=300,  # 5 minutes
    rate_limit=3.0,  # 3 requests per second
    tags=["freshdesk", "tickets", "search"]
)
async def search_tickets(data: SearchTicketsInput) -> Dict[str, Any]:
    """Search for tickets using a KQL query string."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/search/tickets"
    # Freshdesk API requires the query to be enclosed in double quotes
    params = {"query": f'"{data.query}"'}
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        raw_data = response.json()
        return cleanup_freshdesk_response(raw_data)

@TOOL_REGISTRY.register(
    name="get_ticket_conversation",
    description="Get the conversation history for a ticket.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.NORMAL,
    timeout=30.0,
    max_retries=2,
    cache_ttl=300,  # 5 minutes
    rate_limit=5.0,  # 5 requests per second
    tags=["freshdesk", "tickets", "conversation"]
)
async def get_ticket_conversation(data: GetTicketConversationInput) -> List[Dict[str, Any]]:
    """Get the conversation history for a ticket."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/tickets/{data.ticket_id}/conversations"
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url)
        response.raise_for_status()
        raw_data = response.json()
        return cleanup_freshdesk_response(raw_data)

@TOOL_REGISTRY.register(
    name="get_agents",
    description="Get a list of all agents.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.LOW,
    timeout=30.0,
    max_retries=2,
    cache_ttl=1800,  # 30 minutes
    rate_limit=2.0,  # 2 requests per second
    tags=["freshdesk", "agents", "list"]
)
async def get_agents(data: GetAgentsInput) -> List[Dict[str, Any]]:
    """Get a list of all agents."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/agents"
    params = {"page": data.page, "per_page": data.per_page}
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        raw_data = response.json()
        return cleanup_freshdesk_response(raw_data)

@TOOL_REGISTRY.register(
    name="list_contacts",
    description="List all contacts with pagination.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.LOW,
    timeout=30.0,
    max_retries=2,
    cache_ttl=600,  # 10 minutes
    rate_limit=3.0,  # 3 requests per second
    tags=["freshdesk", "contacts", "list"]
)
async def list_contacts(data: ListContactsInput) -> List[Dict[str, Any]]:
    """List all contacts with pagination."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/contacts"
    params = {"page": data.page, "per_page": data.per_page}
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        raw_data = response.json()
        return cleanup_freshdesk_response(raw_data)

@TOOL_REGISTRY.register(
    name="get_contact",
    description="Get a single contact by ID.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.NORMAL,
    timeout=30.0,
    max_retries=2,
    cache_ttl=600,  # 10 minutes
    rate_limit=5.0,  # 5 requests per second
    tags=["freshdesk", "contacts", "detail"]
)
async def get_contact(data: GetContactInput) -> Dict[str, Any]:
    """Get a single contact by ID."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/contacts/{data.contact_id}"
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url)
        response.raise_for_status()
        raw_data = response.json()
        return cleanup_freshdesk_response(raw_data)

@TOOL_REGISTRY.register(
    name="search_contacts",
    description="Search for contacts by name or email.",
    category=ToolCategory.EXTERNAL_API,
    priority=ToolPriority.NORMAL,
    timeout=30.0,
    max_retries=2,
    cache_ttl=300,  # 5 minutes
    rate_limit=5.0,  # 5 requests per second
    tags=["freshdesk", "contacts", "search"]
)
async def search_contacts(data: SearchContactsInput) -> List[Dict[str, Any]]:
    """Search for contacts by name or email."""
    url = f"https://{FRESHDESK_DOMAIN}/api/v2/contacts/autocomplete"
    params = {"term": data.query}
    headers = {
        "Authorization": f"Basic {FRESHDESK_API_KEY}",
        "Content-Type": "application/json"
    }
    if FRESHDESK_COOKIE:
        headers["Cookie"] = FRESHDESK_COOKIE
    async with httpx.AsyncClient(verify=False, headers=headers) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        raw_data = response.json()
        return cleanup_freshdesk_response(raw_data)

# --- Legacy Class for Backward Compatibility ---

class FreshdeskTools:
    """Legacy class for backward compatibility. Use individual functions instead."""
    
    def __init__(self):
        logger.warning("FreshdeskTools class is deprecated. Use individual functions instead.")
    
    async def get_ticket_fields(self) -> List[Dict[str, Any]]:
        return await get_ticket_fields()
    
    async def get_tickets(self, data: GetTicketsInput) -> List[Dict[str, Any]]:
        return await get_tickets(data)
    
    async def get_ticket(self, data: GetTicketInput) -> Dict[str, Any]:
        return await get_ticket(data)
    
    async def search_tickets(self, data: SearchTicketsInput) -> Dict[str, Any]:
        return await search_tickets(data)
    
    async def get_ticket_conversation(self, data: GetTicketConversationInput) -> List[Dict[str, Any]]:
        return await get_ticket_conversation(data)
    
    async def get_agents(self, data: GetAgentsInput) -> List[Dict[str, Any]]:
        return await get_agents(data)
    
    async def list_contacts(self, data: ListContactsInput) -> List[Dict[str, Any]]:
        return await list_contacts(data)
    
    async def get_contact(self, data: GetContactInput) -> Dict[str, Any]:
        return await get_contact(data)
    
    async def search_contacts(self, data: SearchContactsInput) -> List[Dict[str, Any]]:
        return await search_contacts(data)

# --- Utility Functions ---

def get_freshdesk_tools() -> FreshdeskTools:
    """Get an instance of FreshdeskTools for backward compatibility."""
    return FreshdeskTools()

def get_enhanced_freshdesk_tools() -> FreshdeskTools:
    """Alias for get_freshdesk_tools for clarity in enhanced registry context."""
    return FreshdeskTools()

def cleanup_freshdesk_response(data: Any) -> Any:
    """
    Clean up Freshdesk API responses by removing HTML tags and unwanted formatting.
    Also compresses the response to reduce token usage.
    
    Args:
        data: The raw response data from Freshdesk API
        
    Returns:
        Cleaned and compressed data with HTML removed and formatting normalized
    """
    if isinstance(data, dict):
        cleaned = {}
        # Only include essential fields for ticket analysis
        essential_fields = {
            'id', 'subject', 'description', 'description_text', 'status', 'priority', 
            'type', 'source', 'created_at', 'updated_at', 'due_by', 'requester_id',
            'responder_id', 'group_id', 'company_id', 'custom_fields', 'tags'
        }
        
        for key, value in data.items():
            # Skip non-essential fields to reduce token usage
            if key not in essential_fields and not key.startswith('cf_'):
                continue
                
            if key in ['description', 'description_text', 'body', 'body_text']:
                # Clean up text fields that commonly contain HTML
                cleaned[key] = cleanup_text_field(value)
            elif key == 'custom_fields':
                # Clean up custom fields recursively
                cleaned[key] = cleanup_freshdesk_response(value)
            elif key in ['cc_emails', 'fwd_emails', 'reply_cc_emails', 'ticket_cc_emails', 'ticket_bcc_emails']:
                # Limit email arrays to first 3 entries to reduce token usage
                if isinstance(value, list) and len(value) > 3:
                    cleaned[key] = value[:3] + [f"... and {len(value) - 3} more"]
                else:
                    cleaned[key] = value
            else:
                cleaned[key] = cleanup_freshdesk_response(value)
        return cleaned
    elif isinstance(data, list):
        # Limit list size to reduce token usage
        if len(data) > 5:
            return [cleanup_freshdesk_response(item) for item in data[:5]] + [f"... and {len(data) - 5} more items"]
        return [cleanup_freshdesk_response(item) for item in data]
    else:
        return data

def cleanup_text_field(text: str) -> str:
    """
    Clean up a text field by removing HTML tags and normalizing formatting.
    
    Args:
        text: Raw text that may contain HTML
        
    Returns:
        Cleaned text without HTML tags
    """
    if not isinstance(text, str):
        return text
    
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', '', text)
    
    # Remove common Freshdesk artifacts
    text = re.sub(r'&nbsp;', ' ', text)  # Replace non-breaking spaces
    text = re.sub(r'&amp;', '&', text)   # Replace HTML entities
    text = re.sub(r'&lt;', '<', text)
    text = re.sub(r'&gt;', '>', text)
    text = re.sub(r'&quot;', '"', text)
    
    # Remove image tags and their content
    text = re.sub(r'\[image:[^\]]+\]', '', text)
    
    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text)  # Replace multiple whitespace with single space
    text = re.sub(r'\n\s*\n', '\n\n', text)  # Normalize line breaks
    
    # Remove excessive newlines
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    # Strip leading/trailing whitespace
    text = text.strip()
    
    return text

# Main function removed - this module is for tool registration only
