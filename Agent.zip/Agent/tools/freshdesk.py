import logging
import base64
from typing import Optional, Dict, Any, List
import httpx
from pydantic import BaseModel, Field
from tools.registry import TOOL_REGISTRY
from constants import FRESHDESK_API_KEY, FRESHDESK_DOMAIN, FRESHDESK_COOKIE

logger = logging.getLogger(__name__)
registry = TOOL_REGISTRY

# --- Input/Output Models ---

class GetTicketsInput(BaseModel):
    page: Optional[int] = Field(1, description="The page number of results to fetch.")
    per_page: Optional[int] = Field(30, description="The number of results per page (max 100).")

class GetTicketInput(BaseModel):
    ticket_id: int = Field(..., description="The unique ID of the ticket.")

class SearchTicketsInput(BaseModel):
    query: str = Field(..., description="The KQL query string to search for tickets.")

class GetTicketConversationInput(BaseModel):
    ticket_id: int = Field(..., description="The unique ID of the ticket to get conversations for.")

class GetAgentsInput(BaseModel):
    page: Optional[int] = Field(1, description="The page number of results to fetch.")
    per_page: Optional[int] = Field(30, description="The number of results per page (max 100).")

class ListContactsInput(BaseModel):
    page: Optional[int] = Field(1, description="The page number of results to fetch.")
    per_page: Optional[int] = Field(30, description="The number of results per page (max 100).")

class GetContactInput(BaseModel):
    contact_id: int = Field(..., description="The unique ID of the contact.")

class SearchContactsInput(BaseModel):
    query: str = Field(..., description="The search query string for contacts (name or email)." )

# --- Main Tools Class ---

class FreshdeskTools:
    """Collection of read-only Freshdesk tools for the Agent."""

    def __init__(self):
        self._register_tools()

    def _register_tools(self):
        """Register all read-only tools with the registry."""
        registry.register(name="get_ticket_fields", description="Get all available ticket fields from Freshdesk.", input_model=None, output_model=List[Dict[str, Any]])(self.get_ticket_fields)
        registry.register(name="get_tickets", description="Get tickets from Freshdesk with pagination support.", input_model=GetTicketsInput, output_model=List[Dict[str, Any]])(self.get_tickets)
        registry.register(name="get_ticket", description="Get a single ticket by its ID.", input_model=GetTicketInput, output_model=Dict[str, Any])(self.get_ticket)
        registry.register(name="search_tickets", description="Search for tickets using a KQL query string.", input_model=SearchTicketsInput, output_model=Dict[str, Any])(self.search_tickets)
        registry.register(name="get_ticket_conversation", description="Get the conversation history for a ticket.", input_model=GetTicketConversationInput, output_model=List[Dict[str, Any]])(self.get_ticket_conversation)
        registry.register(name="get_agents", description="Get a list of all agents.", input_model=GetAgentsInput, output_model=List[Dict[str, Any]])(self.get_agents)
        registry.register(name="list_contacts", description="List all contacts with pagination.", input_model=ListContactsInput, output_model=List[Dict[str, Any]])(self.list_contacts)
        registry.register(name="get_contact", description="Get a single contact by ID.", input_model=GetContactInput, output_model=Dict[str, Any])(self.get_contact)
        registry.register(name="search_contacts", description="Search for contacts by name or email.", input_model=SearchContactsInput, output_model=List[Dict[str, Any]])(self.search_contacts)

    # --- Tool Implementations ---

    async def get_ticket_fields(self) -> List[Dict[str, Any]]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/ticket_fields"
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.json()

    async def get_tickets(self, data: GetTicketsInput) -> List[Dict[str, Any]]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/tickets"
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        all_tickets = []
        page = data.page or 1
        per_page = data.per_page or 30
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            while True:
                params = {"page": page, "per_page": per_page}
                response = await client.get(url, params=params)
                response.raise_for_status()
                tickets = response.json()
                if not tickets:
                    break
                all_tickets.extend(tickets)
                if len(tickets) < per_page:
                    break
                page += 1
        return all_tickets


    async def get_ticket(self, data: GetTicketInput) -> Dict[str, Any]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/tickets/{data.ticket_id}"
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url)
            response.raise_for_status()
            logger.info(f"[TOOL] get_ticket: output={response.json()}")
            print(f"[TOOL] get_ticket: output={response.json()}")
            return response.json()

    async def search_tickets(self, data: SearchTicketsInput) -> Dict[str, Any]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/search/tickets"
        # Freshdesk API requires the query to be enclosed in double quotes
        params = {"query": f'"{data.query}"'}
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()

    async def get_ticket_conversation(self, data: GetTicketConversationInput) -> List[Dict[str, Any]]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/tickets/{data.ticket_id}/conversations"
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.json()

    async def get_agents(self, data: GetAgentsInput) -> List[Dict[str, Any]]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/agents"
        params = {"page": data.page, "per_page": data.per_page}
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()

    async def list_contacts(self, data: ListContactsInput) -> List[Dict[str, Any]]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/contacts"
        params = {"page": data.page, "per_page": data.per_page}
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()

    async def get_contact(self, data: GetContactInput) -> Dict[str, Any]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/contacts/{data.contact_id}"
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.json()

    async def search_contacts(self, data: SearchContactsInput) -> List[Dict[str, Any]]:
        url = f"https://{FRESHDESK_DOMAIN}/api/v2/contacts/autocomplete"
        params = {"term": data.query}
        headers = {
            "Authorization": f"Basic {FRESHDESK_API_KEY}",
            "Content-Type": "application/json"
        }
        if FRESHDESK_COOKIE:
            headers["Cookie"] = FRESHDESK_COOKIE
        async with httpx.AsyncClient(verify=False, headers=headers) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            return response.json()

def get_freshdesk_tools() -> FreshdeskTools:
    """Get an instance of FreshdeskTools, which registers all read-only tools."""
    return FreshdeskTools()
# (For brevity, the code is not repeated here, but will be written in full in the file)

def main():
    logging.info("Starting Freshdesk MCP server")
    mcp.run(transport='stdio')

if __name__ == "__main__":
    main()
