from typing import Optional
from pydantic import BaseModel, Field
from tools.registry import TOOL_REGISTRY
import os

class ViewFileInput(BaseModel):
    repository_id: str = Field(..., description="The unique ID of the repository.")
    file_path: str = Field(..., description="The path to the file within the repository.")

class ViewFileResult(BaseModel):
    repository_id: str
    file_path: str
    content: str

from database import get_database

def view_file(input: ViewFileInput) -> ViewFileResult:
    """
    Fetch all code_chunks from the database matching repository_id and file_path, merge chunk_texts in order, and return the full file content.
    """
    db = get_database()
    session_factory = db.session_factory
    with session_factory() as session:
        from sqlalchemy import text
        rows = session.execute(
            text("""
            SELECT chunk_text, start_line
            FROM code_chunks
            WHERE repository_id = :repository_id AND file_path = :file_path
            ORDER BY start_line ASC NULLS FIRST, id ASC
            """),
            {"repository_id": input.repository_id, "file_path": input.file_path}
        ).fetchall()
        if not rows:
            raise FileNotFoundError(f"No code chunks found for repository_id={input.repository_id}, file_path={input.file_path}")
        content = "".join(row.chunk_text for row in rows)
    return ViewFileResult(repository_id=input.repository_id, file_path=input.file_path, content=content)

TOOL_REGISTRY.register(
    name="view_file",
    description="View the full content of a file in a repository by repository_id and file_path.",
    input_model=ViewFileInput,
    output_model=ViewFileResult
)(view_file)
