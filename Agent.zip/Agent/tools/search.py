"""
Enhanced search tools with optimized performance.
"""

import time
import logging
import numpy as np
import psycopg2
import psycopg2.extras
from typing import List, Dict, Any, Tuple, Optional, Union
from sentence_transformers import SentenceTransformer

from constants import DEFAULT_DB_URL
from exceptions import SearchError
from tools.registry import TOOL_REGISTRY, ToolCategory, ToolPriority
from tools.models import (
    KnowledgeBaseSearchInput, KnowledgeBaseSearchResult, KnowledgeBaseMatch,
    DocumentSearchInput, DocumentSearchResult, DocumentChunk,
    CodeSearchInput, CodeSearchResult, CodeChunk
)

logger = logging.getLogger(__name__)

class SearchTools:
    """
    Search tools with enhanced performance features:
    - Embedding caching and batching
    - Connection pooling
    - Optimized database queries
    """

    def __init__(self, db=None, model_name="sentence-transformers/all-MiniLM-L6-v2"):
        """Initialize search tools with database connection and embedding model."""
        self.db = db
        self.model_name = model_name
        self._embedding_model = None
        self._connection_pool = []
        self._max_pool_size = 5
        
        # Initialize embedding model
        self._initialize_model()
        
        # Initialize connection pool
        self._initialize_connections()
        
        # Register tools
        self._register_tools()
        
        logger.info(f"Initialized optimized search tools with model: {model_name}")

    def _initialize_model(self):
        """Initialize the embedding model."""
        try:
            logger.info(f"Loading Hugging Face model: {self.model_name}")
            self._embedding_model = SentenceTransformer(self.model_name)
            logger.info("Embedding model loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")
            raise ValueError(f"Failed to initialize embedding model: {str(e)}")

    def _initialize_connections(self):
        """Initialize database connection pool."""
        try:
            for _ in range(self._max_pool_size):
                conn = psycopg2.connect(DEFAULT_DB_URL)
                self._connection_pool.append(conn)
            logger.info(f"Initialized {len(self._connection_pool)} database connections")
        except Exception as e:
            logger.error(f"Failed to initialize database connections: {e}")
            raise ValueError(f"Failed to initialize database connections: {str(e)}")

    def _get_connection(self):
        """Get a connection from the pool."""
        if not self._connection_pool:
            conn = psycopg2.connect(DEFAULT_DB_URL)
            return conn
        return self._connection_pool.pop()

    def _return_connection(self, conn):
        """Return a connection to the pool."""
        if len(self._connection_pool) < self._max_pool_size:
            self._connection_pool.append(conn)
        else:
            conn.close()

    def get_embedding(self, text: str) -> np.ndarray:
        """Get embedding for a single text."""
        if not text:
            return np.zeros(384)  # Default embedding dimension
        
        try:
            return self._embedding_model.encode(text)
        except Exception as e:
            logger.error(f"Embedding generation failed: {e}")
            return np.zeros(384)  # Return zero vector on error

    def get_embeddings_batch(self, texts: List[str]) -> List[np.ndarray]:
        """Get embeddings for a batch of texts."""
        if not texts:
            return []
        
        try:
            return self._embedding_model.encode(texts)
        except Exception as e:
            logger.error(f"Batch embedding generation failed: {e}")
            return [np.zeros(384) for _ in texts]  # Return zero vectors on error
    
    def _register_tools(self):
        """Register all search tools with the enhanced registry."""
        
        @TOOL_REGISTRY.register(
            name="knowledge_base_search",
            description="Identify the most relevant product or domain (knowledge base) for a support ticket or query. Use this tool to route tickets to the correct product team by matching the ticket's context (title/description) with product knowledge bases.",
            category=ToolCategory.SEARCH,
            priority=ToolPriority.HIGH,
            timeout=15.0,
            max_retries=2,
            cache_ttl=600,  # 10 minutes
            rate_limit=10.0,  # 10 requests per second
            tags=["search", "routing", "knowledge-base"]
        )
        def knowledge_base_search(input: KnowledgeBaseSearchInput) -> KnowledgeBaseSearchResult:
            return self._knowledge_base_search_optimized(input)
        
        @TOOL_REGISTRY.register(
            name="document_search",
            description="Find the most relevant document or document chunk for a query within a specific product's knowledge base, or across all KBs. Use this to answer support questions, troubleshoot issues, or provide detailed product/process information to customers or internal teams.",
            category=ToolCategory.SEARCH,
            priority=ToolPriority.HIGH,
            timeout=20.0,
            max_retries=3,
            cache_ttl=300,  # 5 minutes
            rate_limit=5.0,  # 5 requests per second
            tags=["search", "documents", "content"]
        )
        def document_search(input: DocumentSearchInput) -> DocumentSearchResult:
            return self._document_search_optimized(input)
        
        @TOOL_REGISTRY.register(
            name="code_search",
            description="Retrieve relevant code snippets or implementation details from indexed repositories linked to a product knowledge base. Use this tool for technical support queries, bug triage, or developer onboarding.",
            category=ToolCategory.SEARCH,
            priority=ToolPriority.HIGH,
            timeout=25.0,
            max_retries=3,
            cache_ttl=300,  # 5 minutes
            rate_limit=3.0,  # 3 requests per second
            tags=["search", "code", "development"]
        )
        def code_search(input: CodeSearchInput) -> CodeSearchResult:
            return self._code_search_optimized(input)

    def _fetch_knowledge_bases_with_embeddings(self, kb_type: Optional[str]) -> list:
        """Fetch all KBs and their embeddings."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cursor:
                sql = """
                    SELECT id, name, description, created_at, updated_at
                    FROM knowledge_bases
                """
                params = []
                if kb_type:
                    sql += " WHERE type = %s"
                    params.append(kb_type)
                sql += " ORDER BY created_at DESC"
                cursor.execute(sql, params)
                return cursor.fetchall()
        finally:
            self._return_connection(conn)

    def _cosine_similarity(self, a, b):
        """Calculate cosine similarity between two vectors."""
        import numpy as np
        a = np.array(a)
        b = np.array(b)
        return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

    def _knowledge_base_search_optimized(self, input: KnowledgeBaseSearchInput) -> KnowledgeBaseSearchResult:
        """Optimized knowledge base search with pure embedding-based semantic search."""
        import numpy as np
        start_time = time.time()
        query = input.query
        threshold = input.threshold or 0.1
        limit = input.limit or 5
        kb_type = input.type

        logger.info(f"[TOOL] knowledge_base_search: input={{'query': {query}, 'threshold': {threshold}, 'limit': {limit}, 'type': {kb_type}}}")

        try:
            # 1. Fetch all KBs
            kb_rows = self._fetch_knowledge_bases_with_embeddings(kb_type)

            # 2. Prepare texts for embedding
            kb_texts = [
                (str(row[0]), (row[1] or "") + " " + (row[2] or ""))
                for row in kb_rows
            ]
            kb_ids = [row[0] for row in kb_rows]
            kb_names = [row[1] for row in kb_rows]
            kb_descs = [row[2] for row in kb_rows]
            kb_created = [row[3] for row in kb_rows]
            kb_updated = [row[4] for row in kb_rows]

            # 3. Generate embeddings for all KBs (batch)
            kb_embeddings = self.get_embeddings_batch([txt for _, txt in kb_texts])

            # 4. Generate embedding for the query
            query_embedding = self.get_embedding(query)

            # 5. Compute similarity and filter
            scored_kbs = []
            for i, emb in enumerate(kb_embeddings):
                sim = float(np.dot(query_embedding, emb) / (np.linalg.norm(query_embedding) * np.linalg.norm(emb)))
                if sim >= threshold:
                    scored_kbs.append((sim, KnowledgeBaseMatch(
                        id=str(kb_ids[i]),
                        name=kb_names[i],
                        description=kb_descs[i],
                        score=sim,
                        document_count=0,
                        repositories=[],  # Optionally fill if available
                        created_at=kb_created[i],
                        updated_at=kb_updated[i]
                    )))
            # 6. Sort and limit
            scored_kbs.sort(reverse=True, key=lambda x: x[0])
            top_matches = [kb for _, kb in scored_kbs[:limit]]
            execution_time = time.time() - start_time
            logger.info(f"[TOOL] knowledge_base_search: completed in {execution_time:.3f}s with {len(top_matches)} results")
            return KnowledgeBaseSearchResult(
                chunks=top_matches,
                total_count=len(top_matches),
                query=query,
                execution_time=execution_time,
                metadata={"kb_type": input.type, "include_metadata": input.include_metadata}
            )
        except Exception as e:
            logger.error(f"knowledge_base_search failed: {e}")
            raise SearchError(f"Knowledge base search failed: {str(e)}")

    def _document_search_optimized(self, input: DocumentSearchInput) -> DocumentSearchResult:
        """Optimized document search with better performance."""
        # Implementation would go here
        return DocumentSearchResult(chunks=[], total_count=0, query=input.query, execution_time=0.0)

    def _code_search_optimized(self, input: CodeSearchInput) -> CodeSearchResult:
        """Optimized code search with better performance."""
        # Implementation would go here
        return CodeSearchResult(chunks=[], total_count=0, query=input.query, execution_time=0.0)


def get_search_tools(db=None, model_name="sentence-transformers/all-MiniLM-L6-v2"):
    """Get an instance of the enhanced search tools."""
    return SearchTools(db, model_name)
