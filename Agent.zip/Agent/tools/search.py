"""
Search tools for the Agent using the tool registry.
"""

from typing import Dict, List, Optional, Any
import numpy as np
from sentence_transformers import SentenceTransformer
from .models import (
    KnowledgeBaseSearchInput,
    KnowledgeBaseSearchResult,
    DocumentSearchInput,
    DocumentSearchResult,
    CodeSearchInput,
    CodeSearchResult,
    DocumentChunk,
    CodeChunk,
)
from tools.view_file import view_file  # Import the new tool
from database import Database
from exceptions import SearchError
from tools.registry import TOOL_REGISTRY, ToolRegistry
import logging
import os
from sqlalchemy import text

logger = logging.getLogger(__name__)

# Initialize the registry
registry = TOOL_REGISTRY

class SearchTools:
    """
    Collection of search-related tools for the Agent.
    """
    
    def __init__(self, db: Database, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        Initialize the search tools.
        
        Args:
            db: Database instance
            model_name: Name of the Hugging Face model to use for embeddings
        """
        self.db = db
        logger.info(f"Loading Hugging Face model: {model_name}")
        # Disable local_files_only to ensure we're always getting the latest model
        self.embedding_model = SentenceTransformer(model_name)
        logger.info("Embedding model loaded successfully from Hugging Face")
        self._register_tools()
    
    def _register_tools(self):
        """Register all search tools with the registry."""
        registry.register(
            name="knowledge_base_search",
            description="Identify the most relevant product or domain (knowledge base) for a support ticket or query. Use this tool to route tickets to the correct product team by matching the ticket's context (title/description) with product knowledge bases.",
            input_model=KnowledgeBaseSearchInput,
            output_model=KnowledgeBaseSearchResult
        )(self.knowledge_base_search)
        
        registry.register(
            name="document_search",
            description="Find the most relevant document or document chunk for a query within a specific product's knowledge base, or across all KBs. Use this to answer support questions, troubleshoot issues, or provide detailed product/process information to customers or internal teams. Returns a ranked list of matching document chunks with their associated knowledge base, document ID, content, and similarity score.",
            input_model=DocumentSearchInput,
            output_model=DocumentSearchResult
        )(self.document_search)
        
        registry.register(
            name="code_search",
            description="Retrieve relevant code snippets or implementation details from indexed repositories linked to a product knowledge base. Use this tool for technical support queries, bug triage, or developer onboarding. Returns a ranked list of code chunks with their associated knowledge base, document ID, code content, and similarity score. Supports searching across all KBs or within a specific product.",
            input_model=CodeSearchInput,
            output_model=CodeSearchResult
        )(self.code_search)
    
    def get_embedding(self, text: str) -> np.ndarray:
        """Generate an embedding for the given text."""
        return self.embedding_model.encode(text)
    
    def knowledge_base_search(self, input: KnowledgeBaseSearchInput) -> KnowledgeBaseSearchResult:
        """
        Find the most relevant product, SOP, or knowledge base for a user query using semantic search. Use this tool to identify which knowledge base contains the information or documentation needed to answer the user's question or troubleshoot an issue. This is the FIRST step before searching for specific documents or code.
        """
        query = input.query
        threshold = input.threshold or 0.1
        limit = input.limit or 5
        kb_type = input.type
        logger.info(f"[TOOL] knowledge_base_search: input={{'query': {query}, 'threshold': {threshold}, 'limit': {limit}, 'type': {kb_type}}}")
        try:
            # Fetch all KBs from the DB
            with self.db.engine.connect() as conn:
                sql = "SELECT id, name, description FROM knowledge_bases"
                if kb_type:
                    sql += " WHERE type = :type"
                    result = conn.execute(text(sql), {"type": kb_type})
                else:
                    result = conn.execute(text(sql))
                kbs = list(result)
            if not kbs:
                raise SearchError("No knowledge bases in the database")

            # Embed the query
            query_embedding = self.get_embedding(query)
            scored = []
            for kb in kbs:
                kb_id, name, desc = kb[0], kb[1], kb[2]
                kb_text = f"{name}: {desc}" if desc else name
                kb_embedding = self.get_embedding(kb_text)
                score = float(np.dot(kb_embedding, query_embedding) / (np.linalg.norm(kb_embedding) * np.linalg.norm(query_embedding)))
                if score >= threshold:
                    # Get document count
                    with self.db.engine.connect() as conn2:
                        doc_count = conn2.execute(text("SELECT COUNT(*) FROM document_chunks WHERE knowledge_base_id = :kb_id"), {"kb_id": kb_id}).scalar()
                        repo_rows = conn2.execute(text("SELECT id, tag, description FROM repositories WHERE knowledge_base_id = :kb_id"), {"kb_id": kb_id}).fetchall()
                        repo_infos = [{"id": str(row[0]), "tag": row[1], "description": row[2]} for row in repo_rows]
                    scored.append({
                        "id": str(kb_id),
                        "name": name,
                        "description": desc,
                        "score": score,
                        "document_count": doc_count,
                        "repositories": repo_infos
                    })
            # Sort by descending score and limit
            scored = sorted(scored, key=lambda x: -x["score"])[:limit]
            if scored:
                logger.info(f"[TOOL] knowledge_base_search: semantic result={{'chunks': {scored}}}")
                return KnowledgeBaseSearchResult(chunks=scored)
            else:
                raise SearchError("No matching knowledge bases found")
        except Exception as e:
            logger.error(f"knowledge_base_search semantic error: {e}")
            raise SearchError(f"Knowledge base search failed: {str(e)}")
    
    def document_search(self, input: DocumentSearchInput) -> DocumentSearchResult:
        """
        Search for relevant documents, such as logs, documentation, or reports, within a specific knowledge base. Use this tool after you have identified the correct knowledge base ID using `knowledge_base_search`. This tool is best for finding non-code information, like error logs, product specs, or troubleshooting guides.

        Args:
            input (DocumentSearchInput): The input for the search, including the knowledge_base_id (string) and query (string).
        """
        import psycopg2
        import psycopg2.extras
        from pgvector.psycopg2 import register_vector
        from constants import DEFAULT_DB_URL

        query = input.query
        kb_id = input.kb_id
        limit = input.limit or 5
        threshold = input.threshold or 0.1
        logger.info(f"[TOOL] document_search: input={{'query': {query}, 'kb_id': {kb_id}, 'limit': {limit}, 'threshold': {threshold}}}")

        query_embedding_list = self.get_embedding(query).tolist()

        try:
            conn = psycopg2.connect(DEFAULT_DB_URL)
            register_vector(conn)
            cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

            sql = """
                SELECT
                    id,
                    knowledge_base_id,
                    text,
                    1 - (embedding <=> %s::vector) as similarity
                FROM document_chunks
            """
            params = [query_embedding_list]

            where_clauses = []
            if kb_id:
                where_clauses.append("knowledge_base_id = %s")
                params.append(kb_id)

            where_clauses.append("1 - (embedding <=> %s::vector) > %s")
            params.extend([query_embedding_list, threshold])

            if where_clauses:
                sql += " WHERE " + " AND ".join(where_clauses)

            sql += " ORDER BY similarity DESC LIMIT %s"
            params.append(limit)

            cursor.execute(sql, params)
            rows = cursor.fetchall()

            chunks = []
            for row in rows:
                chunks.append(DocumentChunk(
                    id=str(row["id"]),
                    kb_id=str(row["knowledge_base_id"]),
                    content=row["text"],
                    score=float(row["similarity"])
                ))

            cursor.close()
            conn.close()
            logger.info(f"[TOOL] document_search: result={{'chunks': {chunks}}}")
            return DocumentSearchResult(chunks=chunks, kb_id=kb_id)
        except Exception as e:
            print(f"[DEBUG] Exception in document_search: {e}")
            raise SearchError(f"Document search failed: {str(e)}")

    def code_search(self, input: CodeSearchInput) -> CodeSearchResult:
        """
        Search for relevant code snippets, functions, or logic within code repositories linked to a knowledge base. Use this tool after identifying the right knowledge base, when the user needs implementation details, bug analysis, or example code. This tool is best for finding code-level answers, root cause analysis, or suggesting code changes and fixes.

        Args:
            input (CodeSearchInput): The input for the search, including the knowledge_base_id (string) and query (string).
        """
        import psycopg2
        import psycopg2.extras
        from pgvector.psycopg2 import register_vector
        from constants import DEFAULT_DB_URL

        query = input.query
        knowledge_base_id = input.knowledge_base_id
        limit = input.limit or 5
        threshold = input.threshold or 0.1
        logger.info(f"[TOOL] code_search: input={{'query': {query}, 'knowledge_base_id': {knowledge_base_id}, 'limit': {limit}, 'threshold': {threshold}}}")

        query_embedding_list = self.get_embedding(query).tolist()

        try:
            conn = psycopg2.connect(DEFAULT_DB_URL)
            register_vector(conn)
            cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

            repo_ids = []
            repo_tag = getattr(input, 'tag', None)
            if knowledge_base_id:
                if repo_tag:
                    cursor.execute(
                        "SELECT id FROM repositories WHERE knowledge_base_id = %s AND tag = %s",
                        (knowledge_base_id, repo_tag)
                    )
                else:
                    cursor.execute(
                        "SELECT id FROM repositories WHERE knowledge_base_id = %s",
                        (knowledge_base_id,)
                    )
                repo_ids = [row['id'] for row in cursor.fetchall()]
                if not repo_ids:
                    logger.warning(f"No repositories found for knowledge_base_id: {knowledge_base_id} and tag: {repo_tag}")
                    return CodeSearchResult(chunks=[])

            sql = """
                SELECT
                    id,
                    repository_id,
                    file_path,
                    chunk_text,
                    1 - (embedding <=> %s::vector) as similarity
                FROM code_chunks
            """
            params = [query_embedding_list]

            where_clauses = []
            if repo_ids:
                # Use a tuple for the IN clause
                where_clauses.append("repository_id IN %s")
                params.append(tuple(repo_ids))

            where_clauses.append("1 - (embedding <=> %s::vector) > %s")
            params.extend([query_embedding_list, threshold])

            if where_clauses:
                sql += " WHERE " + " AND ".join(where_clauses)

            sql += " ORDER BY similarity DESC LIMIT %s"
            params.append(limit)

            cursor.execute(sql, params)
            rows = cursor.fetchall()

            matches = []
            for row in rows:
                # Ensure the entire chunk_text is returned as the 'code' field
                matches.append(CodeChunk(
                    id=str(row["id"]),
                    repository_id=str(row["repository_id"]),
                    file_path=row["file_path"],
                    code=row["chunk_text"],  # This is the full code chunk from the database
                    score=float(row["similarity"])
                ))

            cursor.close()
            conn.close()
            logger.info(f"[TOOL] code_search: result={{'chunks': {matches}}}")
            return CodeSearchResult(chunks=matches)
        except Exception as e:
            print(f"[DEBUG] Exception in code_search: {e}")
            raise SearchError(f"Code search failed: {str(e)}")

def get_search_tools(db: Database, model_name: str = "sentence-transformers/all-MiniLM-L6-v2") -> SearchTools:
    """
    Get an instance of SearchTools with the specified database connection.
    
    Args:
        db: Database instance
        model_name: Name of the Hugging Face model to use for embeddings
        
    Returns:
        SearchTools: An instance of SearchTools
    """
    return SearchTools(db, model_name=model_name)
