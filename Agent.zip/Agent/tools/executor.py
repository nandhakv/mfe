import logging
from typing import Any, Dict, List
from tools.registry import get_tool_registry

logger = logging.getLogger("tools.executor")

def execute_tool_plan(strategy: str, tool_calls: List[Dict[str, Any]], execution_order: str) -> Dict[str, Any]:
    """
    Dynamically execute tools based on the LLM plan.
    Args:
        strategy: The execution strategy (direct, single_tool, multi_step, parallel)
        tool_calls: List of tool call dicts with tool_name and parameters
        execution_order: 'sequential', 'parallel', or 'direct'
    Returns:
        Dict with tool results, execution trace, and any errors
    """
    tool_registry = get_tool_registry()
    results = []
    errors = []


    def run_tool_call(tool_call):
        tool_name = tool_call.get("tool_name")
        params = tool_call.get("parameters", {})
        tool_info = tool_registry.tools.get(tool_name)
        if not tool_info:
            err = f"Tool '{tool_name}' not found in registry."
            logger.error(err)
            errors.append({"tool_name": tool_name, "error": err})
            return None
        func = tool_info.get("function")
        try:
            logger.info(f"Executing tool: {tool_name} with params: {params}")
            result = func(**params)
            results.append({"tool_name": tool_name, "result": result})
            return result
        except Exception as e:
            err = f"Error executing tool '{tool_name}': {str(e)}"
            logger.error(err)
            errors.append({"tool_name": tool_name, "error": err})
            return None

    if execution_order == "parallel":
        # Run all tools independently
        for tool_call in tool_calls:
            run_tool_call(tool_call)
    elif execution_order == "sequential":
        # Pass result of previous tool as context if needed
        last_result = None
        for tool_call in tool_calls:
            if last_result is not None:
                # Optionally inject last_result into params if tool expects it
                params = tool_call.get("parameters", {})
                if isinstance(params, dict) and "prev_result" in params:
                    params["prev_result"] = last_result
            last_result = run_tool_call(tool_call)
    elif execution_order == "direct":
        # No tools needed
        return {"tool_results": [], "errors": [], "execution_order": execution_order}
    else:
        err = f"Unknown execution_order: {execution_order}"
        logger.error(err)
        errors.append({"execution_order": execution_order, "error": err})

    return {
        "tool_results": results,
        "errors": errors,
        "execution_order": execution_order
    }
