from pydantic import BaseModel
from typing import Optional, List

# --- Input Models ---

class KnowledgeBaseSearchInput(BaseModel):
    query: str
    threshold: float = 0.1
    limit: int = 5
    type: Optional[str] = None

class DocumentSearchInput(BaseModel):
    kb_id: Optional[str] = None
    query: str
    limit: int = 5
    threshold: float = 0.1

class CodeSearchInput(BaseModel):
    knowledge_base_id: Optional[str] = None
    query: str
    limit: int = 5
    threshold: float = 0.1
    type: Optional[str] = None

# --- Result Item Models (for automatic parsing) ---

class KnowledgeBaseMatch(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    score: float
    document_count: int
    repositories: list

class DocumentChunk(BaseModel):
    id: str
    kb_id: str
    content: str
    score: float

class CodeChunk(BaseModel):
    id: str
    repository_id: str
    file_path: str
    code: str
    score: float

# --- Result Models ---

class KnowledgeBaseSearchResult(BaseModel):
    chunks: List[KnowledgeBaseMatch]

class DocumentSearchResult(BaseModel):
    chunks: List[DocumentChunk]
    kb_id: Optional[str] = None

class CodeSearchResult(BaseModel):
    chunks: List[CodeChunk]
