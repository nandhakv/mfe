"""
Models - Pydantic models for all tool functionality.

This module contains all the input and output models used by the tools
for search, Freshdesk integration, code viewing, and other operations.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# --- Search Models ---

class KnowledgeBaseSearchInput(BaseModel):
    """Input model for knowledge base search operations."""
    query: str = Field(..., description="The search query string")
    threshold: float = Field(0.1, description="Similarity threshold for results (0.0 to 1.0)")
    limit: int = Field(5, description="Maximum number of results to return")
    type: Optional[str] = Field(None, description="Filter by knowledge base type")
    include_metadata: bool = Field(False, description="Whether to include additional metadata")

class DocumentSearchInput(BaseModel):
    """Input model for document search operations."""
    kb_id: Optional[str] = Field(None, description="Specific knowledge base ID to search in")
    query: str = Field(..., description="The search query string")
    limit: int = Field(5, description="Maximum number of results to return")
    threshold: float = Field(0.1, description="Similarity threshold for results (0.0 to 1.0)")
    include_content: bool = Field(True, description="Whether to include document content in results")

class CodeSearchInput(BaseModel):
    """Input model for code search operations."""
    knowledge_base_id: Optional[str] = Field(None, description="Specific knowledge base ID to search in")
    query: str = Field(..., description="The search query string")
    limit: int = Field(5, description="Maximum number of results to return")
    threshold: float = Field(0.1, description="Similarity threshold for results (0.0 to 1.0)")
    type: Optional[str] = Field(None, description="Filter by file type (e.g., 'python', 'javascript')")
    repository_id: Optional[str] = Field(None, description="Filter by specific repository ID")

# --- Search Result Models ---

class KnowledgeBaseMatch(BaseModel):
    """Model for knowledge base search result items."""
    id: str = Field(..., description="Knowledge base ID")
    name: str = Field(..., description="Knowledge base name")
    description: Optional[str] = Field(None, description="Knowledge base description")
    score: float = Field(..., description="Similarity score (0.0 to 1.0)")
    document_count: int = Field(..., description="Number of documents in the knowledge base")
    repositories: List[str] = Field(default_factory=list, description="List of repository IDs")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")

class DocumentChunk(BaseModel):
    """Model for document search result items."""
    id: str = Field(..., description="Document chunk ID")
    kb_id: str = Field(..., description="Knowledge base ID")
    content: str = Field(..., description="Document chunk content")
    score: float = Field(..., description="Similarity score (0.0 to 1.0)")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    chunk_index: Optional[int] = Field(None, description="Chunk position in document")

class CodeChunk(BaseModel):
    """Model for code search result items."""
    id: str = Field(..., description="Code chunk ID")
    repository_id: str = Field(..., description="Repository ID")
    file_path: str = Field(..., description="File path within repository")
    code: str = Field(..., description="Code chunk content")
    score: float = Field(..., description="Similarity score (0.0 to 1.0)")
    start_line: Optional[int] = Field(None, description="Starting line number")
    end_line: Optional[int] = Field(None, description="Ending line number")
    language: Optional[str] = Field(None, description="Programming language")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")

class KnowledgeBaseSearchResult(BaseModel):
    """Result model for knowledge base search operations."""
    chunks: List[KnowledgeBaseMatch] = Field(..., description="List of matching knowledge bases")
    total_count: int = Field(..., description="Total number of matches found")
    query: str = Field(..., description="Original search query")
    execution_time: float = Field(..., description="Search execution time in seconds")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional search metadata")

class DocumentSearchResult(BaseModel):
    """Result model for document search operations."""
    chunks: List[DocumentChunk] = Field(..., description="List of matching document chunks")
    kb_id: Optional[str] = Field(None, description="Knowledge base ID that was searched")
    total_count: int = Field(..., description="Total number of matches found")
    query: str = Field(..., description="Original search query")
    execution_time: float = Field(..., description="Search execution time in seconds")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional search metadata")

class CodeSearchResult(BaseModel):
    """Result model for code search operations."""
    chunks: List[CodeChunk] = Field(..., description="List of matching code chunks")
    total_count: int = Field(..., description="Total number of matches found")
    query: str = Field(..., description="Original search query")
    execution_time: float = Field(..., description="Search execution time in seconds")
    repositories_searched: List[str] = Field(default_factory=list, description="List of repositories searched")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional search metadata")

# --- Freshdesk Models ---

class GetTicketsInput(BaseModel):
    """Input model for getting tickets from Freshdesk."""
    page: Optional[int] = Field(1, description="The page number of results to fetch.")
    per_page: Optional[int] = Field(30, description="The number of results per page (max 100).")

class GetTicketInput(BaseModel):
    """Input model for getting a single ticket from Freshdesk."""
    ticket_id: int = Field(..., description="The unique ID of the ticket.")

class SearchTicketsInput(BaseModel):
    """Input model for searching tickets in Freshdesk."""
    query: str = Field(..., description="The KQL query string to search for tickets.")

class GetTicketConversationInput(BaseModel):
    """Input model for getting ticket conversation history."""
    ticket_id: int = Field(..., description="The unique ID of the ticket to get conversations for.")

class GetAgentsInput(BaseModel):
    """Input model for getting agents from Freshdesk."""
    page: Optional[int] = Field(1, description="The page number of results to fetch.")
    per_page: Optional[int] = Field(30, description="The number of results per page (max 100).")

class ListContactsInput(BaseModel):
    """Input model for listing contacts from Freshdesk."""
    page: Optional[int] = Field(1, description="The page number of results to fetch.")
    per_page: Optional[int] = Field(30, description="The number of results per page (max 100).")

class GetContactInput(BaseModel):
    """Input model for getting a single contact from Freshdesk."""
    contact_id: int = Field(..., description="The unique ID of the contact.")

class SearchContactsInput(BaseModel):
    """Input model for searching contacts in Freshdesk."""
    query: str = Field(..., description="The search query string for contacts (name or email).")

# --- Code Viewer Models ---

class CodeViewerInput(BaseModel):
    """Input model for code file viewing operations."""
    repository_id: str = Field(..., description="The unique ID of the repository.")
    file_path: str = Field(..., description="The path to the file within the repository.")
    include_metadata: bool = Field(False, description="Whether to include file metadata like line numbers.")

class CodeViewerResult(BaseModel):
    """Result model for code file viewing operations."""
    repository_id: str = Field(..., description="Repository ID")
    file_path: str = Field(..., description="File path within repository")
    content: str = Field(..., description="Full file content")
    total_lines: int = Field(..., description="Number of lines in file")
    file_size: int = Field(..., description="Size of file in bytes")
    chunks_count: int = Field(..., description="Number of database chunks used")
    metadata: Optional[dict] = Field(None, description="Optional file metadata")

# --- Utility Models ---

class SearchStats(BaseModel):
    """Model for search statistics and metrics."""
    total_searches: int = Field(0, description="Total number of searches performed")
    average_execution_time: float = Field(0.0, description="Average execution time in seconds")
    cache_hit_rate: float = Field(0.0, description="Cache hit rate percentage")
    success_rate: float = Field(0.0, description="Search success rate percentage")
    last_search_time: Optional[datetime] = Field(None, description="Timestamp of last search")

class SearchFilter(BaseModel):
    """Model for search filtering options."""
    file_types: Optional[List[str]] = Field(None, description="Filter by file types")
    repositories: Optional[List[str]] = Field(None, description="Filter by repository IDs")
    date_range: Optional[Dict[str, datetime]] = Field(None, description="Filter by date range")
    size_range: Optional[Dict[str, int]] = Field(None, description="Filter by file size range")
    language: Optional[str] = Field(None, description="Filter by programming language")
