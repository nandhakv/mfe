#!/usr/bin/env python3
"""
Simple test to verify agent behavior without unwanted prints.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agent import create_agent
import os
from constants import DEFAULT_DB_URL
from database import get_database
from tools.search import get_search_tools
from tools.freshdesk import get_freshdesk_tools

def test_simple_agent():
    """Test the agent with minimal output."""
    
    # Set up database and tools
    os.environ["DATABASE_URL"] = DEFAULT_DB_URL
    db = get_database()
    get_search_tools(db)
    get_freshdesk_tools()
    
    # Initialize the agent
    agent = create_agent(debug_mode=False)  # Disable debug mode
    
    # Test query
    query = "What was the root cause of ticket 114781? analyse the code and provide the fix with example"
    
    print("Testing agent without unwanted prints...")
    
    try:
        # Execute the agent - this should NOT print anything automatically
        response = agent.run(query)
        
        print("Agent response received successfully")
        print(f"Response length: {len(response)} characters")
        print(f"Response preview: {response[:100]}...")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_simple_agent() 