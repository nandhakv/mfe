#!/usr/bin/env python3
"""
Test script to verify conditional routing after planning.
"""

import os
import sys
from datetime import datetime

# Add the current directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_conditional_routing():
    """Test that the agent routes correctly based on planning decisions."""
    print("🧪 Testing conditional routing after planning...")
    
    from agent import SimplifiedAgent, AgentConfig
    from state import get_initial_state
    
    # Create a test agent
    config = AgentConfig(
        name="TestAgent",
        max_iterations=5,
        debug_mode=True
    )
    agent = SimplifiedAgent(config)
    
    # Test case 1: Query that should use tools
    print("\n📋 Test Case 1: Query requiring tools")
    tool_query = "What was the root cause of ticket 114781? analyse the code and provide the fix"
    
    # Test case 2: Query that should not need tools
    print("\n📋 Test Case 2: Query not requiring tools")
    simple_query = "Hello, how are you today?"
    
    # Test case 3: Query that might need tools
    print("\n📋 Test Case 3: Query that might need tools")
    search_query = "Search for information about user authentication"
    
    test_cases = [
        ("Tool Query", tool_query),
        ("Simple Query", simple_query),
        ("Search Query", search_query)
    ]
    
    for test_name, query in test_cases:
        print(f"\n🔍 Testing: {test_name}")
        print(f"Query: {query}")
        
        try:
            # Create initial state
            initial_state = get_initial_state(query)
            initial_state["status"] = "idle"
            initial_state["iteration_count"] = 0
            initial_state["start_time"] = datetime.now().isoformat()
            
            # Run planner node
            planner_result = agent._planner_node(initial_state)  # type: ignore
            
            # Check routing decision
            routing_decision = agent._route_after_planning(planner_result)
            
            print(f"✅ Planner status: {planner_result.get('status')}")
            print(f"✅ Routing decision: {routing_decision}")
            
            tool_plans = planner_result.get("tool_execution_plans", {})
            tool_calls = tool_plans.get("tool_calls", []) if tool_plans else []
            print(f"✅ Tool calls planned: {len(tool_calls)}")
            
            if tool_calls:
                print(f"✅ Tools to be called: {[call.get('tool_name', 'unknown') for call in tool_calls]}")
            
        except Exception as e:
            print(f"❌ Error in {test_name}: {e}")
    
    print("\n✅ Conditional routing test completed")
    return True

def test_agent_flow():
    """Test the complete agent flow with different query types."""
    print("\n🧪 Testing complete agent flow...")
    
    from agent import create_agent
    
    # Create agent
    agent = create_agent(
        name="FlowTestAgent",
        max_iterations=3,
        debug_mode=True
    )
    
    # Test queries
    test_queries = [
        ("Simple greeting", "Hello, how are you?"),
        ("Tool-based query", "Get ticket 12345 from Freshdesk"),
        ("Search query", "Find documents about authentication")
    ]
    
    for query_name, query in test_queries:
        print(f"\n🔍 Testing flow: {query_name}")
        print(f"Query: {query}")
        
        try:
            # Run the agent
            response = agent.run(query)
            print(f"✅ Response received: {len(response)} characters")
            print(f"✅ Response preview: {response[:100]}...")
            
        except Exception as e:
            print(f"❌ Error in flow test: {e}")
    
    print("\n✅ Agent flow test completed")
    return True

def main():
    """Run all routing tests."""
    print("🚀 Starting Conditional Routing Tests")
    print("=" * 50)
    
    tests = [
        ("Conditional Routing", test_conditional_routing),
        ("Agent Flow", test_agent_flow),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name} PASSED")
            else:
                print(f"❌ {test_name} FAILED")
        except Exception as e:
            print(f"❌ {test_name} ERROR: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All routing tests passed! Conditional planning works correctly.")
        return True
    else:
        print("⚠️  Some tests failed. Please check the issues above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 