import express from "express";
import { verifySignature } from "./services/webhookHandler.js";
import { handlePullRequest } from "./services/eventListeners.js";
import { addTestReportToPR } from './services/staticCodeAnalysisReport.js';
import logger from "./services/logger.js";

// Helper function to log events to Amplitude
async function logEvent(eventName, eventProperties = {}) {
    logger.info(`📊 Logging event to Amplitude: ${eventName}`);
    
    // Your Amplitude API key
    const API_KEY = '166bc3ee57fcdfdacf44ce795224a80c';
    
    try {
        // Create event data structure that matches Amplitude's HTTP API
        const eventData = {
            api_key: API_KEY,
            events: [
                {
                    event_type: eventName,
                    user_id: eventProperties.user_id || "anonymous_user", // Must be a non-empty string
                    device_id: eventProperties.device_id || "dev_" + Date.now(), // Required if no user_id
                    time: eventProperties.time || Date.now(), // Current time in milliseconds
                    app_version: eventProperties.app_version || "1.0.0",
                    platform: eventProperties.platform || "Web",
                    ...eventProperties // Include any other properties passed in
                }
            ]
        };
        
        // Send the request to Amplitude HTTP API
        const response = await fetch('https://api.amplitude.com/2/httpapi', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(eventData)
        });
        
        const responseText = await response.text();
        logger.info(`Amplitude response status: ${response.status}`);
        logger.info(`Amplitude response body: ${responseText}`);
        
        if (!response.ok) {
            throw new Error(`Amplitude API responded with status: ${response.status}, body: ${responseText}`);
        }
    } catch (error) {
        logger.error(`Amplitude Error: ${error}`);
    }
}

const app = express();
app.use(express.json());

const processedCheckRuns = new Set(); // Consider using a DB or cache for persistence

app.get("/health", (req, res) => {
    logger.info("Health check endpoint hit");
    res.status(200).send("Server is up and running");
});

app.post("/api/webhook", async (req, res) => {
    const repoName = req.body.repository?.name || 'unknown';
    logger.info(`⚡️ Received GitHub Webhook from: ${repoName}`);
    
    try {
        if (!verifySignature(req)) {
            logEvent('webhook_error', {
                error_type: 'invalid_signature',
                repository: repoName,
            });
            return res.status(401).send("❌ Invalid webhook signature");
        }
    } catch (error) {
        logger.error(`❌ Error verifying webhook signature: ${error}`);
        logEvent('webhook_error', {
            error_type: 'signature_verification_failed',
            repository: repoName,
            error_message: error.message,
        });
        return res.status(401).send("❌ Webhook signature verification failed");
    }

    const event = req.headers["x-github-event"];
    logger.info(`🔔 Received GitHub Webhook: ${event}`);

    try {
        if (event === "check_run" && req.body.check_run?.name === "SonarQube Analysis") {
            if (req.body.check_run.status === "completed") {
                const checkRunId = req.body.check_run.id;
                
                if (processedCheckRuns.has(checkRunId)) {
                    logger.warn(`⚠️ Ignoring duplicate check_run: ${checkRunId}`);
                    return res.status(200).send("✅ Duplicate check_run ignored");
                }
                processedCheckRuns.add(checkRunId);
    
                logger.info("🔍 SonarQube Analysis Report");
                addTestReportToPR(req.body.check_run);
                
                logEvent('sonarqube_analysis_processed', {
                    check_run_id: checkRunId,
                    repository: repoName,
                    conclusion: req.body.check_run.conclusion,
                });
    
                return res.status(200).send("✅ Webhook processed");
            }
        } else if (event === "pull_request") {
            const prNumber = req.body.pull_request?.number;
            const sender = req.body.sender?.login;
            const action = req.body.action;
    
            if (req.body.pull_request?.user?.type === "Bot" || sender?.toLowerCase().includes("bot")) {
                logger.info(`🤖 Ignoring bot-triggered PR event for #${prNumber}`);
                return res.status(200).send("✅ Bot-triggered PR event ignored");
            }
    
            // Respond immediately to GitHub to avoid timeout issues
            res.status(200).send("✅ PR processing in background");
            
            // Log PR event
            logEvent('pull_request_received', {
                pr_number: prNumber,
                repository: repoName,
                sender: sender,
                action: action,
            });
    
            // Process the PR event asynchronously
            handlePullRequest(req.body)
                .then(() => {
                    logger.info(`✅ PR #${prNumber} processed successfully`);
                    logEvent('pull_request_processed', {
                        pr_number: prNumber,
                        repository: repoName,
                        status: 'success',
                    });
                })
                .catch((error) => {
                    logger.error(`❌ Error processing PR #${prNumber}: ${error}`);
                    logEvent('pull_request_error', {
                        pr_number: prNumber,
                        repository: repoName,
                        error_message: error.message,
                        status: 'error',
                    });
                });
    
        } else if (event === "issue_comment") {
            logger.info("💬 Comment Added on PR");
            
            const issueNumber = req.body.issue?.number;
            const sender = req.body.sender?.login;
            
            logEvent('issue_comment_received', {
                issue_number: issueNumber,
                repository: repoName,
                sender: sender,
            });
    
            // Respond immediately
            res.status(200).send("✅ Webhook processed");
    
            // Process the event asynchronously
            // handleComment(req.body).catch((error) => logger.error(`❌ Error handling comment: ${error}`));
        } else {
            logger.warn(`⚠️ Unhandled event: ${event}`);
            return res.status(200).send("✅ Webhook processed");
        }
    
    } catch (error) {
        logger.error(`❌ Error processing webhook: ${error}`);
        logEvent('webhook_processing_error', {
            event_type: event,
            repository: repoName,
            error_message: error.message,
        });
        if (!res.headersSent) {
            res.status(500).send("Internal Server Error");
        }
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    logger.info(`🚀 Server running on port ${PORT}`);
    logEvent('server_started', {
        port: PORT,
        environment: process.env.NODE_ENV || 'development',
    });
});