import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

const GITHUB_APP_SECRET = process.env.GITHUB_APP_SECRET;

/**
 * Verify GitHub webhook signature
 */
export function verifySignature(req) {
    const signature = req.headers["x-hub-signature-256"];
    const payload = JSON.stringify(req.body);
    
    const hmac = crypto.createHmac("sha256", GITHUB_APP_SECRET).update(payload).digest("hex");
    const expectedSignature = `sha256=${hmac}`;

    return signature === expectedSignature;
}