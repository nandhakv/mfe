import { connectLLm } from "./llmService.js";
import { responseSchema,summaryResponseScheme } from "../common/constants.js";
import { reviewFileDiffFunPrompt } from "../common/prompts.js";
import { getPullRequestDetails, postInlineComment } from "./githubService.js";

/**
 * Generate AI review with line-specific feedback
 */
async function generateAIReviewFileWise(repo, prNumber, extractedDiff) {
    let allReviews = [];

    for (const { fileName, oldHunk, newHunk, startLine, endLine, type, fullCode } of extractedDiff) {
        console.log("🔄 Generating AI review for", fileName);
    
        // Construct the prompt using the extracted hunks
        const prompt = reviewFileDiffFunPrompt(fileName, oldHunk, newHunk, startLine, endLine, type);
        try {
            console.log("🤖 Sending request to AI for", fileName);
            const response = await connectLLm({ prompt, responseSchema }); // ✅ Send extracted hunks
    
            // console.log(`🤖 AI response for ${fileName}:`, response.choices[0]);
    
            if (!response || !response.choices || response.choices.length === 0) {
                throw new Error(`Invalid AI response structure for ${fileName}`);
            }
    
            // ✅ Parse AI response as JSON
            const aiFeedback = JSON.parse(response.choices[0].message.content);
    
            if (!aiFeedback || !Array.isArray(aiFeedback.reviews)) {
                throw new Error(`AI response for ${fileName} does not contain a valid 'reviews' array`);
            }
    
            // ✅ Attach the file name to each review
            const reviewsWithFile = aiFeedback.reviews.map((review) => ({
                ...review,
                file: fileName,
            }));
    
            allReviews.push(...reviewsWithFile);

            // loop through each feedback and post inline comments
            for (const feedback of reviewsWithFile) {
                try {
                    console.log(`📌 Posting inline comment for ${fileName} at line ${feedback.commentLine}`);
                   await postInlineComment(repo, prNumber, feedback.file, feedback.commentLine, feedback.comment);
                   await new Promise(res => setTimeout(res, 3000));
                } catch(error) {
               //     console.error(`❌ Error posting inline comment for ${fileName}:`, error.message);
            }
        }
        } catch (error) {
            console.error(`❌ Error generating AI review for ${fileName}:`, error.message);
        }
    }
    
    return allReviews; // ✅ Aggregate reviews for all files
}

async function generateAISummary(prompt) {
    let review = "";
    try {
        console.log(":robot_face: Sending request to AI for summary");
        const response = await connectLLm({ prompt, summaryResponseScheme }); // :white_check_mark: Send extracted hunks

        review = response.choices[0].message.content;
        // console.log(`AI response for summary`, response.choices[0].message.content);

        // if (!response || !response.choices || response.choices.length === 0) {
        //     throw new Error(`Invalid AI response structure for ${fileName}`);
        // }

        // :white_check_mark: Parse AI response as JSON
        // const aiFeedback = JSON.parse(response.choices[0].message.content);
    } catch (error) {
        console.error(`:x: Error generating AI review for:`, error.message);
    }

return review; // :white_check_mark: Aggregate reviews for all files
}

export { generateAIReviewFileWise , generateAISummary};