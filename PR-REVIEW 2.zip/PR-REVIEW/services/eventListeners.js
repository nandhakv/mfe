import { getPullRequestDetails, fetchPullRequestDiff, updatePullRequestDescription, ensureWorkflowExists, triggerGitHubAction } from "./githubService.js";
import { generateAIReviewFileWise } from "./aiReviewService.js";
import { generatePRSummaryTable, extractDiffChanges, getModifiedFiles } from "../common/utils.js";
// import { analyzePullRequest } from "./staticCodeAnalyser.js";

/**
 * Handle PR events
 */
export async function handlePullRequest(payload) {
    const action = payload.action;
    const repo = payload.repository.full_name;
    const prNumber = payload.pull_request.number;

    if (action === "opened") {
        console.log(`🔄 PR #${prNumber} updated in ${repo}`);

        // Fetch PR details
        // const prDetails = await getPullRequestDetails(repo, prNumber);
        // let prDescription = prDetails.details.body || "";

        // ✅ Define boundaries for AI Summary & SonarQube Report
        const aiSummaryStart = "<!-- START_AI_SUMMARY -->";
        const aiSummaryEnd = "<!-- END_AI_SUMMARY -->";
        const sonarReportStart = "<!-- START_SONARQUBE_REPORT -->";
        const sonarReportEnd = "<!-- END_SONARQUBE_REPORT -->";

        // const sonarLoadingMessage = `${sonarReportStart}\n⏳ **SonarQube analysis in progress...**\n${sonarReportEnd}`;
        const sonarLoadingMessage = `${sonarReportStart}\n⏳ **SonarQube analysis on Hold!**\n${sonarReportEnd}`;
        const aiLoadingMessage = `${aiSummaryStart}\n⏳ **AI analysis in progress...**\n${aiSummaryEnd}`;

        // ✅ Update PR Description
        await updatePullRequestDescription(repo, prNumber, `${sonarLoadingMessage}\n\n${aiLoadingMessage}`);

        // try{
        //   // ✅ Trigger Static Code Analysis
        //   const { workflowId, githubToken } = await ensureWorkflowExists(repo, prNumber);
        //   if (workflowId) {
        //       triggerGitHubAction(repo, workflowId, {
        //           branch: prDetails.details.head.ref,
        //           files: getModifiedFiles(prDetails),
        //           pr_number: prDetails.details.number.toString(),
        //           github_token: githubToken,
        //           sonarqube_host: process.env.SONARQUBE_HOST,
        //           sonarqube_token: process.env.SONARQUBE_TOKEN
        //       });
        //   }
        // } catch (error) {
        //     console.error(`❌ Error triggering GitHub Action for PR #${prNumber}:`, error.message);
        // }

        console.log(`✅ PR #${prNumber} updated successfully with loading messages.`);
        // ✅ Fetch PR diff & AI Feedback
        const diff = await fetchPullRequestDiff(repo, prNumber);
        const extractedDiff = extractDiffChanges(diff);
        const aiFeedback = await generateAIReviewFileWise(repo, prNumber, extractedDiff);
    
        console.log("Generating Table for PR #" + prNumber);
        // ✅ Construct AI Summary
        const aiSummaryTable = await generatePRSummaryTable(extractedDiff, aiFeedback);
        const newAISummary = `${aiSummaryStart}\n# 🔍 AI-Generated Summary\n${aiSummaryTable}\n${aiSummaryEnd}`;

        // Fetch PR details
        const prDetailsUpdated = await getPullRequestDetails(repo, prNumber);
        let prDescriptionUpdated = prDetailsUpdated.details.body || "";  

             // ✅ Extract Existing Sections
        const existingAIReport = extractSection(prDescriptionUpdated, aiSummaryStart, aiSummaryEnd);
        const existingSonarReport = extractSection(prDescriptionUpdated, sonarReportStart, sonarReportEnd);

        console.log("existingAIReport PR ", existingAIReport);
        console.log("existingSonarReport PR ", existingSonarReport);

       
        // ✅ Reconstruct PR description ensuring both reports are included
        prDescriptionUpdated = `${existingSonarReport || ""}\n\n${newAISummary}`;

        // ✅ Update PR Description
        await updatePullRequestDescription(repo, prNumber, prDescriptionUpdated);
        console.log(`✅ PR #${prNumber} updated successfully with AI Summary & SonarQube Report.`);
    }
}

/**
 * Extracts a section from a text given its start and end markers.
 */
function extractSection(text, startMarker, endMarker) {
    const regex = new RegExp(`${startMarker}[\\s\\S]*?${endMarker}`, "g");
    const match = text.match(regex);
    return match ? match[0] : "";
}


export function mapLineNumbersToDiffPositions(diffByFile) {
    const lineToPositionMap = {};
    for (const [file, diffContent] of Object.entries(diffByFile)) {
        lineToPositionMap[file] = {}; // Initialize file-specific mapping
        const lines = diffContent.split("\n");
        let position = 0;
        let lineNumber = 0;
        for (const line of lines) {
            if (line.startsWith("@@")) {
                // Extract line numbers from diff header
                const match = line.match(/@@ -\d+,\d+ \+(\d+),\d+ @@/);
                if (match) {
                    lineNumber = parseInt(match[1], 10);
                    console.log(`Found diff header for file ${file}: starting at line ${lineNumber}`);
                }
            } else if (!line.startsWith("-")) {
                position++;
                if (!line.startsWith("+")) lineNumber++;
                lineToPositionMap[file][lineNumber] = position;
                console.log(`Mapped line ${lineNumber} to position ${position} in file ${file}`);
            }
        }
    }
    return lineToPositionMap;
}

/**
 * Handle comment events
 */
export async function handleComment(payload) {
    const repo = payload.repository.full_name;
    const issueNumber = payload.issue.number;
    const comment = payload.comment.body;

    console.log(`💬 New comment on issue #${issueNumber} in ${repo}: "${comment}"`);
}