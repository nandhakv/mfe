import jwt from "jsonwebtoken";
import fs from "fs";
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const APP_ID = process.env.GITHUB_APP_ID;
// const PRIVATE_KEY = process.env.GITHUB_PRIVATE_KEY;
const PRIVATE_KEY = "-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEApGd9aZb3R95uwT+I5CG5XkpPGTqs8T6tKmpV5GVhU3sPLcwh\ndeMPyG8RxWpH9C2/yCfk4nuU44El1v2rpWvMnkZLVLX0ovopsmdKhRWIO+OUThG9\nwBwVz944aaBb5WUpCM4M18BlVNY4L0xfCin3JDacNLv+T0KgRif4ZLhJO4Ah4T9l\nuDfbng+WN+Zf9GpggWckqgOXhdMLJQl+2J3+pLej5B5vh0dBI/3joGoRRxzXKsjk\nejKCrwX/wn2SSOX1qxa4RVKn0rTDvn6zIgwuD2Rf4dGhJPuxZTmVw45dEm3s2G9g\n56D6xKSkvWUtqSs8GPQMIB1b38g+QmCwCxAhHwIDAQABAoIBAFY8tutRNirrwXr6\n4cqQ6hRMtEsOnTL6ZokuOBnTGAdbMK4cOp0E2v2PTWoZgt7RtJzAWG541rOzxe6N\nJ6Fg93c6dj9cJpPq1z5usgc3MTwA94UwBzGjScm8ziiR5kJhGvI0a0Ys9LpYmCYv\nUFcbhjjnsG51AkP/NeU3CDOE+10K1QCGdvjFamn8uKgAKhGxj4RmJ5de9IE+Hipq\nuHsw5qm9ljVa1Z0Izd895b4pCqK6J14ljdtbc3S1+6kyzVSgLhUrP6qztH9gZMSh\ncl7w74yZG+6vHxyRETBBN/xNEYPiiCsSDO9rY7+sWqrvbgBY/M87v6okXBBPYgTD\n+G1HRIECgYEAzejeS2/sx39YkH2F9qL/KlwScPDS5I6gUEi3YJwueeBfZjDfycsb\npAsrYr6ea7+/8a5MMLivFFGZwNpY8sk3XLNHmzJ76TYukur5r0/7afVYdT9NzGF3\nU4nEsG32IlpCNioPpGUaSL2hyi3nZxtGwcXx7/TPJR4KYxScPGQO7N8CgYEAzGXa\nEL+pyT8XwITo3eRVMnPWgCKeVv7kwENXWLd95kk3f2WJYG2j7O0+vk2Y+O15utnT\njfx3va/9eKIjqnji/uPqgv+0hHVcsDvqTKPsLvmNE/lI/sI/8H9+GSzls0EaVvhK\nJ8cw6BVh/fXr/yqzX0h7UMgqYrfL+RG80TwlE8ECgYBvZT71ssx3NSa1rKLPxmij\nAwKbBT4iliKWrHBAnN3r433Y7DH1mqMOgVhsaFGOW0M9PZ1Mcm2NYYP7uGSMnF0O\nEpN3m707cquJogOIW43ZSfkcHS46lrQWhp7ZD/Qrq4bMhL7Hokaw+Z5QobrhpfkG\nlc8IkPmLzA+0gI7xgPQuIwKBgGY3UTQrBTeVC8XFMcc1lr2iXFS7+z86PR9BDf9Z\n0+ZEGzLkjizg56dmhYgZujRSXhvpLvjElwUPa8zWGMv5pFsfk3lrctUC9BVWATfO\niiB7v+eLNMviTKNyvpbMcxqPpiJ0DHGUFYsalmSwhRKYQheWYcTmNPwlOiYWjrx8\nPXaBAoGAbAk4X6EZJoXPudkMVulCsDVPyyHjS51AiI/lIIj9Q9HQJ0TkQHP2USA6\nRisOPGsGB3kfpadxMl/pjWTLJ8wH6F7C8sRAeTRzProEp5YACvKj9NrQZyVQMmd8\neCyyLGXl39rwqFXl41pJtMFpeg+nr0Vha+AjpKf4AkEnh+ADtDo=\n-----END RSA PRIVATE KEY-----";

// const APP_ID = "1090700";
// const PRIVATE_KEY_PATH = "./reviewjudge.2024-07-14.private-key.pem";

/**
 * Generate JWT token
 */
function generateJWT() {
    const privateKey = PRIVATE_KEY;

    const payload = {
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + (10 * 60),
        iss: APP_ID
    };

    return jwt.sign(payload, privateKey, { algorithm: "RS256" });
}

/**
 * Get GitHub App Installation ID
 */
async function getInstallationID() {
    const jwtToken = generateJWT();
    
    try {
        const { data } = await axios.get("https://api.github.com/app/installations", {
            headers: {
                Authorization: `Bearer ${jwtToken}`,
                Accept: "application/vnd.github.v3+json"
            }
        });

        if (data.length === 0) throw new Error("No installations found");

        return data[0].id;
    } catch (error) {
        console.error("❌ Error fetching Installation ID:", error.response?.data || error.message);
        throw error;
    }
}

/**
 * Get Installation Access Token
 */
async function getInstallationToken() {
    const jwtToken = generateJWT();
    const installationID = await getInstallationID();

    const url = `https://api.github.com/app/installations/${installationID}/access_tokens`;

    try {
        const { data } = await axios.post(url, {}, {
            headers: {
                Authorization: `Bearer ${jwtToken}`,
                Accept: "application/vnd.github.v3+json"
            }
        });

        return data.token;
    } catch (error) {
        console.error("❌ Error fetching installation token:", error.response?.data || error.message);
        throw error;
    }
}

export { generateJWT, getInstallationID, getInstallationToken };