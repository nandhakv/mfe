import dotenv from "dotenv";
dotenv.config();

export const connectLLm = async ({ prompt, responseSchema }) => {
    const fetch = (await import("node-fetch")).default; // Dynamic import for node-fetch

    return await fetch("https://llmproxy.go-yubi.in/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${process.env.LLM_API_KEY}`,
        },
        body: JSON.stringify({
            model: "bedrock-claude-3.5-(US)",
            messages: [
                {
                    role: "system",
                    content:
                        "You are an AI assistant providing detailed code review feedback.",
                },
                {
                    role: "user",
                    content: prompt,
                },
            ],
            response_format: responseSchema, // Use structured schema
        }),
    }).then((response) => response.json()).catch((error) => {
        console.error("❌ Error connecting to LLM:", error);
        throw error;
    }
    );
};