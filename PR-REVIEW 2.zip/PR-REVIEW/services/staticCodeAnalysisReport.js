import { updatePullRequestDescription, getPullRequestDetails } from "./githubService.js";

const addTestReportToPR = async (checkRun) => {
  try {
    const { output, url } = checkRun;

    // Extract PR number from title
    const prMatch = output.title.match(/#(\d+)#/);
    if (!prMatch) {
      console.error("PR number not found in title");
      return;
    }
    const prNumber = prMatch[1];

    // Extract repo owner and name from the URL
    const repoMatch = url.match(/repos\/([^/]+)\/([^/]+)\/check-runs/);
    if (!repoMatch) {
      console.error("Repository details not found in URL");
      return;
    }
    const repo = `${repoMatch[1]}/${repoMatch[2]}`;

    // ✅ Define section boundaries
    const sonarReportStart = "<!-- START_SONARQUBE_REPORT -->";
    const sonarReportEnd = "<!-- END_SONARQUBE_REPORT -->";
    const aiSummaryStart = "<!-- START_AI_SUMMARY -->";
    const aiSummaryEnd = "<!-- END_AI_SUMMARY -->";

    // ✅ Fetch current PR description
    const prDetails = await getPullRequestDetails(repo, prNumber);
    let prDescription = prDetails.details.body || "";

    // ✅ Extract existing AI Summary & SonarQube Report
    const existingAIReport = extractSection(prDescription, aiSummaryStart, aiSummaryEnd);
    const existingSonarReport = extractSection(prDescription, sonarReportStart, sonarReportEnd);

    console.log("existingAIReport SQ ", existingAIReport);
    console.log("existingSonarReport SQ ", existingSonarReport);
    // ✅ Parse SonarQube report
    let newSonarReport;
    const sonarData = JSON.parse(output.text);

    if (!sonarData.issues || !sonarData.issues.issues.length) {
      console.log("No issues found in the SonarQube report.");
      newSonarReport = `${sonarReportStart}\n## ✅ No issues found in the SonarQube analysis.\n${sonarReportEnd}`;
    } else {
      let table = `| File | Line | Severity | Issue |\n|------|------|----------|-------|\n`;
      sonarData.issues.issues.forEach(issue => {
        const severityIcons = {
          "BLOCKER": "🔴 Critical",
          "CRITICAL": "🟠 High",
          "MAJOR": "🟡 Medium",
          "MINOR": "🔵 Low",
        };
        const severityLabel = severityIcons[issue.severity] || issue.severity;
        table += `| ${issue.component} | ${issue.line || "N/A"} | ${severityLabel} | ${issue.message} |\n`;
      });

      newSonarReport = `${sonarReportStart}\n## 📊 Static Code Analysis Report\n\n${table}\n${sonarReportEnd}`;
    }

    // ✅ Rebuild PR description ensuring both reports are included
    prDescription = `${newSonarReport}\n\n${existingAIReport || ""}`;

    // ✅ Update PR Description
    await updatePullRequestDescription(repo, prNumber, prDescription);
    console.log(`✅ PR #${prNumber} updated successfully with SonarQube report.`);
  } catch (error) {
    console.error("❌ Error updating PR with SonarQube report:", error);
  }
};

/**
 * Extracts a section from a text given its start and end markers.
 */
function extractSection(text, startMarker, endMarker) {
  const regex = new RegExp(`${startMarker}[\\s\\S]*?${endMarker}`, "g");
  const match = text.match(regex);
  return match ? match[0] : "";
}

export { addTestReportToPR };
