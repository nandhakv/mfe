import { getInstallationToken } from "./githubAuth.js";
import { parseGitDiff } from "../common/utils.js";
import axios from "axios";
import { Octokit } from "@octokit/core";
// import { promises as fs } from "fs";
// import path from "path";
import fs from "fs";

/**
 * Fetch PR details
 */
async function getPullRequestDetails(repo, prNumber) {
    try {
        const token = await getInstallationToken();
        const octokit = new Octokit({ auth: token });

        // Debugging: Check repo value before splitting
        if (typeof repo !== "string") {
            console.error("❌ Invalid repo format. Expected string but got:", repo);
            throw new Error("Invalid repository format. Expected a string like 'owner/repo'.");
        }

        const [owner, repoName] = repo.split("/");

        // Fetch PR details
        const { data: prDetails } = await octokit.request("GET /repos/{owner}/{repo}/pulls/{pull_number}", {
            owner,
            repo: repoName,
            pull_number: prNumber,
        });

        // Fetch list of files in the PR
        const { data: files } = await octokit.request("GET /repos/{owner}/{repo}/pulls/{pull_number}/files", {
            owner,
            repo: repoName,
            pull_number: prNumber,
        });

        return {
            details: prDetails,
            files: files.map(file => ({
                filename: file.filename,
                status: file.status,
                additions: file.additions,
                deletions: file.deletions,
                changes: file.changes,
                raw_url: file.raw_url,
            })),
        };
    } catch (error) {
        console.error("❌ Error fetching PR details:", error.response?.data || error.message);
        throw error;
    }
}

/**
 * Fetch PR diff
 */
async function fetchPullRequestDiff(repo, prNumber) {
    console.log("repo", repo);
    const token = await getInstallationToken();
    const octokit = new Octokit({ auth: token });

    const [owner, repoName] = repo.split("/");
    
    const { data } = await octokit.request("GET /repos/{owner}/{repo}/pulls/{pull_number}", {
        owner,
        repo: repoName,
        pull_number: prNumber,
        headers: { Accept: "application/vnd.github.v3.diff" } // Fetch as raw diff
    });

    return parseGitDiff(data);
}

// /**
//  * Fetch the full content of a file
//  */
async function fetchFileContent(rawUrl) {
    try {
        console.log("fetching code from: ", rawUrl);
        const token = await getInstallationToken();

        const response = await axios.get(rawUrl, {
            headers: {
                Authorization: `token ${token}`,
                Accept: "application/vnd.github.v3.raw",
            },
        });
       
        return response.data;
    } catch (error) {
        console.error(`❌ Error fetching file content from: ${rawUrl}`, error.response?.data || error.message);
        throw error;
    }
}

/**
 * Get the latest commit ID for a PR
 */
async function getLatestCommitId(repo, prNumber) {
    try {
        const token = await getInstallationToken();
        const octokit = new Octokit({ auth: token });

        const [owner, repoName] = repo.split("/");
        const { data } = await octokit.request("GET /repos/{owner}/{repo}/pulls/{pull_number}/commits", {
            owner,
            repo: repoName,
            pull_number: prNumber,
        });

        return data[data.length - 1].sha; // Get the last commit in the list
    } catch (error) {
        console.error("❌ Error fetching commit ID:", error.response?.data || error.message);
        throw error;
    }
}

/**
 * Post an inline comment on a specific line of a PR.
 */
 async function postInlineComment(repo, prNumber, filePath, line, comment) {
    try {
        const token = await getInstallationToken();
        const octokit = new Octokit({ auth: token });

        const [owner, repoName] = repo.split("/");
        const commitId = await getLatestCommitId(repo, prNumber);

        await octokit.request("POST /repos/{owner}/{repo}/pulls/{pull_number}/comments", {
            owner,
            repo: repoName,
            pull_number: prNumber,
            body: comment,
            commit_id: commitId,
            path: filePath,
            line: line,  
            side: "RIGHT", // Ensures comment is placed on the new code
        });

        console.log(`✅ Posted comment on ${filePath} (Line ${line})`);
    } catch (error) {
        console.error("❌ Error posting inline comment:", error.response?.data || error.message);
     //   throw error;
    }
}

/**
 * Update PR Description
 */
async function updatePullRequestDescription(repo, prNumber, updatedDescription) {
    const token = await getInstallationToken();
    const octokit = new Octokit({ auth: token });

    const [owner, repoName] = repo.split("/");
    
    try {
        await octokit.request("PATCH /repos/{owner}/{repo}/pulls/{pull_number}", {
            owner,
            repo: repoName,
            pull_number: prNumber,
            body: updatedDescription
        });

        console.log("✅ PR description updated successfully.");
    } catch (error) {
        console.error("❌ Error updating PR description:", error.response?.data || error.message);
    }
}

/**
 * Ensure that the GitHub Actions workflow file exists in the repository
 */
async function ensureWorkflowExists(repo) {
    try{
    const token = await getInstallationToken();
    const octokit = new Octokit({ auth: token });

    const [owner, repoName] = repo.split("/");
    const workflowPath = ".github/workflows/";

    // 1️⃣ Get the default branch dynamically
    const { data: repoData } = await octokit.request("GET /repos/{owner}/{repo}", {
        owner,
        repo: repoName
    });
    const defaultBranch = repoData.default_branch;
    console.log(`✅ Default branch detected: ${defaultBranch}`);

    // Load workflow version details
    const versions = JSON.parse(fs.readFileSync("workflows/workflow_versions.json", "utf-8"));
    const latestWorkflowFile = versions.latest;
    const allWorkflowFiles = new Set(Object.values(versions.versions));
    const workflowContent = fs.readFileSync("workflows/" + latestWorkflowFile, "utf-8");

    // 2️⃣ Get the list of existing workflows in the repo
    let existingWorkflows = [];
    try {
        const { data: workflowsData } = await octokit.request("GET /repos/{owner}/{repo}/actions/workflows", {
            owner,
            repo: repoName
        });
        
        // Extract workflow file names
        existingWorkflows = workflowsData.workflows.map(workflow => workflow.path.split('/').pop()).filter(file => allWorkflowFiles.has(file));;
        
        console.log(`📂 Existing workflows found: ${existingWorkflows.join(", ")}`);
        
    } catch (error) {
        if (error.status === 404) {
            console.log(`⚠️ No existing workflows found.`);
        } else {
            console.error(`❌ Error fetching workflow files: ${error.message}`);
            throw error;
        }
    }

    // 3️⃣ If the latest workflow already exists, return the workflow ID
    if (existingWorkflows.includes(latestWorkflowFile)) {
        console.log(`✅ Latest workflow ${latestWorkflowFile} already exists.`);

        const { data: workflows } = await octokit.request("GET /repos/{owner}/{repo}/actions/workflows", {
            owner,
            repo: repoName
        });

        const workflow = workflows.workflows.find(w => w.path.endsWith(latestWorkflowFile));
        if (workflow) {
            console.log(`✅ Workflow already exists with ID: ${workflow.id}`);
            return { workflowId: workflow.id, githubToken: token };
        } else {
            console.log(`⚠️ Workflow file exists, but no matching workflow ID found.`);
            return null;
        }
    }

    console.log(`⚠️ Latest workflow ${latestWorkflowFile} not found. Proceeding with update...`);

    // 4️⃣ Create a new temporary branch
    const tempBranch = `workflow-update-${Date.now()}`;
    const { data: branchData } = await octokit.request("GET /repos/{owner}/{repo}/branches/{branch}", {
        owner,
        repo: repoName,
        branch: defaultBranch
    });
    const latestCommitSha = branchData.commit.sha;

    await octokit.request("POST /repos/{owner}/{repo}/git/refs", {
        owner,
        repo: repoName,
        ref: `refs/heads/${tempBranch}`,
        sha: latestCommitSha
    });

    console.log(`✅ Created temporary branch: ${tempBranch}`);

    // 5️⃣ Delete old workflows
    for (const oldFile of existingWorkflows) {
        if (oldFile !== latestWorkflowFile) {
            try {
                const { data: fileData } = await octokit.request("GET /repos/{owner}/{repo}/contents/{path}", {
                    owner,
                    repo: repoName,
                    path: workflowPath + oldFile
                });

                await octokit.request("DELETE /repos/{owner}/{repo}/contents/{path}", {
                    owner,
                    repo: repoName,
                    path: workflowPath + oldFile,
                    message: `Remove old workflow: ${oldFile}`,
                    sha: fileData.sha,
                    branch: tempBranch
                });

                console.log(`🗑️ Removed old workflow: ${oldFile}`);
            } catch (error) {
                console.error(`❌ Failed to delete ${oldFile}: ${error.message}`);
            }
        }
    }

    // 6️⃣ Upload the latest workflow file
    await octokit.request("PUT /repos/{owner}/{repo}/contents/{path}", {
        owner,
        repo: repoName,
        path: workflowPath + latestWorkflowFile,
        message: `Add latest GitHub Actions workflow: ${latestWorkflowFile}`,
        content: Buffer.from(workflowContent).toString("base64"),
        branch: tempBranch,
        // sha: latestCommitSha,
    });

    console.log(`✅ Workflow file added on ${tempBranch}`);

    // 7️⃣ Create a pull request
    const { data: pullRequest } = await octokit.request("POST /repos/{owner}/{repo}/pulls", {
        owner,
        repo: repoName,
        title: "#Workflow Auto PR: Update Workflow",
        head: tempBranch,
        base: defaultBranch,
        body: `Automated PR to update the GitHub Actions workflow. This PR:\n\n- **Adds the latest workflow (${latestWorkflowFile})**\n- **Removes outdated workflow files**\n\n**Note:** This PR is created automatically. Do not close this PR manually.`,
    });

    console.log(`✅ Pull request created: ${pullRequest.html_url}`);

    return { prUrl: pullRequest.html_url };
} catch (error) {
    console.error(`❌ Error ensuring workflow exists: ${error.message}`);
}
}

async function triggerGitHubAction(repo, workflowId, inputs) {
    const token = await getInstallationToken(); // Ensure you have a valid GitHub token    
    const octokit = new Octokit({ auth: token });
    const [owner, repoName] = repo.split("/");

    try {
        const response = await octokit.request(
            "POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches",
            {
                owner,
                repo: repoName,
                workflow_id: workflowId,
                ref: "master",
                inputs,
                headers: {
                    Accept: "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                    "Content-Type": "application/json",
                }
            }
        );

        console.log("✅ GitHub Action triggered successfully:", response.status);
        return response.status;
    } catch (error) {
        console.error(`❌ GitHub API Error (${error.status}): ${error.message}`);
        throw error;
    }
}


export { getPullRequestDetails, fetchPullRequestDiff, fetchFileContent, postInlineComment, updatePullRequestDescription, getLatestCommitId, ensureWorkflowExists, triggerGitHubAction };