// import { analyzePullRequest } from "./staticCodeAnalyser.js"; 

// async function testSonarQubeAnalysis() {
//     const files = [
//         {
//             filename: 'container-1/src/App.js',
//             status: 'modified',
//             raw_url: 'https://github.com/nandhakv/mfe/raw/5cbfe14c5979a52ed61dcdb3924ba5072e3fa929/container-1%2Fsrc%2FApp.js'
//         },
//         {
//             filename: 'container-1/src/components/Header.js',
//             status: 'modified',
//             raw_url: 'https://github.com/nandhakv/mfe/raw/5cbfe14c5979a52ed61dcdb3924ba5072e3fa929/container-1%2Fsrc%2Fcomponents%2FHeader.js'
//         }
//     ];

//     const prOwner = 'your_user';
//     const prRepo = 'your_repo';
//     const prNumber = 1;

//     console.log("Starting SonarQube analysis...");

//     try {
//         const results = await analyzePullRequest(files, prOwner, prRepo, prNumber);
//         console.log("SonarQube Analysis Results:", JSON.stringify(results, null, 2));
//     } catch (error) {
//         console.error("Error during analysis:", error);
//     }
// }

// // Run the test function
// testSonarQubeAnalysis();

import { ensureWorkflowExists, triggerGitHubAction } from './githubService.js';

const { workflowId, githubToken} = await ensureWorkflowExists("credavenue/phoenix-ui");

console.log("worflowId", workflowId);
console.log("githubToken", githubToken);
// triggerGitHubAction(
//   "credavenue/phoenix-ui",
//   workflowId,
//   {
//       branch: "develop/yb-core-textfield",
//       files: "packages/yb-core-textfield/.eslintrc.js,packages/yb-core-textfield/config-overrides.js",
//       pr_number: "279",
//       github_token: githubToken,
//       sonarqube_host: process.env.SONARQUBE_HOST,
//       sonarqube_token: process.env.SONARQUBE_TOKEN
//   }
// );

// await triggerWorkflow("nandhakv/mfe");