import jwt from "jsonwebtoken";
import fs from "fs";
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const APP_ID = process.env.GITHUB_APP_ID;
const PRIVATE_KEY = process.env.GITHUB_PRIVATE_KEY;

/**
 * Generate a JWT token for GitHub App authentication
 */
function generateJWT() {
    const privateKey = PRIVATE_KEY;

    const payload = {
        iat: Math.floor(Date.now() / 1000),  // Issued at (current time)
        exp: Math.floor(Date.now() / 1000) + (10 * 60), // Expires in 10 min
        iss: APP_ID  // GitHub App ID
    };

    return jwt.sign(payload, privateKey, { algorithm: "RS256" });
}

/**
 * Get the GitHub App Installation ID
 */
async function getInstallationID() {
    const jwtToken = generateJWT();
    
    try {
        const { data } = await axios.get("https://api.github.com/app/installations", {
            headers: {
                Authorization: `Bearer ${jwtToken}`,
                Accept: "application/vnd.github.v3+json"
            }
        });

        if (data.length === 0) throw new Error("No installations found for this app");

        return data[0].id;  // Assuming the first installation is the correct one
    } catch (error) {
        console.error("❌ Error fetching Installation ID:", error.response?.data || error.message);
        throw new Error("Failed to get Installation ID");
    }
}

/**
 * Get an Installation Access Token to interact with GitHub API
 */
export async function getInstallationToken() {
    const jwtToken = generateJWT();
    const installationID = await getInstallationID();  // Fetch Installation ID dynamically

    const url = `https://api.github.com/app/installations/${installationID}/access_tokens`;

    try {
        const { data } = await axios.post(url, {}, {
            headers: {
                Authorization: `Bearer ${jwtToken}`,
                Accept: "application/vnd.github.v3+json"
            }
        });

        return data.token;
    } catch (error) {
        console.error("❌ Error fetching installation token:", error.response?.data || error.message);
        throw new Error("Failed to get installation token");
    }
}

// Run and log the authentication process
(async () => {
    try {
        console.log("🔑 JWT Token:", generateJWT());
        console.log("🏷️ Installation ID:", await getInstallationID());
        console.log("🔓 Installation Token:", await getInstallationToken());
    } catch (error) {
        console.error("❌ Authentication Error:", error.message);
    }
})();

export { generateJWT, getInstallationID, getInstallationToken };