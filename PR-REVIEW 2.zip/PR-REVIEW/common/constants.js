export const responseSchema = {
    type: "json_schema",
    json_schema: {
        name: "review_feedback",
        schema: {
            type: "object",
            properties: {
                reviews: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            startLine: { type: "number" },
                            endLine: { type: "number" },
                            commentLine: { type: "number" },
                            comment: {
                                type: "string",
                            },
                        },
                        required: ["startLine", "endLine", "comment"],
                        additionalProperties: false,
                    },
                },
                fileSummary: {
                    type: "array",
                    items: {
                        type: "string",
                        description:
                            "Briefly list the main changes made in this file. Include key additions, deletions, or modifications in bullet points (1-4 bullet points).",
                    },
                },
            },
            required: ["reviews", "fileSummary"],
            additionalProperties: false,
        },
        strict: true,
    },
};

export const summaryResponseScheme = {
    type: "json_schema",
    json_schema: {
        name: "review_feedback",
        schema: {
            type: "object",
            properties: {
                reviews: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            startLine: { type: "number" },
                            endLine: { type: "number" },
                            commentLine: { type: "number" },
                            comment: {
                                type: "string",
                            },
                        },
                        required: ["startLine", "endLine", "comment"],
                        additionalProperties: false,
                    },
                },
                fileSummary: {
                    type: "array",
                    items: {
                        type: "string",
                        description:
                            "Briefly list the main changes made in this file. Include key additions, deletions, or modifications in bullet points (1-4 bullet points).",
                    },
                },
            },
            required: ["reviews", "fileSummary"],
            additionalProperties: false,
        },
        strict: true,
    },
};