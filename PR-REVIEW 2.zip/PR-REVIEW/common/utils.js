import { generateAISummary } from "../services/aiReviewService.js";
import { generatePRSummaryPrompt } from "./prompts.js";

function parseGitDiff(diff) {
  const fileDiffs = {};
  let currentFile = null;
  let currentDiff = [];

  const lines = diff.split("\n");

  for (const line of lines) {
      // Detect file changes in unified diff format
      const fileMatch = line.match(/^diff --git a\/(.+) b\/(.+)$/);
      if (fileMatch) {
          // Store previous file's diff
          if (currentFile && currentDiff.length > 0) {
              fileDiffs[currentFile] = currentDiff.join("\n");
          }

          // Start new file diff
          currentFile = fileMatch[2]; // File path after `b/`
          currentDiff = [];
      } else if (currentFile) {
          currentDiff.push(line);
      }
  }

  // Store last file's diff
  if (currentFile && currentDiff.length > 0) {
      fileDiffs[currentFile] = currentDiff.join("\n");
  }

  return fileDiffs;
}

// function extractDiffChanges(diffString) {
//   const allChanges = [];

//   for (const [fileName, diffContent] of Object.entries(diffString)) {
//       const lines = diffContent.split("\n");
//       const changes = [];
//       let oldHunk = [];
//       let newHunk = [];
//       let oldLineStart = null;
//       let newLineStart = null;
//       let currentOldLine = null;
//       let currentNewLine = null;
//       let type = null;
//       let fullCode = diffContent;

//       for (const line of lines) {
//           if (line.startsWith("--- ") || line.startsWith("+++ ")) {
//               continue;
//           }

//           if (line.startsWith("@@")) {
//               const match = line.match(/-(\d+),?\d* \+(\d+),?\d*/);
//               if (match) {
//                   oldLineStart = parseInt(match[1], 10);
//                   newLineStart = parseInt(match[2], 10);
//                   currentOldLine = oldLineStart;
//                   currentNewLine = newLineStart;
//               }
//               continue;
//           }

//           if (line.startsWith("-")) {
//               if (!type) type = "updated";
//               oldHunk.push(line.slice(1).trim());
//               currentOldLine++;
//           } else if (line.startsWith("+")) {
//               if (!type) type = oldHunk.length ? "updated" : "added";
//               newHunk.push(line.slice(1).trim());
//               currentNewLine++;
//           } else {
//               if (oldHunk.length || newHunk.length) {
//                   changes.push({
//                       type,
//                       oldHunk: oldHunk.length ? oldHunk.join("\n") : undefined,
//                       newHunk: newHunk.length ? newHunk.join("\n") : undefined,
//                       startLine: newHunk.length ? currentNewLine - newHunk.length : currentNewLine, // Always take from new hunk
//                       endLine: newHunk.length ? currentNewLine - 1 : currentNewLine - 1,
//                       fileName,
//                       fullCode,
//                   });
//                   oldHunk = [];
//                   newHunk = [];
//                   type = null;
//               }
//               currentOldLine++;
//               currentNewLine++;
//           }
//       }

//       if (oldHunk.length || newHunk.length) {
//           changes.push({
//               type,
//               oldHunk: oldHunk.length ? oldHunk.join("\n") : undefined,
//               newHunk: newHunk.length ? newHunk.join("\n") : undefined,
//               startLine: newHunk.length ? currentNewLine - newHunk.length : currentNewLine,
//               endLine: newHunk.length ? currentNewLine - 1 : currentNewLine - 1,
//               fileName,
//               fullCode,
//           });
//       }

//       allChanges.push(...changes);
//   }

//   return allChanges;
// }
function extractDiffChanges(diffString) {
  const allChanges = [];
  const ignoredExtensions = [".lock", ".yml", ".yaml", ".log", ".gitignore",".md",".html",".config.js",".mdx",".json"];

  for (const [fileName, diffContent] of Object.entries(diffString)) {
      // ✅ Skip files with ignored extensions
      if (ignoredExtensions.some(ext => fileName.endsWith(ext))) {
          console.log(`🚫 Skipping file: ${fileName}`);
          continue;
      }

      const lines = diffContent.split("\n");
      const changes = [];
      let oldHunk = [];
      let newHunk = [];
      let oldLineStart = null;
      let newLineStart = null;
      let currentOldLine = null;
      let currentNewLine = null;
      let type = null;
      let fullCode = diffContent;

      for (const line of lines) {
          if (line.startsWith("--- ") || line.startsWith("+++ ")) {
              continue;
          }

          if (line.startsWith("@@")) {
              const match = line.match(/-(\d+),?\d* \+(\d+),?\d*/);
              if (match) {
                  oldLineStart = parseInt(match[1], 10);
                  newLineStart = parseInt(match[2], 10);
                  currentOldLine = oldLineStart;
                  currentNewLine = newLineStart;
              }
              continue;
          }

          if (line.startsWith("-")) {
              if (!type) type = "updated";
              oldHunk.push(line.slice(1).trim());
              currentOldLine++;
          } else if (line.startsWith("+")) {
              if (!type) type = oldHunk.length ? "updated" : "added";
              newHunk.push(line.slice(1).trim());
              currentNewLine++;
          } else {
              if (oldHunk.length || newHunk.length) {
                  changes.push({
                      type,
                      oldHunk: oldHunk.length ? oldHunk.join("\n") : undefined,
                      newHunk: newHunk.length ? newHunk.join("\n") : undefined,
                      startLine: newHunk.length ? currentNewLine - newHunk.length : currentNewLine, // Always take from new hunk
                      endLine: newHunk.length ? currentNewLine - 1 : currentNewLine - 1,
                      fileName,
                      fullCode,
                  });
                  oldHunk = [];
                  newHunk = [];
                  type = null;
              }
              currentOldLine++;
              currentNewLine++;
          }
      }

      if (oldHunk.length || newHunk.length) {
          changes.push({
              type,
              oldHunk: oldHunk.length ? oldHunk.join("\n") : undefined,
              newHunk: newHunk.length ? newHunk.join("\n") : undefined,
              startLine: newHunk.length ? currentNewLine - newHunk.length : currentNewLine,
              endLine: newHunk.length ? currentNewLine - 1 : currentNewLine - 1,
              fileName,
              fullCode,
          });
      }

      allChanges.push(...changes);
  }

  return allChanges;
}


async function generatePRSummaryTable(codeChanges, aiPrompt) {
  const issueCounts = { '🔴 Critical': 0, '🟠 High': 0, '🟡 Medium': 0, '🔵 Low': 0 };
  const fileIssues = {};
  const lineChanges = {};

  // Count issues by severity and categorize them per file
  aiPrompt.forEach(({ file, comment }) => {
    const severityMatch = comment.match(/(🔴|🟠|🟡|🔵)\s(\w+)/);
    if (severityMatch) {
      const severity = `${severityMatch[1]} ${severityMatch[2]}`;
      issueCounts[severity]++;

      if (!fileIssues[file]) {
        fileIssues[file] = { '🔴 Critical': 0, '🟠 High': 0, '🟡 Medium': 0, '🔵 Low': 0, total: 0 };
      }
      fileIssues[file][severity]++;
      fileIssues[file].total++;
    }
  });

  // Track line additions and deletions
  codeChanges.forEach(({ fileName, type, oldHunk, newHunk }) => {
    if (!lineChanges[fileName]) {
      lineChanges[fileName] = { added: 0, deleted: 0 };
    }

    if (type === 'added') {
      lineChanges[fileName].added += (newHunk ? newHunk.split("\n").length : 0);
    } else if (type === 'deleted') {
      lineChanges[fileName].deleted += (oldHunk ? oldHunk.split("\n").length : 0);
    } else if (type === 'updated') {
      lineChanges[fileName].deleted += (oldHunk ? oldHunk.split("\n").length : 0);
      lineChanges[fileName].added += (newHunk ? newHunk.split("\n").length : 0);
    }
  });

  // Construct Issues Breakdown Table
  const issuesTable = Object.entries(issueCounts)
    .filter(([_, count]) => count > 0)
    .map(([severity, count]) => `| ${severity} | ${count} |`)
    .join("\n");

  // Construct File Changes Table
  const modifiedFiles = [...new Set(codeChanges.map(({ fileName }) => fileName))];
  const aiDescription = await generateAISummary(generatePRSummaryPrompt(issuesTable, modifiedFiles));

  const fileChangesTable = modifiedFiles
    .filter(file => (fileIssues[file]?.total || 0) > 0) // Skip files with no issues
    .map(file => {
      const issues = fileIssues[file] || { total: 0 };
      return `| ${file} | ❌ ${issues.total} Issues | ${
        issues['🔴 Critical'] ? `🔴 ${issues['🔴 Critical']}` : "0"
      } | ${
        issues['🟠 High'] ? `🟠 ${issues['🟠 High']}` : "0"
      } | ${
        issues['🟡 Medium'] ? `🟡 ${issues['🟡 Medium']}` : "0"
      } | ${
        issues['🔵 Low'] ? `🔵 ${issues['🔵 Low']}` : "0"
      } |`;
    })
    .join("\n");

  const formattedFileChangesTable = fileChangesTable.length
    ? `| File | Status | 🔴 Critical | 🟠 High | 🟡 Medium | 🔵 Low |
|------|--------|------------|---------|-----------|--------|
${fileChangesTable}`
    : "";

  const formattedIssuesTable = issuesTable.length
    ? `| Severity | Count |
|----------|-------|
${issuesTable}`
    : "";

  const reviewComments = aiPrompt.length
    ? aiPrompt.map(({ file, commentLine, comment }) => `- **${file} (Line ${commentLine})**: ${comment}`).join("\n")
    : "";

  // Construct the final output
  let output = `### 📊 PR Summary\n${aiDescription}\n`;

  if (formattedFileChangesTable) {
    output += `\n### 🗂 Issues on Changed Files\n\n${formattedFileChangesTable}\n`;
  }

  // if (formattedIssuesTable) {
  //   output += `\n### 🔍 Issues Breakdown\n\n${formattedIssuesTable}\n`;
  // }

  if (reviewComments) {
    output += `\n### 📝 AI Review Comments\n\n${reviewComments}\n`;
  }

  // If no content exists, return a default message
  if (!formattedFileChangesTable && !formattedIssuesTable && !reviewComments) {
    output = "✅ No issues or changes detected in this PR.";
  }

  return output;
}

const getModifiedFiles = (prData) => {
  if (!prData || !Array.isArray(prData.files)) {
      console.error("Invalid prData or files array missing");
      return "";
  }

  const modifiedFiles = prData.files
      .filter(file => file.status === "modified" || file.status === "added") // Filter modified or added files
      .map(file => file.filename); // Extract filenames

  return [...new Set(modifiedFiles)].join(","); // Convert unique filenames to a comma-separated string
};

export { parseGitDiff, extractDiffChanges, generatePRSummaryTable, getModifiedFiles };

// ### 🚨 Issue Breakdown  

// ${formattedIssuesTable}  